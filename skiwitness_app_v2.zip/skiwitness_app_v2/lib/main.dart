import 'dart:async';
import 'dart:developer';

import 'package:amplify_auth_cognito/amplify_auth_cognito.dart';
// import 'package:amplify_flutter/amplify.dart';
import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:sentry_flutter/sentry_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skiwitness_app/bloc/contact_bloc/contact_bloc.dart';
import 'package:skiwitness_app/bloc/get_plans_bloc/get_plans_bloc.dart';
import 'package:skiwitness_app/bloc/profile_image_bloc/profile_image_bloc.dart';
import 'package:skiwitness_app/in_app_purchase/ipa_service.dart';
import 'package:sqflite/sqflite.dart';

import 'DB/create_database.dart';
import 'amplifyconfiguration.dart';
import 'index.dart';
import 'theme/internationalization.dart';
import 'theme/pay_now_theme.dart';

void main() async {
  // PayNowTheme.initialize();
  // WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  // FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);
  WidgetsFlutterBinding.ensureInitialized();
  await PayNowTheme.initialize();
  await _configureAmplify();

  await SentryFlutter.init(
    (options) {
      options.dsn =
          'https://c05c1bb31d7b3ede5c6cd7192ff05b51@o1321288.ingest.us.sentry.io/4507945263169536';
      // Set tracesSampleRate to 1.0 to capture 100% of transactions for tracing.
      // We recommend adjusting this value in production.
      options.tracesSampleRate = 1.0;
      // The sampling rate for profiling is relative to tracesSampleRate
      // Setting to 1.0 will profile 100% of sampled transactions:
      options.profilesSampleRate = 1.0;
    },
    appRunner: () => runApp(const MyApp()),
  );

  // Amplify.Auth.signOut();
  runApp(const MyApp());
}

Future<void> _configureAmplify() async {
  AmplifyAuthCognito authPlugin = AmplifyAuthCognito();
  Amplify.addPlugin(authPlugin);

  try {
    await Amplify.configure(amplifyconfig);
    print("Amplify successfully configured");
  } catch (e) {
    print("Could not configure Amplify: $e");
  }
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  State<MyApp> createState() => _MyAppState();

  static _MyAppState of(BuildContext context) =>
      context.findAncestorStateOfType<_MyAppState>()!;
}

class _MyAppState extends State<MyApp> {
  Locale? _locale;
  ThemeMode _themeMode = PayNowTheme.themeMode;
  Timer? _timer;
  bool displaySplashImage = true;
  bool _isAuthenticated = false;
  bool _hasSeenOnboarding = false;
  bool _isLogin = false;

  late StreamSubscription<List<PurchaseDetails>> _iapSubscription;

  void _ipaSubscriptionObv() {
    final Stream purchaseUpdated = InAppPurchase.instance.purchaseStream;

    _iapSubscription = purchaseUpdated.listen((purchaseDetailsList) async {
      log("Purchase stream started");
      await Sentry.captureMessage("Purchase stream started");
      IAPService().listenToPurchaseUpdated(purchaseDetailsList);
    }, onDone: () async {
      await Sentry.captureMessage("Purchase stream Cancel");
      _iapSubscription.cancel();
    }, onError: (error) async {
      await Sentry.captureMessage("Purchase stream started");
      await Sentry.captureException(error);
      _iapSubscription.cancel();
    }) as StreamSubscription<List<PurchaseDetails>>;
  }

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 1),
        () => setState(() => displaySplashImage = false));
    _initializeDatabase(); // Call the initializeDatabase() method
    _checkAuthStatus();
    _checkOnboardingStatus();
    _ipaSubscriptionObv();
    // _timer = Timer.periodic(Duration(seconds: 5), _onTimerTick);
  }

  // Future<void> _onTimerTick(Timer timer) async {
  //   // Call your function here
  //   final OfflineVideoRecordsWidget _s3BucketAutoSync = OfflineVideoRecordsWidget();
  //   String? result = await _s3BucketAutoSync.s3_bucket_auto_sync();
  //   print('Automatic function call every 5 seconds');
  // }

  Future<void> _initializeDatabase() async {
    DataBase database = DataBase();
    // Call the initializeDatabase() method and await its completion
    Database db = await database.initializeDatabase();
    print('hari');
    print(db);
    print('suthan');
  }

  Future<void> _checkAuthStatus() async {
    try {
      // Check if user is already signed in
      final session = await Amplify.Auth.fetchAuthSession(
          options: const CognitoSessionOptions(getAWSCredentials: true));
      setState(() {
        _isAuthenticated = session.isSignedIn;
      });
      var authUser = await Amplify.Auth.getCurrentUser();
      String cognitoId = authUser.userId;
      // print(cognitoId);
      // print(session);
      // print('hari');
      // print(_isAuthenticated);
      // print('hari');
    } catch (e) {
      print("Error checking auth status: $e");
    }
  }

  Future<void> _checkOnboardingStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool hasSeenOnboarding = prefs.getBool('hasSeenOnboarding') ?? false;
    bool hasLoginCheck = prefs.getBool('isLogin') ?? false;

    setState(() {
      _hasSeenOnboarding = hasSeenOnboarding;
      _isLogin = hasLoginCheck;
    });
  }

  void setLocale(String language) {
    setState(() => _locale = createLocale(language));
  }

  void setThemeMode(ThemeMode mode) => setState(() {
        _themeMode = mode;
        PayNowTheme.saveThemeMode(mode);
      });

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<GetPlansBloc>(
            create: (context) => GetPlansBloc()..add(GetAllPlansEvent())),
        BlocProvider<ContactBloc>(create: (context) => ContactBloc()),
        BlocProvider<ProfileImageBloc>(create: (context) => ProfileImageBloc())
      ],
      child: MaterialApp(
          title: 'Skiwitness',
          debugShowCheckedModeBanner: false,
          localizationsDelegates: const [
            FFLocalizationsDelegate(),
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          locale: _locale,
          supportedLocales: const [Locale('en', '')],
          // theme: ThemeData(brightness: Brightness.light),
          theme: ThemeData(brightness: Brightness.dark),
          darkTheme: ThemeData(brightness: Brightness.dark),
          themeMode: _themeMode,
          home: displaySplashImage
              ? Builder(
                  builder: (context) => Container(
                    color: PayNowTheme.of(context).primary,
                    child: Center(
                      child: Image.asset(
                        'assets/images/logo.png',
                        width: MediaQuery.of(context).size.width * 0.4,
                        height: MediaQuery.of(context).size.height * 1.0,
                        fit: BoxFit.contain,
                      ),
                    ),
                  ),
                )
              : _hasSeenOnboarding
                  ? _isAuthenticated || _isLogin
                      ? const NavBarPage(initialPage: 'DashboardPage')
                      : const WelcomePageWidget()
                  : const OnboardingPageWidget()
          // _isAuthenticated ? NavBarPage(initialPage: 'DashboardPage') :  OnboardingPageWidget(),
          // :  NavBarPage(initialPage: 'DashboardPage'),
          ),
    );
  }
}

class NavBarPage extends StatefulWidget {
  const NavBarPage({super.key, this.initialPage, this.page});

  final String? initialPage;
  final Widget? page;

  @override
  _NavBarPageState createState() => _NavBarPageState();
}

/// This is the private State class that goes with NavBarPage.
class _NavBarPageState extends State<NavBarPage> {
  String _currentPageName = 'DashboardPage';
  late Widget? _currentPage;

  @override
  void initState() {
    super.initState();
    _currentPageName = widget.initialPage ?? _currentPageName;
    _currentPage = widget.page;
  }

  @override
  Widget build(BuildContext context) {
    final tabs = {
      'DashboardPage': const MyRecordsTabWidget(),
      'IncomeTransPage': const OfflineVideoRecordsWidget(),
      'ContactListPage': const SubscriptionPageWidget(),
      'ProfilePage': const ProfilePageWidget(),
    };
    final currentIndex = tabs.keys.toList().indexOf(_currentPageName);
    return Scaffold(
      body: _currentPage ?? tabs[_currentPageName],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        onTap: (i) => setState(() {
          _currentPage = null;
          _currentPageName = tabs.keys.toList()[i];
        }),
        backgroundColor: const Color(0xFFF3F4F5),
        selectedItemColor: Colors.black,
        unselectedItemColor: const Color(0xC6616161),
        showSelectedLabels: true,
        showUnselectedLabels: true,
        type: BottomNavigationBarType.fixed,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(
              Icons.home_filled,
              size: 24.0,
            ),
            label: 'My Records',
            tooltip: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.offline_bolt_rounded,
              size: 24.0,
            ),
            label: 'Offline Videos',
            tooltip: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.subscriptions,
              size: 24.0,
            ),
            label: 'Subscription',
            tooltip: '',
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.more_horiz,
              size: 26.0,
            ),
            label: 'More',
            tooltip: '',
          )
        ],
      ),
    );
  }
}
