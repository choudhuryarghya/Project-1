import 'dart:developer';
import 'dart:io';

import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

class GetProfileImageRepo {
  Future<void> uploadProfileImage(
      {required String xyz,
      required String fileType,
      required File imageFile}) async {
    final dio = Dio();
    var authUser = await Amplify.Auth.getCurrentUser();

    var fileName = "${const Uuid().v4()}.jpg";
    var uuid = const Uuid().v4();

    log('uuid: $uuid, fileName: $fileName');
    String cognitoId = authUser.userId;
    log('cognitoId: $cognitoId');

    const String getPresignedURLEndPoint =
        'https://c1i5s281d2.execute-api.us-east-1.amazonaws.com/default/imageUploadPresigned';
    const String updateImageUrlEndPoint =
        'https://j8ncwqtfu4.execute-api.us-east-1.amazonaws.com/develop/updateimageurl';

    try {
      final response = await dio.get(getPresignedURLEndPoint, queryParameters: {
        'name': fileName,
        'type': 'jpg',
        'cognitoId': cognitoId,
      });

      if (response.statusCode == 200) {
        final imageUploadUrl = response.data['uploadURL'].toString();

        try {
          log(imageUploadUrl.replaceFirst(
              'https://ski-uploads.s3.amazonaws.com',
              'https://dczmr8aignart.cloudfront.net'));
          final res = await imageFile.readAsBytes();

          final imageResponse = await dio.put(
            imageUploadUrl.replaceFirst('https://ski-uploads.s3.amazonaws.com',
                'https://dczmr8aignart.cloudfront.net'),
            data: res,
            options: Options(
              headers: {'Content-Type': 'image/jpg'},
            ),
          );

          if (imageResponse.statusCode == 200) {
            final updateResponse = await dio.post(
              updateImageUrlEndPoint,
              data: {
                'imageUrl': fileName,
                'cognitoId': cognitoId,
                'isVideo': false,
                'id': uuid,
              },
              options: Options(headers: {'Content-Type': 'application/json'}),
            );

            if (updateResponse.statusCode == 200) {
              final url =
                  'https://3ghvmpumdb.execute-api.us-east-1.amazonaws.com/default/getUserDetails?cognitoId=$cognitoId';

              final response = await http.get(Uri.parse(url));

              if (response.statusCode == 200) {
                SharedPreferences prefs = await SharedPreferences.getInstance();
                await prefs.setString('userDetails', response.body);
              } else {
                throw Exception('Failed to load user details');
              }
            } else {
              log('Failed to update image URL: ${updateResponse.statusCode}');
            }
          }
        } catch (e) {
          throw Exception('Failed to upload image: $e');
        }
      }
    } catch (e) {
      throw Exception('Failed to get presigned URL: $e');
    }
  }
}
