import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:skiwitness_app/model/contact_model.dart';

class ContactRepo {
  Future<String> contactForm(ContactModel contact) async {
    try {
      Dio dio = Dio();
      final Map<String, dynamic> requestBody = {
        "cognitoId": contact.cognitoId,
        "body": contact.body
      };
      final response = await dio.post(
          'https://6o9s7uxrmh.execute-api.us-east-1.amazonaws.com/default/sendMail',
          data: requestBody);
      log(response.statusMessage.toString());
      if (response.statusCode == 200) {
        return '${response.statusCode}';
      } else {
        return '${response.statusMessage}';
      }
    } catch (e) {
      log(e.toString());
      throw Exception(e);
    }
  }
}
