import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:skiwitness_app/model/get_plans_model.dart';

class GetPlansRepo {
  Future<List<GetPlansModel>> getPlansList() async {
    Dio dio = Dio();

    try {
      final response = await dio.get(
          'https://fkojnxxrlg.execute-api.us-east-1.amazonaws.com/default/listSubscriptionPlans');

      final List<dynamic> getPlansListData = response.data;
      log('Response Data: ${getPlansListData.toString()}');
      List<GetPlansModel> plans =
          getPlansListData.map((data) => GetPlansModel.fromJson(data)).toList();
      return plans;
    } catch (e) {
      log(e.toString());
      throw Exception(e);
    }
  }
}
