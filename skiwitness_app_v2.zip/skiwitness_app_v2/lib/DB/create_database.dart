import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DataBase {
  Future<Database> initializeDatabase() async {
    final String path = join(await getDatabasesPath(), 'videos_database.db');
    // print('Database path: $path');

    // Open the database
    final Database database = await openDatabase(path);

    // Check if the 'videos' table exists
    final List<Map<String, dynamic>> tables = await database.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table' AND name='tbl_offline_videos';",
    );

    // If the 'videos' table doesn't exist, create it
    if (tables.isEmpty) {
      print('Creating table...');
      await database.execute(
        'CREATE TABLE tbl_offline_videos ('
        'id TEXT PRIMARY KEY,'
        'cognitoId TEXT,'
        'name TEXT,'
        'filePath TEXT,'
       ' location TEXT,'
        'duration INT,'
        'thumbnail TEXT,'
        'thumbnailFilename TEXT,'
        'datetime TEXT,'
        'isSubscriptionExpired INTEGER,'
        'videoCompressed INTEGER,'
        'sync INTEGER,'
        'isOffline INTEGER DEFAULT 0'
            ')',
      );
      print('Table created successfully');
    } else {
    //  await database.execute('DROP TABLE IF EXISTS tbl_offline_videos;');
      // Close the database
      // await database.close();
      // print(tables);
      //  print('Table already exists');
    }

    return database;
  }
}
