import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:skiwitness_app/model/get_plans_model.dart';
import 'package:skiwitness_app/repository/get_plans_repo.dart';

part 'get_plans_event.dart';
part 'get_plans_state.dart';

class GetPlansBloc extends Bloc<GetPlansEvent, GetPlansState> {
  GetPlansBloc() : super(GetPlansState.initial()) {
    on<GetPlansEvent>((event, emit) {});
    on<GetAllPlansEvent>(getAllPlansEvent);
  }

  FutureOr<void> getAllPlansEvent(
      GetAllPlansEvent event, Emitter<GetPlansState> emit) async {
    emit(const GetPlansState(status: GetPlanStatus.loading));
    try {
      final plansList = await GetPlansRepo().getPlansList();
      emit(GetPlansState(status: GetPlanStatus.loaded, plansList: plansList));
    } catch (e) {
      emit(const GetPlansState(
          status: GetPlanStatus.failure,
          message: 'Fetching Plans list failed! Please retry'));
    }
  }
}
