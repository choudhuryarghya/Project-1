part of 'get_plans_bloc.dart';

sealed class GetPlansEvent extends Equatable {
  const GetPlansEvent();

  @override
  List<Object> get props => [];
}

class GetAllPlansEvent extends GetPlansEvent{}