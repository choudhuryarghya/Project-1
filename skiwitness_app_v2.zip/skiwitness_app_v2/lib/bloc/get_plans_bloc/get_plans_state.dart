part of 'get_plans_bloc.dart';

enum GetPlanStatus { initial, loading, loaded, failure }

class GetPlansState extends Equatable {
  const GetPlansState({this.plansList, this.status, this.message});
  final List<GetPlansModel>? plansList;
  final GetPlanStatus? status;
  final String? message;

  factory GetPlansState.initial() {
    return const GetPlansState(status: GetPlanStatus.initial);
  }
  @override
  List<Object?> get props => [plansList, status, message];

  GetPlansState copyWith({
    List<GetPlansModel>? plansList,
    GetPlanStatus? status,
    String? message,
  }) {
    return GetPlansState(
        plansList: plansList ?? this.plansList,
        status: status ?? this.status,
        message: message ?? this.message);
  }
}
