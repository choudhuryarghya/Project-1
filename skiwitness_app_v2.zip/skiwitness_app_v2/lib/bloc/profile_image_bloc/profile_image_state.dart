part of 'profile_image_bloc.dart';

enum ProfileImageStatus { initial, loading, loaded, failure }

class ProfileImageState extends Equatable {
  const ProfileImageState({this.imageUrl, this.status, this.message});
  final String? imageUrl;
  final ProfileImageStatus? status;
  final String? message;

  factory ProfileImageState.initial() {
    return const ProfileImageState(status: ProfileImageStatus.initial);
  }
  @override
  List<Object?> get props => [imageUrl, status, message];

  ProfileImageState copyWith({
    String? imageUrl,
    ProfileImageStatus? status,
    String? message,
  }) {
    return ProfileImageState(
        imageUrl: imageUrl ?? this.imageUrl,
        status: status ?? this.status,
        message: message ?? this.message);
  }
}
