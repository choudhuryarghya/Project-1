import 'dart:async';
import 'dart:developer';
import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:skiwitness_app/repository/get_profile_image_repo.dart';

part 'profile_image_event.dart';
part 'profile_image_state.dart';

class ProfileImageBloc extends Bloc<ProfileImageEvent, ProfileImageState> {
  ProfileImageBloc() : super(ProfileImageState.initial()) {
    on<ProfileImageEvent>((event, emit) {});
    on<GetProfileImageEvent>(getProfileImageEvent);
  }

  FutureOr<void> getProfileImageEvent(
      GetProfileImageEvent event, Emitter<ProfileImageState> emit) async {
    emit(const ProfileImageState(status: ProfileImageStatus.loading));
    try {
      await GetProfileImageRepo().uploadProfileImage(
          fileType: event.fileType, imageFile: event.imageFile, xyz: '');
      // Future.delayed(const Duration(seconds: 3), () {
      //   emit(const ProfileImageState(
      //     status: ProfileImageStatus.loaded,
      //   ));
      // });
      emit(const ProfileImageState(
        status: ProfileImageStatus.loaded,
      ));
    } catch (e) {
      log(e.toString());
      emit(ProfileImageState(
          status: ProfileImageStatus.failure, message: e.toString()));
    }
  }
}
