part of 'contact_bloc.dart';

enum ContactStatus { initial, loading, loaded, failure }

class ContactState extends Equatable {
  ContactState({this.message, this.status});

  String? message;
  ContactStatus? status;

  factory ContactState.initial() {
    return ContactState(status: ContactStatus.initial);
  }
  @override
  List<Object?> get props => [message, status];

  ContactState copyWith({
    String? message,
    ContactStatus? status,
  }) {
    return ContactState(
        status: status ?? this.status, message: message ?? this.message);
  }
}
