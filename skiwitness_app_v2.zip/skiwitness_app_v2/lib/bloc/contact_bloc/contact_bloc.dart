import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:skiwitness_app/model/contact_model.dart';
import 'package:skiwitness_app/repository/contact_repo.dart';

part 'contact_event.dart';
part 'contact_state.dart';

class ContactBloc extends Bloc<ContactEvent, ContactState> {
  ContactBloc() : super(ContactState.initial()) {
    on<ContactEvent>((event, emit) {});
    on<SendContactFormEvent>(sendContactFormEvent);
  }

  FutureOr<void> sendContactFormEvent(
      SendContactFormEvent event, Emitter<ContactState> emit) async {
    emit(ContactState(status: ContactStatus.loading));
    try {
      final result = await ContactRepo().contactForm(event.contactModel);
      if (result == '200') {
        emit(ContactState(status: ContactStatus.loaded));
      } else {
        emit(ContactState(
            message: 'Some Error Occurred! Please retry after some time',
            status: ContactStatus.failure));
      }
    } catch (e) {
      emit(ContactState(message: e.toString(), status: ContactStatus.failure));
    }
  }
}
