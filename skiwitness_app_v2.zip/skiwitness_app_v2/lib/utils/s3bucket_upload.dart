import 'dart:io';
import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import 'package:mime/mime.dart';

class S3bucketUpload {
  File? _image;

  Future<String?> getPresignedUrl(File file) async {
    var authUser = await Amplify.Auth.getCurrentUser();
    String cognitoId = authUser.userId;
    print(cognitoId);
    try {
      // Get the file name and determine the file type
      String fileName = file.path.split('/').last;
      String fileType = fileName.endsWith('.png') ||
              fileName.endsWith('.jpg') ||
              fileName.endsWith('.jpeg')
          ? 'image'
          : 'video';

      print('Filetype: $fileType');
      print('Filetype1: ${fileName.split('.').last}');
      print('File name: $fileName');

      // Make the request to get the presigned URL
      Response presignedUrlResponse = await Dio().get(
        'https://c1i5s281d2.execute-api.us-east-1.amazonaws.com/default/imageUploadPresigned?name=$fileName&type=video/mp4&cognitoId=$cognitoId&isVideo=true',
      );

      return presignedUrlResponse.data['uploadURL'];
    } catch (error) {
      print('Error getting presigned url: $error');
      return null;
    }
  }

  // Now, uploading that file to the received presigned url
  Future<String?> uploadFileToPresignedUrl(File file, String presignedUrl) async {
    print('check file pathe-1');
    print(file.path);
    print('check file pathe-1');
    try {
      List<int> fileBytes = await file.readAsBytes();

      var request = http.Request('PUT', Uri.parse(presignedUrl));

      String contentTypeString = file.path.endsWith('.png') ||
              file.path.endsWith('.jpg') ||
              file.path.endsWith('.jpeg')
          ? 'image'
          : 'video';

      // Inside the uploadFileToPresignedUrl method
      String contentType =
          lookupMimeType(file.path) ?? 'application/octet-stream';
      request.headers['Content-Type'] = 'video/mp4';

      // Send file bytes
      request.bodyBytes = fileBytes;

      // Send the request
      var response = await request.send();

      if (response.statusCode == 200) {
        print('File uploaded successfully');
        print(presignedUrl.split('?').first);
        return presignedUrl.split('?').first;
      } else {
        print('Failed to upload the file: ${response.reasonPhrase}');
        return null;
      }
    } catch (error) {
      print('Error uploading file: $error');
      return null;
    }
  }
}
