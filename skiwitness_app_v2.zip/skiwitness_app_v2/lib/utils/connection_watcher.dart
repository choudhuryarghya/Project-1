import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';

class ConnectionWatcher {
  final Function(bool isConnected) onConnectionChanged;

  ConnectionWatcher({required this.onConnectionChanged});

  late StreamSubscription<ConnectivityResult> _subscription;
  bool _isConnected = false;

  void start() {
    _subscription = Connectivity().onConnectivityChanged.listen((event) {
      if (event == ConnectivityResult.mobile ||
          event == ConnectivityResult.wifi) {
        _isConnected = true;
      } else {
        _isConnected = false;
      }
      onConnectionChanged(_isConnected);
    }) as StreamSubscription<ConnectivityResult>;
  }

  void stop() {
    _subscription.cancel();
  }
}
