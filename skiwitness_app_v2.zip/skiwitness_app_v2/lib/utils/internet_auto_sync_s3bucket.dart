// import 'dart:io';
//
// import 'package:amplify_flutter/amplify_flutter.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:sqflite/sqflite.dart';
//
// import '../DB/create_database.dart';
// import '../model/video_info_model.dart';
// typedef void CallbackFunction();
// class S3BucketAutoSync{
//   final CallbackFunction callback;
//
//   // Accept the callback function as an argument
//   S3BucketAutoSync({required this.callback});
//   File? _selectedFile;
//   String? _presignedUrl;
//
//   Future<String?> s3_bucket_auto_sync() async {
//     var authUser = await Amplify.Auth.getCurrentUser();
//     String cognitoId = authUser.userId;
//     DataBase database = DataBase();
//     Database db = await database.initializeDatabase();
//
//     // Fetch data from SharedPreferences
//     // List<VideoInfo>? sharedPreferencesVideos = persons?.map((person) => VideoInfo.fromRawJson(person)).toList();
//
//     // Fetch data from the database
//     List<Map<String, dynamic>> videoData = await db.query('tbl_offline_videos',
//       where: 'sync = ? AND cognitoId = ?',
//       whereArgs: [0, cognitoId],
//     );
//     if(videoData.isNotEmpty){
//       // Iterate through each video and upload it
//       for (var videoMap in videoData) {
//         VideoInfo video = VideoInfo.fromJson(videoMap);
//         File? selectedFile = File(video.filePath); // Adjust this if the file path needs processing
//
//         await _uploadFile(selectedFile, video);
//       }
//     }
//     print(videoData);
//   }
//
//   Future<void> _uploadFile(File? selectedFile, VideoInfo video) async {
//     print("test connection");
//     var connectivityResults = await Connectivity().checkConnectivity();
//     print('Connectivity results: $connectivityResults'); // Debug print
//     if (connectivityResults is List<ConnectivityResult>) {
//       bool noConnection = connectivityResults.contains(ConnectivityResult.none);
//       if (noConnection) {
//         print("No internet connection");
//         // ScaffoldMessenger.of(context).showSnackBar(
//         //   SnackBar(
//         //     content: Text('Please check your internet connection.'),
//         //     backgroundColor: Colors.red,
//         //   ),
//         // );
//         return;
//       }
//     } else {
//       return;
//     }
//
//     // setState(() {
//     //   video.isUploading = true;
//     // });
//
//     if (selectedFile != null) {
//       String? presignedUrl;
//       try {
//         presignedUrl = await s3bucketUpload.getPresignedUrl(selectedFile);
//       } catch (e) {
//         print("Error obtaining presigned URL: $e");
//         // setState(() {
//         //   video.isUploading = false;
//         // });
//         return;
//       }
//
//       if (presignedUrl != null) {
//         var replacedUrl = presignedUrl.replaceFirst(
//             'https://ski-uploads-free.s3.amazonaws.com',
//             'https://dczmr8aignart.cloudfront.net');
//         print(replacedUrl);
//
//
//
//         try {
//           await s3bucketUpload.uploadFileToPresignedUrl(selectedFile, replacedUrl!);
//           await updateVideoColumn(video.name, 'filePath', replacedUrl);
//         } catch (e) {
//           print("Error uploading file: $e");
//         } finally {
//           // setState(() {
//           //   video.isUploading = false;
//           // });
//         }
//       } else {
//         print("Presigned URL is null");
//         // setState(() {
//         //   video.isUploading = false;
//         // });
//       }
//     } else {
//       print("Selected file is null");
//       // setState(() {
//       //   video.isUploading = false;
//       // });
//     }
//   }
//
//   Future<void> updateVideoColumn(
//       String name, String columnName, String? presignedUrl) async {
//     DataBase database = DataBase();
//     Database db = await database.initializeDatabase();
//     Map<String, dynamic> updateData = {columnName: presignedUrl, 'sync': true};
//     await db.update(
//       'tbl_offline_videos',
//       updateData,
//       where: 'name = ?',
//       whereArgs: [name],
//       conflictAlgorithm: ConflictAlgorithm.replace,
//     );
//     callback();
//     print('Column $columnName updated successfully');
//   }
//
// }