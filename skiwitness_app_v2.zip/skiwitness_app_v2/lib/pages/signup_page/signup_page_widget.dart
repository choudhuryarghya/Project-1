import 'package:amplify_auth_cognito/amplify_auth_cognito.dart';
import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:intl_phone_field/phone_number.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:skiwitness_app/pages/login_page/confirmation_code_page_widget.dart';

import '../../../theme/pay_now_theme.dart';
import '../../../theme/pay_now_util.dart';
import '../../../theme/pay_now_widgets.dart';
import 'package:skiwitness_app/pages/dashboard_empty_page/dashboard_empty_page_widget.dart';
import 'package:skiwitness_app/pages/login_page/login_page_widget.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'signup_page_model.dart';
export 'signup_page_model.dart';

class SignupPageWidget extends StatefulWidget {
  const SignupPageWidget({Key? key}) : super(key: key);

  @override
  _SignupPageWidgetState createState() => _SignupPageWidgetState();
}

class _SignupPageWidgetState extends State<SignupPageWidget> {
  late SignupPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  bool _isLoader = false;
  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SignupPageModel());

    _model.mobileController ??= TextEditingController();
    _model.newPasswordController ??= TextEditingController();
    _model.comfirmPasswordController ??= TextEditingController();
    _model.firstNameController ??= TextEditingController();
    _model.lastNameController ??= TextEditingController();
  }
  bool _isPhoneValid = true;
  String countryCode = '91';

  void _signUp() async {
    print(countryCode);
    setState(() {
      _isLoader = true;
    });
    // var email = "harisuresh410@gmail.com";

    try {
      // String? completePhoneNumber = _model.mobileController.completeNumber;
      Map<CognitoUserAttributeKey, String> userAttributes = {
        // CognitoUserAttributeKey.email: email.trim(),  // depending on your Cognito settings, you may add other attributes here
        CognitoUserAttributeKey.middleName: '',
        CognitoUserAttributeKey.name: _model.firstNameController.text +
            '' +
            _model.lastNameController.text,
        // Additional attributes can be added here if needed
      };
      print(_model.mobileController.text.trim());
      String password = _model.comfirmPasswordController.text.trim();
      SignUpResult res = await Amplify.Auth.signUp(
        username: "+"+countryCode+_model.mobileController.text.trim(),
        password: _model.comfirmPasswordController.text.trim(),
        options: CognitoSignUpOptions(userAttributes: userAttributes),
      );
        print(res);
      if (res.isSignUpComplete) {
        print(res.isSignUpComplete);
        setState(() {
          _isLoader = false;
        });
        print("MFA code required. Please check your SMS.");
        // await Navigator.push(
        //   context,
        //   MaterialPageRoute(builder: (context) => ConfirmationCodePageWidget(pageComingFrom: PageComingFrom.LoginScreen,
        //       username: "+91" + _model.mobileController.text.trim(),  // Pass the username to the confirmation page
        //       onConfirmSuccess: () {
        //         print("MFA Verification and login successful!");
        //         // Handle successful verification here, e.g., navigate to main app page
        //       }
        //   )),
        // );
        // Navigate to a confirmation screen or login page
      } else {
        print(res.nextStep.signUpStep);
        if (res.nextStep.signUpStep == AuthSignUpStep.confirmSignUp) {
          setState(() {
            _isLoader = false;
          });
          showMessage(
              context, 'Verification code send Please check your SMS.', 14,
              backgroundColor: Colors.green[400]);
          showDialog(
            context: context, // Pass the current BuildContext
            barrierDismissible: false,
            builder: (BuildContext context) {
              return AlertDialog(
                title: const Text('Success!',

                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 20.0,
                  ),

                ),
                content: const Text(
                  'Verification code send Please check your SMS.',
                  style: TextStyle(
                    color: Colors.black,
                    // fontSize: 20.0,
                  ),
                ),
                backgroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
                actions: <Widget>[
                   TextButton(
                      style: TextButton.styleFrom(
                        textStyle: Theme.of(context).textTheme.labelLarge,
                      ),
                      child: const Text('Ok',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18.0,
                        ),
                      ),
                      onPressed: () async {
                         Navigator.of(context).pop(); // Close the dialog
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ConfirmationCodePageWidget(
                                  pageComingFrom: PageComingFrom.SignUpScreen,
                                  username: "+"+countryCode+_model.mobileController.text.trim(), // Pass the username to the confirmation page
                                  password: '',
                                  onConfirmSuccess: () {
                                    print("MFA Verification and login successful!");
                                    // Handle successful verification here, e.g., navigate to main app page
                                  })),
                        );
                      },
                    ),

                ],
              );
            },
          );

          // Navigate to a confirmation screen or login page
        }
        print("Sign up incomplete, further steps required");
        // Handle next steps required here
      }
    } on AuthException catch (e) {
      setState(() {
        _isLoader = false;
      });

      showDialog(
        context: context, // Pass the current BuildContext
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Error!',

              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),

            ),
            content:  Text(
              e.message,
              style: TextStyle(
                color: Colors.black,
                // fontSize: 20.0,
              ),
            ),
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
            actions: <Widget>[
                TextButton(
                  style: TextButton.styleFrom(
                    textStyle: Theme.of(context).textTheme.labelLarge,
                  ),
                  child: const Text('Ok',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18.0,
                    ),
                  ),
                  onPressed: () async {
                     Navigator.of(context).pop(); // Close the dialog

                  },
                ),

            ],
          );
        },
      );
      // if (e.message ==
      //     "Password did not conform with policy: Password must have lowercase characters") {
      //   print("Password must have lowercase characters");
      //   showMessage(context, 'Password must have lowercase characters', 14,
      //       backgroundColor: Colors.red);
      // } else {
      //   showMessage(context, e.message, 14, backgroundColor: Colors.red);
      // }
      print("Could not sign up - ${e.message}");
    }
  }
  void validatePhone() {
    if (_model.mobileController.text.trim().isEmpty) {
      setState(() {
        _isPhoneValid = false;
      });
    } else {
      setState(() {
        _isPhoneValid = true;
      });
    }
  }
  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
        key: scaffoldKey,
        backgroundColor: PayNowTheme.of(context).secondaryBackground,
        body: ModalProgressHUD(
          inAsyncCall: _isLoader,
          // demo of some additional parameters
          opacity: 0.4,
          blur: 1.5,
          progressIndicator: const CircularProgressIndicator(),
          child: Container(
            width: MediaQuery.of(context).size.width * 1.0,
            height: MediaQuery.of(context).size.height * 1.0,
            // decoration: BoxDecoration(
            //   color: PayNowTheme.of(context).primary,
            //   image: DecorationImage(
            //     fit: BoxFit.cover,
            //     image: Image.asset(
            //       'assets/images/login-bg.png',
            //     ).image,
            //   ),
            // ),
            // color: Colors.white,
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(25.0, screenHeight * 0.05, 25.0, 0.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 40.0, 0.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              AutoSizeText(
                                'Sign up',
                                textAlign: TextAlign.start,
                                style: PayNowTheme.of(context)
                                    .displaySmall
                                    .override(
                                        fontFamily: 'Poppins',
                                        fontSize: 32.0,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  Text(
                                    'Create your account',
                                    textAlign: TextAlign.start,
                                    style: PayNowTheme.of(context)
                                        .displaySmall
                                        .override(
                                            fontFamily: 'Poppins',
                                            fontSize: 15.0,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    // ListView(
                    //   padding: EdgeInsets.zero,
                    //   shrinkWrap: true,
                    //   scrollDirection: Axis.vertical,
                    //   children: [
                    Form(
                      key: _model.formKey,
                      autovalidateMode: AutovalidateMode.disabled,
                      // autovalidateMode: AutovalidateMode.onUserInteraction,
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 50.0, 0.0, 0.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(
                              height: 22,
                            ),
                            TextFormField(
                              decoration: InputDecoration(
                                prefixIcon: Icon(Icons.person),
                                labelText: 'First Name',
                                focusColor: Colors.blue,
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(),
                                ),
                                errorBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.red),
                                ),
                              ),
                              style: PayNowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: PayNowTheme.of(context).primaryText,
                                  ),
                              controller: _model.firstNameController,
                              // validator: _model.firstNameControllerValidator.asValidator(context),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter first name';
                                }
                                return null;
                              },
                            ),
                            SizedBox(
                              height: 22,
                            ),
                            TextFormField(
                              decoration: InputDecoration(
                                prefixIcon: Icon(Icons.person),
                                labelText: 'Last Name',
                                focusColor: Colors.blue,
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(),
                                ),
                                errorBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.red),
                                ),
                              ),
                              style: PayNowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: PayNowTheme.of(context).primaryText,
                                  ),
                              controller: _model.lastNameController,
                              // validator: _model.lastNameControllerValidator.asValidator(context),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter last name';
                                }
                                return null;
                              },
                            ),
                            SizedBox(
                              height: 22,
                            ),
                            IntlPhoneField(
                              controller: _model.mobileController,
                              decoration: InputDecoration(
                                  labelText: 'Mobile Number',
                                  border: OutlineInputBorder(
                                    borderSide: BorderSide(),
                                  ),
                                  errorBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.red),
                                  ),
                                  errorText: !_isPhoneValid ? 'Please enter mobile number' : null,
                                  focusColor: Colors.blue),
                              languageCode: "en",
                              initialCountryCode: "IN",
                              dropdownIcon: Icon(Icons.mobile_friendly),
                              onChanged: (phone) {
                                print(phone.completeNumber);
                                print(phone.number);
                                  validatePhone();  // Call validate on every change
                                _model.mobileControllerValidator
                                    .asValidator(context);

                              },
                              onCountryChanged: (country) {
                                countryCode = country.dialCode;
                                print('Country changed to: ' + country.name);
                              },

                            ),
                            SizedBox(
                              height: 22,
                            ),
                            TextFormField(
                              decoration: InputDecoration(
                                prefixIcon: Icon(Icons.security),
                                labelText: 'Password',
                                focusColor: Colors.blue,
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(),
                                ),
                                errorBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.red),
                                ),
                                suffixIcon: InkWell(
                                  onTap: () => setState(
                                    () => _model.newPasswordVisibility =
                                        !_model.newPasswordVisibility,
                                  ),
                                  focusNode: FocusNode(skipTraversal: true),
                                  child: Icon(
                                    _model.newPasswordVisibility
                                        ? Icons.visibility_outlined
                                        : Icons.visibility_off_outlined,
                                    color: PayNowTheme.of(context).secondary,
                                    size: 20.0,
                                  ),
                                ),
                              ),
                              style: PayNowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: PayNowTheme.of(context).primaryText,
                                  ),
                              controller: _model.newPasswordController,
                              obscureText: !_model.newPasswordVisibility,
                              // validator: _model.newPasswordControllerValidator.asValidator(context),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter password';
                                }
                                return null;
                              },
                            ),
                            SizedBox(
                              height: 22,
                            ),
                            TextFormField(
                              decoration: InputDecoration(
                                prefixIcon: Icon(Icons.security),
                                labelText: 'Confirm Password',
                                focusColor: Colors.blue,
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(),
                                ),
                                errorBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.red),
                                ),
                                suffixIcon: InkWell(
                                  onTap: () => setState(
                                    () => _model.comfirmPasswordVisibility =
                                        !_model.comfirmPasswordVisibility,
                                  ),
                                  focusNode: FocusNode(skipTraversal: true),
                                  child: Icon(
                                    _model.comfirmPasswordVisibility
                                        ? Icons.visibility_outlined
                                        : Icons.visibility_off_outlined,
                                    color: PayNowTheme.of(context).secondary,
                                    size: 20.0,
                                  ),
                                ),
                              ),
                              style: PayNowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: PayNowTheme.of(context).primaryText,
                                  ),
                              controller: _model.comfirmPasswordController,
                              obscureText: !_model.comfirmPasswordVisibility,
                              // validator: _model.comfirmPasswordControllerValidator.asValidator(context),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter confirm password';
                                }
                                return null;
                              },
                            ),
                            SizedBox(
                              height: 22,
                            ),
                          ],
                        ),
                      ),
                    ),
                    //   ],
                    // ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 25.0, 0.0, 20.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                              child: SizedBox( // Use SizedBox to set a maximum width
                                width: MediaQuery.of(context).size.width * 0.8, // Set maximum width as 80% of screen width
                                child: FFButtonWidget(
                            onPressed: () async {
                              // if (_model.mobileController.text.isEmpty) {
                              //   showMessage(
                              //       context, 'Please enter mobile Number!',
                              //       backgroundColor: Colors.red);
                              //   return;
                              // }
                              // print(_model.mobileController.text);
                              // if (_model.newPasswordController.text.isEmpty) {
                              //   showMessage(context, 'Please enter Password!',
                              //       backgroundColor: Colors.red);
                              //   return;
                              // }
                              // if (_model
                              //     .comfirmPasswordController.text.isEmpty) {
                              //   showMessage(
                              //       context, 'Please enter Confirm Password!',
                              //       backgroundColor: Colors.red);
                              //   return;
                              // }

                              // if (_model.formKey.currentState == null ||
                              //     !_model.formKey.currentState!.validate()) {
                              //   return;
                              // }
                              validatePhone();
                              // if (!_isPhoneValid) {
                              //   // showMessage(context, 'Please enter mobile number!', 14, backgroundColor: Colors.red);
                              //   return;
                              // }

                              if (!_model.formKey.currentState!.validate() || !_isPhoneValid) {
                                 return;
                              }
                              if (_model.newPasswordController.text.trim() !=
                                  _model.comfirmPasswordController.text
                                      .trim()) {
                                print('wrong');
                                // showMessage(context,'Password And Confirm Password Miss Match',14,backgroundColor: Colors.red);
                                showDialog(
                                  context: context, // Pass the current BuildContext
                                  barrierDismissible: false,
                                  builder: (BuildContext context) {
                                    return AlertDialog(
                                      title: const Text('Error!',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 20.0,
                                        ),

                                      ),
                                      content: const Text(
                                        'Password And Confirm Password Miss Match.',
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 20.0,
                                        ),
                                      ),
                                      backgroundColor: Colors.white,
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
                                      actions: <Widget>[
                                        Center(
                                          child:   TextButton(
                                            style: TextButton.styleFrom(
                                              textStyle: Theme.of(context).textTheme.labelLarge,
                                            ),
                                            child: const Text('Ok',
                                              style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 18.0,
                                              ),
                                            ),
                                            onPressed: () async {
                                               Navigator.of(context).pop(); // Close the dialog

                                            },
                                          ),
                                        )
                                      ],
                                    );
                                  },
                                );
                                return;
                              }
                              // print('All ok');
                               _signUp();

                              // await Navigator.pushAndRemoveUntil(
                              //   context,
                              //   PageTransition(
                              //     type: PageTransitionType.rightToLeft,
                              //     duration: Duration(milliseconds: 300),
                              //     reverseDuration: Duration(milliseconds: 300),
                              //     child: ConfirmationCodePageWidget(pageComingFrom: PageComingFrom.SignUpScreen, username: "",  // Pass the username to the confirmation page
                              //         onConfirmSuccess: (){}),
                              //   ),
                              //       (r) => false,
                              // );

                              /*await Navigator.push(
                            context,
                            PageTransition(
                              type: PageTransitionType.rightToLeft,
                              duration: Duration(milliseconds: 300),
                              reverseDuration: Duration(milliseconds: 300),
                              child: DashboardEmptyPageWidget(),
                            ),
                          );*/
                            },
                            text: 'Create Account',
                            options: FFButtonOptions(
                              // width: 320.0,
                              height: 50.0,
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              iconPadding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              color: PayNowTheme.of(context).primary,
                              textStyle: PayNowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: Colors.white,
                                    fontSize: 15.0,
                                  ),
                              elevation: 2.0,
                              borderSide: BorderSide(
                                color: Colors.transparent,
                                width: 1.0,
                              ),
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                          ),))
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, screenHeight * 0.05),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              await Navigator.push(
                                context,
                                PageTransition(
                                  type: PageTransitionType.rightToLeft,
                                  duration: Duration(milliseconds: 300),
                                  reverseDuration: Duration(milliseconds: 300),
                                  child: LoginPageWidget(),
                                ),
                              );
                            },
                            child: Text(
                              'Already have account?',
                              style: PayNowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Poppins',
                                    color: PayNowTheme.of(context).primary,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ));
  }

  void showMessage(BuildContext context, String message, double size,
      {Color? backgroundColor}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: PayNowTheme.of(context).titleSmall.override(
              fontFamily: 'Poppins', color: Colors.white, fontSize: size),
        ),
        duration: Duration(milliseconds: 4000),
        backgroundColor: backgroundColor ?? PayNowTheme.of(context).primary,
      ),
    );
  }
}
