import 'dart:async';
import 'dart:io';

import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:skiwitness_app/model/video_info_model.dart';
import 'package:skiwitness_app/pages/camera_demo/video_player.dart';
import 'package:skiwitness_app/widgets/timer_widget.dart';
import 'package:sqflite/sqflite.dart';

import '../../../theme/pay_now_theme.dart';
import '../../../theme/pay_now_util.dart';
import '../../../theme/pay_now_widgets.dart';
import '../../DB/create_database.dart';
import '../../utils/s3bucket_upload.dart';
import '/main.dart';
import 'package:skiwitness_app/pages/expemses_trans_page/expemses_trans_page_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'offline_videos_page_model.dart';
export 'offline_videos_page_model.dart';

class OfflineVideoRecordsWidget extends StatefulWidget {
  const OfflineVideoRecordsWidget({Key? key}) : super(key: key);

  @override
  _OfflineVideoRecordsWidgetState createState() =>
      _OfflineVideoRecordsWidgetState();
}

class _OfflineVideoRecordsWidgetState extends State<OfflineVideoRecordsWidget> {
  late IncomeTransPageModel _model;
  final S3bucketUpload s3bucketUpload = S3bucketUpload();
  File? _selectedFile;
  String? _presignedUrl;
  final scaffoldKey = GlobalKey<ScaffoldState>();
  List<VideoInfo> offlineVideos = [];
  bool _isUploading = false;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => IncomeTransPageModel());
    _timer = Timer.periodic(Duration(seconds: 5), _onTimerTick);
    getOfflineVideos().then((value) {
      setState(() {
        offlineVideos = value ?? [];
      });
    });
  }
Future<void> _onTimerTick(Timer timer) async {
    // Call your function here
    // final OfflineVideoRecordsWidget _s3BucketAutoSync = OfflineVideoRecordsWidget();
     String? result = await s3_bucket_auto_sync();
    // print('Automatic function call every 5 seconds');
  }
 void callback(){
   getOfflineVideos().then((value) {
     setState(() {
       offlineVideos = value ?? [];
     });
   });
 }

  Future<void> _uploadFile(File? selectedFile, VideoInfo video) async {
    print("test connection");
    // try {
    var connectivityResults = await Connectivity().checkConnectivity();
    // Debug print to show connectivity results
    print('Connectivity results: $connectivityResults'); // Debug print
    if (connectivityResults is List<ConnectivityResult>) {
      bool noConnection = connectivityResults.contains(ConnectivityResult.none);
      if (noConnection) {
        print("No internet connection");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Please check your internet connection.'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }
    } else {
      return;
    }

    setState(() {
      video.isUploading = true;
    });

    if (selectedFile != null) {
      String? presignedUrl;
      try {
        presignedUrl = await s3bucketUpload.getPresignedUrl(selectedFile);
      } catch (e) {
        print("Error obtaining presigned URL: $e");
        setState(() {
          video.isUploading = false;
        });
        return;
      }

      if (presignedUrl != null) {
        var replacedUrl = presignedUrl.replaceFirst(
            'https://ski-uploads-free.s3.amazonaws.com',
            'https://dczmr8aignart.cloudfront.net');
        print(replacedUrl);

        setState(() {
          _presignedUrl = replacedUrl;
        });

        try {
          await s3bucketUpload.uploadFileToPresignedUrl(
              selectedFile, _presignedUrl!);
          await updateVideoColumn(video.name, 'filePath', replacedUrl);
          // ScaffoldMessenger.of(context).showSnackBar(
          //   SnackBar(
          //     content: Text('File uploaded successfully!'),
          //     backgroundColor: Colors.white,
          //   ),
          // );
          // Show success message
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text('Success'),
                content: Text('File uploaded successfully!'),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text('OK'),
                  ),
                ],
              );
            },
          );
        } catch (e) {
          print("Error uploading file: $e");
        } finally {
          setState(() {
            video.isUploading = false;
          });
        }
      } else {
        print("Presigned URL is null");
        setState(() {
          video.isUploading = false;
        });
      }
    } else {
      print("Selected file is null");
      setState(() {
        video.isUploading = false;
      });
    }
  }

  Future<void> updateVideoColumn(
      String name, String columnName, String? presignedUrl) async {
    DataBase database = DataBase();
    Database db = await database.initializeDatabase();
    // Build the map for the column update
    Map<String, dynamic> updateData = {columnName: presignedUrl, 'sync': true};
    // Update the specific column for the video with the given id
    await db.update(
      'tbl_offline_videos',
      updateData,
      where: 'name = ?',
      whereArgs: [name],
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    // Refresh the list of offline videos
    setState(() {
      // Fetch the updated list of offline videos
      getOfflineVideos().then((value) {
        setState(() {
          offlineVideos = value ?? [];
        });
      });
    });
    print('Column $columnName updated successfully');
  }


  Future<String?> s3_bucket_auto_sync() async {
    var authUser = await Amplify.Auth.getCurrentUser();
    String cognitoId = authUser.userId;
    DataBase database = DataBase();
    Database db = await database.initializeDatabase();

    // Fetch data from SharedPreferences
    // List<VideoInfo>? sharedPreferencesVideos = persons?.map((person) => VideoInfo.fromRawJson(person)).toList();

    // Fetch data from the database
    List<Map<String, dynamic>> videoData = await db.query('tbl_offline_videos',
      where: 'sync = ? AND cognitoId = ?',
      whereArgs: [0, cognitoId],
    );
    if(videoData.isNotEmpty){
      // Iterate through each video and upload it
      for (var videoMap in videoData) {
        VideoInfo video = VideoInfo.fromJson(videoMap);
        File? selectedFile = File(video.filePath); // Adjust this if the file path needs processing

        await _uploadFileAuto(selectedFile, video);
      }
    }
    // print(videoData);
  }

  Future<void> _uploadFileAuto(File? selectedFile, VideoInfo video) async {
    print("test connection");
    var connectivityResults = await Connectivity().checkConnectivity();
    print('Connectivity results: $connectivityResults'); // Debug print
    if (connectivityResults is List<ConnectivityResult>) {
      bool noConnection = connectivityResults.contains(ConnectivityResult.none);
      if (noConnection) {
        print("No internet connection");
        // ScaffoldMessenger.of(context).showSnackBar(
        //   SnackBar(
        //     content: Text('Please check your internet connection.'),
        //     backgroundColor: Colors.red,
        //   ),
        // );
        return;
      }
    } else {
      return;
    }

    // setState(() {
    //   video.isUploading = true;
    // });

    if (selectedFile != null) {
      String? presignedUrl;
      try {
        presignedUrl = await s3bucketUpload.getPresignedUrl(selectedFile);
      } catch (e) {
        print("Error obtaining presigned URL: $e");
        // setState(() {
        //   video.isUploading = false;
        // });
        return;
      }

      if (presignedUrl != null) {
        var replacedUrl = presignedUrl.replaceFirst(
            'https://ski-uploads-free.s3.amazonaws.com',
            'https://dczmr8aignart.cloudfront.net');
        print(replacedUrl);



        try {
          await s3bucketUpload.uploadFileToPresignedUrl(selectedFile, replacedUrl!);
          await updateVideoColumnAuto(video.name, 'filePath', replacedUrl);
        } catch (e) {
          print("Error uploading file: $e");
        } finally {
          // setState(() {
          //   video.isUploading = false;
          // });
        }
      } else {
        print("Presigned URL is null");
        // setState(() {
        //   video.isUploading = false;
        // });
      }
    } else {
      print("Selected file is null");
      // setState(() {
      //   video.isUploading = false;
      // });
    }
  }

  Future<void> updateVideoColumnAuto(
      String name, String columnName, String? presignedUrl) async {
    DataBase database = DataBase();
    Database db = await database.initializeDatabase();
    Map<String, dynamic> updateData = {columnName: presignedUrl, 'sync': true};
    await db.update(
      'tbl_offline_videos',
      updateData,
      where: 'name = ?',
      whereArgs: [name],
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
    callback();
    print('Column $columnName updated successfully');
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: PayNowTheme.of(context).secondaryBackground,
      appBar: AppBar(
        backgroundColor: PayNowTheme.of(context).secondaryBackground,
        iconTheme: IconThemeData(color: Colors.black),
        automaticallyImplyLeading: true,
        leading: InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            await Navigator.pushAndRemoveUntil(
              context,
              PageTransition(
                type: PageTransitionType.rightToLeft,
                duration: Duration(milliseconds: 300),
                reverseDuration: Duration(milliseconds: 300),
                child: NavBarPage(initialPage: 'DashboardPage'),
              ),
              (r) => false,
            );
          },
          child: Icon(
            Icons.arrow_back_ios,
            color: PayNowTheme.of(context).primaryText,
            size: 24.0,
          ),
        ),
        title: Text(
          'Offline Videos',
          style: PayNowTheme.of(context).titleMedium.override(
                fontFamily: 'Poppins',
                color: PayNowTheme.of(context).primaryText,
                fontSize: 18.0,
              ),
        ),
        actions: [
          RemainingTimer(
            timerColor: Colors.green,
          ),
        ],
        centerTitle: true,
        elevation: 0.0,
      ),
      floatingActionButton: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 5.0, 0.0),
        child: FFButtonWidget(
          onPressed: () async {
            await Navigator.pushAndRemoveUntil(
              context,
              PageTransition(
                type: PageTransitionType.rightToLeft,
                duration: Duration(milliseconds: 300),
                reverseDuration: Duration(milliseconds: 300),
                child: NavBarPage(initialPage: 'ContactListPage'),
              ),
              (r) => false,
            );
          },
          text: 'Upload All',
          icon: Icon(
            Icons.sync,
            size: 20.0,
          ),
          options: FFButtonOptions(
            width: 160.0,
            height: 40.0,
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
            iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
            color: PayNowTheme.of(context).secondary,
            textStyle: PayNowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Poppins',
                  color: Colors.black,
                ),
            elevation: 2.0,
            borderSide: BorderSide(
              color: Colors.transparent,
              width: 1.0,
            ),
            borderRadius: BorderRadius.circular(10.0),
          ),
        ),
      ),
      body: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Expanded(
            flex: 2,
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
              child: ListView.builder(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                itemCount: offlineVideos.length,
                itemBuilder: (context, index) {
                  return _buildRecordedVideoItem(context, offlineVideos[index]);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecordedVideoItem(BuildContext context, VideoInfo offlineVideo) {
    DateFormat dateFormat = DateFormat("yyyy-MM-ddTHH:mm:ss.SSS");
    DateTime dateTime = dateFormat.parse(offlineVideo.datetime);
    String thumbnailUrl = offlineVideo.thumbnail;
    String formattedDate = DateFormat('MMM dd, hh:mm aa').format(dateTime);
    String dummyImagePath = 'assets/video-placeholder.jpg';
    File thumbnailFile = File(thumbnailUrl);
    bool isThumbnailValid = thumbnailUrl.isNotEmpty && thumbnailFile.existsSync();
    return InkWell(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => VideoPage(
                videoFile: offlineVideo.filePath.startsWith('https')
                    ? offlineVideo.filePath
                    : File(offlineVideo.filePath)),
          ),
        );
      },
      child: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
        child: Container(
          width: MediaQuery.of(context).size.width * 1.0,
          height: 80.0,
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: MediaQuery.of(context).size.width * 0.2,
                height: 100.0,
                decoration: BoxDecoration(),
                child: Container(
                  width: 80.0,
                  height: 80.0,
                  margin: EdgeInsets.all(8),
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      borderRadius: BorderRadius.all(Radius.circular(10))),
                  child:  isThumbnailValid
                      ? Image.file(
                    thumbnailFile,
                    fit: BoxFit.cover,
                  )
                      : Image.asset(
                    dummyImagePath,
                    fit: BoxFit.cover,
                  ),
                  // Image.file(
                  //   File(offlineVideo.thumbnail),
                  //   fit: BoxFit.cover,
                  // ),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.4,
                margin: EdgeInsets.only(left: 2),
                height: 100.0,
                decoration: BoxDecoration(),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      offlineVideo.name,
                      style: PayNowTheme.of(context).titleSmall.override(
                            fontFamily: 'Poppins',
                            color: PayNowTheme.of(context).primaryText,
                          ),
                    ),
                    Text(
                      formattedDate,
                      style: PayNowTheme.of(context).titleSmall.override(
                            fontFamily: 'Poppins',
                            color: PayNowTheme.of(context).secondaryText,
                            fontSize: 14.0,
                          ),
                    ),
                  ],
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width * 0.35,
                height: 100.0,
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.end,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Visibility(
                      visible: !offlineVideo.sync, // Show if not synced
                      child: IconButton(
                        onPressed: () {
                          File selectedFile = File(offlineVideo.filePath);
                          _uploadFile(selectedFile, offlineVideo);
                        },
                        icon: offlineVideo.isUploading
                            ? CircularProgressIndicator(color: Colors.yellow.shade900,)
                            : Icon(
                                Icons.cloud_upload_sharp,
                                color: Colors.yellow.shade900,
                                size: 28,
                              ),
                      ),
                    ),
                    IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Icons.share_rounded,
                        color: Colors.yellow.shade700,
                        size: 28,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
