import '../../../theme/pay_now_theme.dart';
import '../../../theme/pay_now_util.dart';
import '../../../theme/pay_now_widgets.dart';
import '/main.dart';
import 'package:skiwitness_app/pages/expemses_trans_page/expemses_trans_page_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'income_trans_page_model.dart';
export 'income_trans_page_model.dart';

class IncomeTransPageWidget extends StatefulWidget {
  const IncomeTransPageWidget({Key? key}) : super(key: key);

  @override
  _IncomeTransPageWidgetState createState() => _IncomeTransPageWidgetState();
}

class _IncomeTransPageWidgetState extends State<IncomeTransPageWidget> {
  late IncomeTransPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => IncomeTransPageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: PayNowTheme.of(context).secondaryBackground,
      appBar: AppBar(
        backgroundColor: PayNowTheme.of(context).secondaryBackground,
        iconTheme: IconThemeData(color: Colors.black),
        automaticallyImplyLeading: true,
        leading: InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            await Navigator.pushAndRemoveUntil(
              context,
              PageTransition(
                type: PageTransitionType.rightToLeft,
                duration: Duration(milliseconds: 300),
                reverseDuration: Duration(milliseconds: 300),
                child: NavBarPage(initialPage: 'DashboardPage'),
              ),
              (r) => false,
            );
          },
          child: Icon(
            Icons.arrow_back_ios,
            color: PayNowTheme.of(context).primaryText,
            size: 24.0,
          ),
        ),
        title: Text(
          'Offline Videos',
          style: PayNowTheme.of(context).titleMedium.override(
                fontFamily: 'Poppins',
                color: PayNowTheme.of(context).primaryText,
                fontSize: 18.0,
              ),
        ),
        actions: [],
        centerTitle: true,
        elevation: 0.0,
      ),
      floatingActionButton: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 5.0, 0.0),
        child: FFButtonWidget(
          onPressed: () async {
            await Navigator.pushAndRemoveUntil(
              context,
              PageTransition(
                type: PageTransitionType.rightToLeft,
                duration: Duration(milliseconds: 300),
                reverseDuration: Duration(milliseconds: 300),
                child: NavBarPage(initialPage: 'ContactListPage'),
              ),
              (r) => false,
            );
          },
          text: 'Upload All',
          icon: Icon(
            Icons.sync,
            size: 20.0,
          ),
          options: FFButtonOptions(
            width: 160.0,
            height: 40.0,
            padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
            iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
            color: PayNowTheme.of(context).secondary,
            textStyle: PayNowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Poppins',
                  color: Colors.black,
                ),
            elevation: 2.0,
            borderSide: BorderSide(
              color: Colors.transparent,
              width: 1.0,
            ),
            borderRadius: BorderRadius.circular(10.0),
          ),
        ),
      ),
      body: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Expanded(
            flex: 2,
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
              child: ListView(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                children: [
                  _buildRecordedVideoItem(context),
                  _buildRecordedVideoItem(context),
                  _buildRecordedVideoItem(context),
                  _buildRecordedVideoItem(context),
                  _buildRecordedVideoItem(context),
                  _buildRecordedVideoItem(context),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Padding _buildRecordedVideoItem(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
      child: Container(
        width: MediaQuery.of(context).size.width * 1.0,
        height: 80.0,
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: MediaQuery.of(context).size.width * 0.2,
              height: 100.0,
              decoration: BoxDecoration(),
              child: Container(
                width: 80.0,
                height: 80.0,
                margin: EdgeInsets.all(8),
                clipBehavior: Clip.antiAlias,
                decoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.all(Radius.circular(10))),
                child: Image.asset(
                  'assets/images/logo.png',
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.4,
              margin: EdgeInsets.only(left: 2),
              height: 100.0,
              decoration: BoxDecoration(),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Video Name',
                    style: PayNowTheme.of(context).titleSmall.override(
                          fontFamily: 'Poppins',
                          color: PayNowTheme.of(context).primaryText,
                        ),
                  ),
                  Text(
                    'Oct 14, 10:24 AM',
                    style: PayNowTheme.of(context).titleSmall.override(
                          fontFamily: 'Poppins',
                          color: PayNowTheme.of(context).secondaryText,
                          fontSize: 14.0,
                        ),
                  ),
                ],
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width * 0.35,
              height: 100.0,
              child: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.cloud_upload_sharp,
                      color: Colors.yellow.shade900,
                      size: 28,
                    ),
                  ),
                  IconButton(
                    onPressed: () {},
                    icon: Icon(
                      Icons.share_rounded,
                      color: Colors.yellow.shade700,
                      size: 28,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
