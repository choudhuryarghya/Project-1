import 'dart:convert';

import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:flutter/services.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skiwitness_app/pages/contact_list_page/contact_list_page_widget.dart';
import 'package:skiwitness_app/theme/pay_now_widgets.dart';

import '../../../theme/pay_now_theme.dart';
import '../../../theme/pay_now_util.dart';
import '../login_page/login_page_widget.dart';
import '../resetpassword_page/resetpassword_page_model.dart';
import '/main.dart';
import 'package:skiwitness_app/pages/mycard_page/mycard_page_widget.dart';
import 'package:skiwitness_app/pages/profileedit_page/profileedit_page_widget.dart';
import 'package:skiwitness_app/pages/settings_page/settings_page_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'profile_page_model.dart';
export 'profile_page_model.dart';
import 'package:http/http.dart' as http;

class ResetPasswordPageWidget extends StatefulWidget {
  const ResetPasswordPageWidget({Key? key}) : super(key: key);

  @override
  _ResetPasswordPageWidgetState createState() =>
      _ResetPasswordPageWidgetState();
}

class _ResetPasswordPageWidgetState extends State<ResetPasswordPageWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final formKey = GlobalKey<FormState>(); // GlobalKey for the Form
  late ResetpasswordPageModel _model;
  bool _isLoader = false;
  String userName = '';
  String phoneNumber = '';
  final _codeController = TextEditingController();
  late TextEditingController mobileController; // Declare but don't initialize yet
  @override
  void initState() {
    fetchUserDetails();
    super.initState();
    _model = createModel(context, () => ResetpasswordPageModel());
    // _model.mobileController ??= TextEditingController(text: phoneNumber);
    _model.passwordController ??= TextEditingController();
  }

  fetchUserDetails() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userDetailsString = prefs.getString('userDetails');
    print(userDetailsString);
    if(userDetailsString != null) {
      Map<String, dynamic> userDetails = json.decode(userDetailsString);
      setState(() {
        userName = userDetails['user']['first_name'];
        phoneNumber = userDetails['user']['userName'];
        mobileController = TextEditingController(text: phoneNumber); // Initialize mobileController here
      });

      print(phoneNumber);
    }else{
      var authUser = await Amplify.Auth.getCurrentUser();
      print(authUser);
      String cognitoId = authUser.userId;
      print('just-test-2');
      final url = 'https://3ghvmpumdb.execute-api.us-east-1.amazonaws.com/default/getUserDetails?cognitoId='+cognitoId;

      final response = await http.get(Uri.parse(url));
      print('just-test-3');
      if (response.statusCode == 200) {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('userDetails', response.body);
        Map<String, dynamic> userDetails = json.decode(response.body);
        setState(() {
          userName = userDetails['user']['first_name'];
          phoneNumber = userDetails['user']['userName'];
          mobileController = TextEditingController(text: phoneNumber); // Initialize mobileController here
        });
      } else {
        throw Exception('Failed to load user details');
      }
    }
  }

  Future<void> confirmResetPassword() async {
    print(phoneNumber);
    print(_model.passwordController.text);
    print(_codeController.text);
    setState(() {
      _isLoader = true;
    });
    try {
      final result = await Amplify.Auth.confirmResetPassword(
          username: phoneNumber,
          newPassword: _model.passwordController.text,
          confirmationCode: _codeController.text
      );
      // print('test1');
      // print(result);
      // print('test2');
      if(result.isPasswordReset){
        setState(() {
          _isLoader = false;
        });
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setBool('isLogin', false);
        // To remove user details (on logout)
        await prefs.remove('userDetails');
        // To remove user details (on logout)
        await prefs.remove('isPassword');
        Amplify.Auth.signOut();
        showDialog(
          context: context, // Pass the current BuildContext
          barrierDismissible: false,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Success!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20.0,
                ),
              ),
              content: const Text(
                'You\'ve successfully reset your password.',
                style: TextStyle(
                  color: Colors.black,
                  // fontSize: 20.0,
                ),
              ),
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
              actions: <Widget>[
                TextButton(
                  style: TextButton.styleFrom(
                    textStyle: Theme.of(context).textTheme.labelLarge,
                  ),
                  child: const Text('Ok',
                    style: TextStyle(
                      color: Colors.black,
                      // fontSize: 20.0,
                    ),
                  ),
                  onPressed: () async {
                     Navigator.of(context).pop(); // Close the dialog


                    Navigator.pushAndRemoveUntil(
                      context,
                      PageTransition(
                        type: PageTransitionType.rightToLeft,
                        duration: Duration(milliseconds: 300),
                        reverseDuration: Duration(milliseconds: 300),
                        child: LoginPageWidget(),
                      ),
                          (r) => false,
                    );
                  },
                ),
              ],
            );
          },
        );
      }
      // await Navigator.push(
      //   context,
      //   PageTransition(
      //     type: PageTransitionType.rightToLeft,
      //     duration: Duration(milliseconds: 300),
      //     reverseDuration: Duration(milliseconds: 300),
      //     child: LoginPageWidget(),
      //   ),
      // );
    } on AmplifyException catch (e) {
      setState(() {
        _isLoader = false;
      });
      print(e.message);
      // if(e.message == 'Username/client id combination not found.'){
      //   showMessage(context, e.message,15, backgroundColor: Colors.red);
      showDialog(
        context: context, // Pass the current BuildContext
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('error!',

              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),

            ),
            content:  Text(
              e.message,
              style: TextStyle(
                color: Colors.black,
                // fontSize: 20.0,
              ),
            ),
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
            actions: <Widget>[
              TextButton(
                style: TextButton.styleFrom(
                  textStyle: Theme.of(context).textTheme.labelLarge,
                ),
                child: const Text('Ok',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                  ),
                ),
                onPressed: () async {
                  Navigator.of(context).pop(); // Close the dialog

                },
              ),

            ],
          );
        },
      );
      //   safePrint(e.message);
      // }else{
      //   showMessage(context, e.message,15, backgroundColor: Colors.red);
      // }
    }
  }
  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: PayNowTheme.of(context).secondaryBackground,
      appBar: AppBar(
        backgroundColor: PayNowTheme.of(context).secondaryBackground,
        automaticallyImplyLeading: false,
        leading: InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            Navigator.pop(context);
          },
          child: Icon(
            Icons.arrow_back_ios,
            color: PayNowTheme.of(context).primaryText,
            size: 24.0,
          ),
        ),
        title: Text(
          'Reset Password',
          style: PayNowTheme.of(context).titleMedium.override(
                fontFamily: 'Poppins',
                color: PayNowTheme.of(context).primaryText,
                fontSize: 18.0,
              ),
        ),
        actions: [],
        centerTitle: true,
        elevation: 0.0,
      ),
      body: Form(
    key: formKey, child:  Column( // Wrap with Column
          children: [
      Expanded(
    child:   ListView(
        padding: EdgeInsets.all(12),
        children: [
          Container(
            width: MediaQuery.of(context).size.width * 1.0,
            height: 190.0,
            decoration: BoxDecoration(
              color: PayNowTheme.of(context).secondaryBackground,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      width: 90.0,
                      height: 120.0,
                      clipBehavior: Clip.antiAlias,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                      ),
                      child: SvgPicture.asset(
                        'assets/images/PPavater.svg',
                      ),
                    ),
                  ],
                ),
                Text(
                  userName,
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  '',
                  style: PayNowTheme.of(context).titleSmall.override(
                      fontFamily: 'Poppins',
                      color: PayNowTheme.of(context).primaryText,
                      fontWeight: FontWeight.w800),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          // IntlPhoneField(
          //   decoration: InputDecoration(
          //       labelText: 'Mobile Number',
          //       border: OutlineInputBorder(
          //         borderSide: BorderSide(),
          //       ),
          //       focusColor: Colors.blue),
          //   languageCode: "en",
          //   initialCountryCode: "IN",
          //   dropdownIcon: Icon(Icons.mobile_friendly),
          //   onChanged: (phone) {
          //     print(phone.completeNumber);
          //   },
          //   onCountryChanged: (country) {
          //     print('Country changed to: ' + country.name);
          //   },
          //   enabled: false,
          //   initialValue: '6381160852',
          // ),
          TextFormField(
            controller: mobileController,
            enabled: false,
            decoration: InputDecoration(
              prefixIcon: Icon(Icons.phone_android),
              labelText: 'Mobile Number',
              focusColor: Colors.blue,
              border: OutlineInputBorder(
                borderSide: BorderSide(),
              ),
              errorBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.red),
              ),
            ),
            style: PayNowTheme.of(context).bodyMedium.override(
              fontFamily: 'Poppins',
              color: PayNowTheme.of(context).primaryText,
            ),

          ),
          SizedBox(
            height: 22,
          ),
          TextFormField(
            controller: _codeController,
            decoration: InputDecoration(
              prefixIcon: Icon(Icons.lock),
              labelText: 'Confirmation Code',
              focusColor: Colors.blue,
              border: OutlineInputBorder(
                borderSide: BorderSide(),
              ),
              errorBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.red),
              ),
            ),
            style: PayNowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Poppins',
                  color: PayNowTheme.of(context).primaryText,
                ),
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            keyboardType: TextInputType.number,
            maxLength: 6,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter a confirmation code';
              }
              return null;
            },
          ),
          SizedBox(
            height: 22,
          ),
          TextFormField(
            controller: _model.passwordController,
            decoration: InputDecoration(
              prefixIcon: Icon(Icons.security),
              labelText: 'New Password',
              focusColor: Colors.blue,
              border: OutlineInputBorder(
                borderSide: BorderSide(),
              ),
              errorBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.red),
              ),
              suffixIcon: InkWell(
                onTap: () => setState(
                  () => newPasswordVisibility = !newPasswordVisibility,
                ),
                focusNode: FocusNode(skipTraversal: true),
                child: Icon(
                  newPasswordVisibility
                      ? Icons.visibility_outlined
                      : Icons.visibility_off_outlined,
                  color: PayNowTheme.of(context).secondary,
                  size: 20.0,
                ),
              ),
            ),
            style: PayNowTheme.of(context).bodyMedium.override(
                  fontFamily: 'Poppins',
                  color: PayNowTheme.of(context).primaryText,
                ),
            obscureText: !newPasswordVisibility,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter a new password';
              }
              return null;
            },
          ),
          SizedBox(
            height: 42,
          ),
          // Expanded(
          //     child:
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: _confirmButton(context),
              )
    // ),
        ],
      ),
    )
    ]
    )));
  }

  FFButtonWidget _confirmButton(BuildContext context) {
    return FFButtonWidget(
      onPressed: () async {
        if (formKey.currentState!.validate()) {
          // If the form is valid, perform your action
          confirmResetPassword();
        }
        // await Navigator.pushAndRemoveUntil(
        //   context,
        //   PageTransition(
        //     type: PageTransitionType.rightToLeft,
        //     duration: Duration(milliseconds: 300),
        //     reverseDuration: Duration(milliseconds: 300),
        //     child: NavBarPage(initialPage: 'DashboardPage'),
        //   ),
        //       (r) => false,
        // );
        // ScaffoldMessenger.of(context).showSnackBar(
        //   SnackBar(
        //     content: Text(
        //       'Action Completed ',
        //       style: PayNowTheme.of(context).titleSmall.override(
        //         fontFamily: 'Poppins',
        //         color: Colors.white,
        //       ),
        //     ),
        //     duration: Duration(milliseconds: 4000),
        //     backgroundColor: PayNowTheme.of(context).primary,
        //   ),
        // );
      },
      text: 'Submit',
      options: FFButtonOptions(
        height: 50.0,
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
        iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
        color: PayNowTheme.of(context).primary,
        textStyle: PayNowTheme.of(context).headlineSmall.override(
          fontFamily: 'Poppins',
          color: Colors.white,
          fontSize: 15.0,
        ),
        elevation: 2.0,
        borderSide: BorderSide(
          color: Colors.transparent,
          width: 1.0,
        ),
        borderRadius: BorderRadius.circular(10.0),
      ),
    );
  }

  bool newPasswordVisibility = false;
}
