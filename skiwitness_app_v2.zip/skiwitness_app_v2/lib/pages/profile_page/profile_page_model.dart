import '../../../theme/pay_now_util.dart';
import 'package:flutter/material.dart';

class ProfilePageModel extends PayNowModel {
  /// Initialization and disposal methods.

  void initState(BuildContext context) {}

  void dispose() {}

  /// Additional helper methods are added here.
}
