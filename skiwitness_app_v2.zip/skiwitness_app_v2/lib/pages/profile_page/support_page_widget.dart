import 'dart:developer';

import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:skiwitness_app/bloc/contact_bloc/contact_bloc.dart';
import 'package:skiwitness_app/model/contact_model.dart';
import 'package:skiwitness_app/theme/pay_now_widgets.dart';

import '../../../theme/pay_now_theme.dart';

export 'profile_page_model.dart';

class SupportPageWidget extends StatefulWidget {
  const SupportPageWidget({super.key});

  @override
  _SupportPageWidgetState createState() => _SupportPageWidgetState();
}

class _SupportPageWidgetState extends State<SupportPageWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  TextEditingController messageTextEditingController = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<ContactBloc, ContactState>(
      listener: (context, state) {
        if (state.status == ContactStatus.loaded) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                'Your message has been delivered. The support team will be contacting you soon.',
                style: PayNowTheme.of(context).titleSmall.override(
                      fontFamily: 'Poppins',
                      color: Colors.white,
                    ),
              ),
              backgroundColor: PayNowTheme.of(context).primary,
            ),
          );
          messageTextEditingController.clear();
        } else if (state.status == ContactStatus.failure) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content:
                  Text('Some Error Occurred! Please retry after some time')));
        }
      },
      builder: (context, state) {
        return Scaffold(
          key: scaffoldKey,
          backgroundColor: PayNowTheme.of(context).secondaryBackground,
          appBar: AppBar(
            backgroundColor: PayNowTheme.of(context).secondaryBackground,
            automaticallyImplyLeading: false,
            leading: InkWell(
              splashColor: Colors.transparent,
              focusColor: Colors.transparent,
              hoverColor: Colors.transparent,
              highlightColor: Colors.transparent,
              onTap: () async {
                Navigator.pop(context);
              },
              child: Icon(
                Icons.arrow_back_ios,
                color: PayNowTheme.of(context).primaryText,
                size: 24.0,
              ),
            ),
            title: Text(
              'Support',
              style: PayNowTheme.of(context).titleMedium.override(
                    fontFamily: 'Poppins',
                    color: PayNowTheme.of(context).primaryText,
                    fontSize: 18.0,
                  ),
            ),
            actions: const [],
            centerTitle: true,
            elevation: 0.0,
          ),
          body: ListView(
            children: [
              Container(
                width: MediaQuery.of(context).size.width * 1.0,
                height: 160.0,
                decoration: BoxDecoration(
                  color: PayNowTheme.of(context).secondaryBackground,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          width: 90.0,
                          height: 90.0,
                          clipBehavior: Clip.antiAlias,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                          ),
                          child: SvgPicture.asset(
                            'assets/images/PPavater.svg',
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Text(
                      '',
                      style: PayNowTheme.of(context).titleSmall.override(
                          fontFamily: 'Poppins',
                          color: PayNowTheme.of(context).primaryText,
                          fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextFormField(
                  controller: messageTextEditingController,
                  decoration: const InputDecoration(
                    labelText: 'Message',
                    focusColor: Colors.blue,
                    border: OutlineInputBorder(
                      borderSide: BorderSide(),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.red),
                    ),
                  ),
                  minLines: 5,
                  maxLines: 8,
                  style: PayNowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Poppins',
                        color: PayNowTheme.of(context).primaryText,
                      ),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Expanded(
                  child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: state.status == ContactStatus.loading
                    ? const Center(child: CircularProgressIndicator())
                    : _sendButton(context),
              )),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                  'Customer service hours are M-F 8 am - 5 pm MT. If you email or call after these hours you will be contacted by the next  business day',
                  style: PayNowTheme.of(context).titleSmall.override(
                      fontFamily: 'Poppins',
                      color: Colors.white,
                      fontWeight: FontWeight.w800),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  leading: const Icon(Icons.email),
                  title: Text(
                    'angie@datavise.com',
                    style: PayNowTheme.of(context).titleSmall.override(
                        fontFamily: 'Poppins',
                        color: Colors.white,
                        fontWeight: FontWeight.normal),
                  ),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  leading: const Icon(Icons.call),
                  title: Text(
                    'Toll Free (866) 698-4464',
                    style: PayNowTheme.of(context).titleSmall.override(
                        fontFamily: 'Poppins',
                        color: Colors.white,
                        fontWeight: FontWeight.normal),
                  ),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  leading: const Icon(Icons.phone_android),
                  title: Text(
                    'Direct (385) 519-0482 ext 110',
                    style: PayNowTheme.of(context).titleSmall.override(
                        fontFamily: 'Poppins',
                        color: Colors.white,
                        fontWeight: FontWeight.normal),
                  ),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: ListTile(
                  leading: const Icon(Icons.web),
                  title: Text(
                    'www.skiwitness.com',
                    style: PayNowTheme.of(context).titleSmall.override(
                        fontFamily: 'Poppins',
                        color: Colors.white,
                        fontWeight: FontWeight.normal),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  FFButtonWidget _sendButton(BuildContext context) {
    return FFButtonWidget(
      onPressed: () async {
        var authUser = await Amplify.Auth.getCurrentUser();
        String cognitoId = authUser.userId;
        log(cognitoId);
        log(messageTextEditingController.text);
        context.read<ContactBloc>().add(SendContactFormEvent(
            contactModel: (ContactModel(
                cognitoId: cognitoId,
                body: messageTextEditingController.text))));
      },
      text: 'Send',
      options: FFButtonOptions(
        height: 50.0,
        padding: const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
        iconPadding: const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
        color: PayNowTheme.of(context).primary,
        textStyle: PayNowTheme.of(context).headlineSmall.override(
              fontFamily: 'Poppins',
              color: Colors.white,
              fontSize: 15.0,
            ),
        elevation: 2.0,
        borderSide: const BorderSide(
          color: Colors.transparent,
          width: 1.0,
        ),
        borderRadius: BorderRadius.circular(10.0),
      ),
    );
  }

  void showMessage(BuildContext context, String message,
      {Color? backgroundColor}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: PayNowTheme.of(context).titleSmall.override(
                fontFamily: 'Poppins',
                color: Colors.white,
              ),
        ),
        duration: const Duration(milliseconds: 4000),
        backgroundColor: backgroundColor ?? PayNowTheme.of(context).primary,
      ),
    );
  }
}
