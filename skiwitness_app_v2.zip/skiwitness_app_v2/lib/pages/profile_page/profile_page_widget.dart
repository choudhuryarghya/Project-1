import 'dart:convert';
import 'dart:io';

import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skiwitness_app/bloc/profile_image_bloc/profile_image_bloc.dart';
import 'package:skiwitness_app/index.dart';
import 'package:skiwitness_app/pages/profile_page/reset_password_page_widget.dart';
import 'package:skiwitness_app/pages/profile_page/support_page_widget.dart';
import 'package:skiwitness_app/pages/profile_page/web_view_container.dart';
import 'package:skiwitness_app/widgets/timer_widget.dart';

import '/main.dart';
import '../../../theme/pay_now_theme.dart';
import '../../../theme/pay_now_util.dart';

export 'profile_page_model.dart';

class ProfilePageWidget extends StatefulWidget {
  const ProfilePageWidget({super.key});

  @override
  _ProfilePageWidgetState createState() => _ProfilePageWidgetState();
}

class _ProfilePageWidgetState extends State<ProfilePageWidget> {
  File? selectedProfileImage;
  late ProfilePageModel _model;
  String userName = '';
  String phoneNumber = '';
  bool _isLoader = false;
  String profile = '';
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    fetchUserDetails();
    _model = createModel(context, () => ProfilePageModel());
  }

  fetchUserDetails() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userDetailsString = prefs.getString('userDetails');
    print(userDetailsString);
    if (userDetailsString != null) {
      Map<String, dynamic> userDetails = json.decode(userDetailsString);
      print('object: $userDetails');
      setState(() {
        userName = userDetails['user']['first_name'];
        phoneNumber = userDetails['user']['userName'];
        try {
          profile = userDetails['user']['imageUrl'];
        } catch (e) {
          profile = '';
        }
      });
    } else {
      var authUser = await Amplify.Auth.getCurrentUser();
      print(authUser);
      String cognitoId = authUser.userId;
      print('just-test-2');
      final url =
          'https://3ghvmpumdb.execute-api.us-east-1.amazonaws.com/default/getUserDetails?cognitoId=$cognitoId';

      final response = await http.get(Uri.parse(url));
      print('just-test-3');
      if (response.statusCode == 200) {
        // log(response.body);
        SharedPreferences prefs = await SharedPreferences.getInstance();
        // await prefs.setString('userDetails', response.body);
        Map<String, dynamic> userDetails = json.decode(response.body);
        setState(() {
          userName = userDetails['user']['first_name'];
          phoneNumber = userDetails['user']['userName'];
        });
      } else {
        throw Exception('Failed to load user details');
      }
    }
  }

  Future<void> resetPassword() async {
    setState(() {
      _isLoader = true;
    });
    try {
      final result = await Amplify.Auth.resetPassword(
        username: phoneNumber,
      );
      // print(result);
      // print(result.isPasswordReset);
      setState(() {
        _isLoader = false;
      });
      showDialog(
        context: context, // Pass the current BuildContext
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text(
              'Code Send',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),
            ),
            content: const Text(
              'Verification code has been sent to your number. Please check.',
              style: TextStyle(
                color: Colors.black,
                fontSize: 15.0,
              ),
            ),
            backgroundColor: Colors.white,
            shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(2))),
            actions: <Widget>[
              TextButton(
                style: TextButton.styleFrom(
                  textStyle: Theme.of(context).textTheme.labelLarge,
                ),
                child: const Text(
                  'Ok',
                  style: TextStyle(
                    color: Colors.black,
                    // fontSize: 20.0,
                  ),
                ),
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                  Navigator.push(
                    context,
                    PageTransition(
                      type: PageTransitionType.rightToLeft,
                      duration: const Duration(milliseconds: 300),
                      reverseDuration: const Duration(milliseconds: 300),
                      child: const ResetPasswordPageWidget(),
                    ),
                  );
                  // setState(() {
                  //   print(result);
                  //   print(result.isPasswordReset);
                  //   print('hari');
                  //   _confirmCodeNotSend = result.isPasswordReset;
                  // });
                },
              ),
            ],
          );
        },
      );
      // setState(() {
      //    _confirmCodeNotSend = result.isPasswordReset;
      // });
    } on AmplifyException catch (e) {
      setState(() {
        _isLoader = false;
      });
      print(e);
      // if(e.message == 'Username/client id combination not found.'){
      //   showMessage(context, 'Invalid User',20, backgroundColor: Colors.red);
      //   safePrint(e.message);
      // }else{
      //   showMessage(context, e.message,15, backgroundColor: Colors.red);
      // }
      showDialog(
        context: context, // Pass the current BuildContext
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text(
              'Error!',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),
            ),
            content: Text(
              e.message,
              style: const TextStyle(
                color: Colors.black,
                // fontSize: 20.0,
              ),
            ),
            backgroundColor: Colors.white,
            shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(2))),
            actions: <Widget>[
              Center(
                child: TextButton(
                  style: TextButton.styleFrom(
                    textStyle: Theme.of(context).textTheme.labelLarge,
                  ),
                  child: const Text(
                    'Ok',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18.0,
                    ),
                  ),
                  onPressed: () async {
                    Navigator.of(context).pop(); // Close the dialog
                  },
                ),
              )
            ],
          );
        },
      );
    }
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
        inAsyncCall: _isLoader,
        // demo of some additional parameters
        opacity: 0.4,
        blur: 1.5,
        progressIndicator: const CircularProgressIndicator(),
        child: BlocConsumer<ProfileImageBloc, ProfileImageState>(
          listener: (context, state) {
            if (state.status == ProfileImageStatus.loaded) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    'Profile image loaded Successfully!',
                    style: PayNowTheme.of(context).titleSmall.override(
                          fontFamily: 'Poppins',
                          color: Colors.white,
                        ),
                  ),
                  backgroundColor: PayNowTheme.of(context).primary,
                ),
              );
            }
            if (state.status == ProfileImageStatus.failure) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                  content: Text('Something went wrong. Please try later!')));
            }
          },
          builder: (context, state) {
            return Scaffold(
              key: scaffoldKey,
              backgroundColor: const Color(0xFFF1F4F8),
              appBar: AppBar(
                backgroundColor: PayNowTheme.of(context).secondaryBackground,
                automaticallyImplyLeading: false,
                leading: InkWell(
                  splashColor: Colors.transparent,
                  focusColor: Colors.transparent,
                  hoverColor: Colors.transparent,
                  highlightColor: Colors.transparent,
                  onTap: () async {
                    await Navigator.push(
                      context,
                      PageTransition(
                        type: PageTransitionType.rightToLeft,
                        duration: const Duration(milliseconds: 300),
                        reverseDuration: const Duration(milliseconds: 300),
                        child: const NavBarPage(initialPage: 'DashboardPage'),
                      ),
                    );
                  },
                  child: Icon(
                    Icons.arrow_back_ios,
                    color: PayNowTheme.of(context).primaryText,
                    size: 24.0,
                  ),
                ),
                title: Text(
                  'My Profile',
                  style: PayNowTheme.of(context).titleMedium.override(
                        fontFamily: 'Poppins',
                        color: PayNowTheme.of(context).primaryText,
                        fontSize: 18.0,
                      ),
                ),
                actions: const [
                  RemainingTimer(
                    timerColor: Colors.green,
                  )
                ],
                centerTitle: true,
                elevation: 0.0,
              ),
              body: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width * 1.0,
                        height: 160.0,
                        decoration: BoxDecoration(
                          color: PayNowTheme.of(context).secondaryBackground,
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: 90.0,
                                  height: 90.0,
                                  clipBehavior: Clip.antiAlias,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Colors.grey[100],
                                  ),
                                  child: GestureDetector(
                                    onTap: () async {
                                      await _pickImageFromGallery();
                                    },
                                    child: state.status ==
                                            ProfileImageStatus.loading
                                        ? Center(
                                            child: CircularProgressIndicator(
                                              color: Theme.of(context)
                                                  .colorScheme
                                                  .primaryContainer,
                                            ),
                                          )
                                        : selectedProfileImage != null
                                            ? CircleAvatar(
                                                radius: 45,
                                                backgroundImage: FileImage(
                                                    selectedProfileImage!),
                                              )
                                            : profile != ''
                                                ? CircleAvatar(
                                                    radius: 45,
                                                    backgroundImage:
                                                        NetworkImage(profile),
                                                  )
                                                : SvgPicture.asset(
                                                    'assets/images/PPavater.svg',
                                                    placeholderBuilder:
                                                        (BuildContext context) {
                                                      // Placeholder logic based on userName
                                                      String placeholderText =
                                                          userName.isNotEmpty
                                                              ? userName[0]
                                                                  .toUpperCase()
                                                              : '?';

                                                      return Center(
                                                        child: Text(
                                                          placeholderText,
                                                          style: const TextStyle(
                                                              fontSize: 40,
                                                              color: Colors
                                                                  .black), // Adjust the style as needed
                                                        ),
                                                      );
                                                    },
                                                    fit: BoxFit.contain,
                                                  ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Text(
                              userName,
                              style: PayNowTheme.of(context)
                                  .titleSmall
                                  .override(
                                      fontFamily: 'Poppins',
                                      color:
                                          PayNowTheme.of(context).primaryText,
                                      fontWeight: FontWeight.w800),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Expanded(
                    child: Container(
                      width: MediaQuery.of(context).size.width * 1.0,
                      height: MediaQuery.of(context).size.height * 1.0,
                      decoration: BoxDecoration(
                        color: PayNowTheme.of(context).secondaryBackground,
                        shape: BoxShape.rectangle,
                      ),
                      child: Padding(
                        padding: const EdgeInsetsDirectional.fromSTEB(
                            0.0, 30.0, 0.0, 30.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Expanded(
                              child: ListView(
                                padding: EdgeInsets.zero,
                                scrollDirection: Axis.vertical,
                                children: [
                                  Padding(
                                    padding:
                                        const EdgeInsetsDirectional.fromSTEB(
                                            20.0, 0.0, 20.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              1.0,
                                          height: 70.0,
                                          constraints: BoxConstraints(
                                            maxWidth: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.88,
                                          ),
                                          decoration: BoxDecoration(
                                            color: PayNowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(5.0),
                                            shape: BoxShape.rectangle,
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsetsDirectional
                                                .fromSTEB(0.0, 10.0, 0.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                await Navigator.push(
                                                  context,
                                                  PageTransition(
                                                    type: PageTransitionType
                                                        .rightToLeft,
                                                    duration: const Duration(
                                                        milliseconds: 300),
                                                    reverseDuration:
                                                        const Duration(
                                                            milliseconds: 300),
                                                    child:
                                                        const ProfileeditPageWidget(),
                                                  ),
                                                );
                                              },
                                              child: ListTile(
                                                leading: Icon(
                                                  Icons.perm_identity,
                                                  color: PayNowTheme.of(context)
                                                      .primaryText,
                                                ),
                                                title: Text(
                                                  'My Info',
                                                  style: PayNowTheme.of(context)
                                                      .titleMedium
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color: PayNowTheme.of(
                                                                context)
                                                            .primaryText,
                                                        fontSize: 14.0,
                                                      ),
                                                ),
                                                trailing: Icon(
                                                  Icons.arrow_forward_ios,
                                                  color: PayNowTheme.of(context)
                                                      .secondaryText,
                                                  size: 20.0,
                                                ),
                                                tileColor:
                                                    PayNowTheme.of(context)
                                                        .secondary,
                                                dense: false,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding:
                                        const EdgeInsetsDirectional.fromSTEB(
                                            20.0, 20.0, 20.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              1.0,
                                          height: 70.0,
                                          constraints: BoxConstraints(
                                            maxWidth: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.88,
                                          ),
                                          decoration: BoxDecoration(
                                            color: PayNowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(5.0),
                                            shape: BoxShape.rectangle,
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsetsDirectional
                                                .fromSTEB(0.0, 10.0, 0.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                _showPasswordVerificationDialog(
                                                    context);
                                              },
                                              child: ListTile(
                                                leading: Icon(
                                                  Icons.lock_reset_rounded,
                                                  color: PayNowTheme.of(context)
                                                      .primaryText,
                                                ),
                                                title: Text(
                                                  'Reset Password',
                                                  style: PayNowTheme.of(context)
                                                      .titleMedium
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color: PayNowTheme.of(
                                                                context)
                                                            .primaryText,
                                                        fontSize: 14.0,
                                                      ),
                                                ),
                                                trailing: Icon(
                                                  Icons.arrow_forward_ios,
                                                  color: PayNowTheme.of(context)
                                                      .secondaryText,
                                                  size: 20.0,
                                                ),
                                                tileColor:
                                                    PayNowTheme.of(context)
                                                        .secondary,
                                                dense: false,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  if (false)
                                    Padding(
                                      padding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              20.0, 20.0, 20.0, 0.0),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Container(
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                1.0,
                                            height: 70.0,
                                            constraints: BoxConstraints(
                                              maxWidth: MediaQuery.of(context)
                                                      .size
                                                      .width *
                                                  0.88,
                                            ),
                                            decoration: BoxDecoration(
                                              color: PayNowTheme.of(context)
                                                  .primaryBackground,
                                              borderRadius:
                                                  BorderRadius.circular(5.0),
                                              shape: BoxShape.rectangle,
                                            ),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsetsDirectional
                                                      .fromSTEB(
                                                      0.0, 10.0, 0.0, 0.0),
                                              child: InkWell(
                                                splashColor: Colors.transparent,
                                                focusColor: Colors.transparent,
                                                hoverColor: Colors.transparent,
                                                highlightColor:
                                                    Colors.transparent,
                                                onTap: () async {
                                                  await Navigator.push(
                                                    context,
                                                    PageTransition(
                                                      type: PageTransitionType
                                                          .rightToLeft,
                                                      duration: const Duration(
                                                          milliseconds: 300),
                                                      reverseDuration:
                                                          const Duration(
                                                              milliseconds:
                                                                  300),
                                                      child:
                                                          const SettingsPageWidget(),
                                                    ),
                                                  );
                                                },
                                                child: ListTile(
                                                  leading: Icon(
                                                    Icons.settings_sharp,
                                                    color:
                                                        PayNowTheme.of(context)
                                                            .primaryText,
                                                  ),
                                                  title: Text(
                                                    'Settings',
                                                    style: PayNowTheme.of(
                                                            context)
                                                        .titleMedium
                                                        .override(
                                                          fontFamily: 'Poppins',
                                                          color: PayNowTheme.of(
                                                                  context)
                                                              .primaryText,
                                                          fontSize: 14.0,
                                                        ),
                                                  ),
                                                  trailing: Icon(
                                                    Icons.arrow_forward_ios,
                                                    color:
                                                        PayNowTheme.of(context)
                                                            .secondaryText,
                                                    size: 20.0,
                                                  ),
                                                  tileColor:
                                                      PayNowTheme.of(context)
                                                          .secondary,
                                                  dense: false,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  Padding(
                                    padding:
                                        const EdgeInsetsDirectional.fromSTEB(
                                            20.0, 20.0, 20.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              1.0,
                                          height: 70.0,
                                          constraints: BoxConstraints(
                                            maxWidth: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.88,
                                          ),
                                          decoration: BoxDecoration(
                                            color: PayNowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(5.0),
                                            shape: BoxShape.rectangle,
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsetsDirectional
                                                .fromSTEB(0.0, 10.0, 0.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                await Navigator.push(
                                                  context,
                                                  PageTransition(
                                                    type: PageTransitionType
                                                        .rightToLeft,
                                                    duration: const Duration(
                                                        milliseconds: 300),
                                                    reverseDuration:
                                                        const Duration(
                                                            milliseconds: 300),
                                                    child:
                                                        const SubscriptionPageWidget(),
                                                  ),
                                                );
                                              },
                                              child: ListTile(
                                                leading: Icon(
                                                  Icons.credit_card,
                                                  color: PayNowTheme.of(context)
                                                      .primaryText,
                                                ),
                                                title: Text(
                                                  'My Subscription',
                                                  style: PayNowTheme.of(context)
                                                      .titleMedium
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color: PayNowTheme.of(
                                                                context)
                                                            .primaryText,
                                                        fontSize: 14.0,
                                                      ),
                                                ),
                                                trailing: Icon(
                                                  Icons.arrow_forward_ios,
                                                  color: PayNowTheme.of(context)
                                                      .secondaryText,
                                                  size: 20.0,
                                                ),
                                                tileColor:
                                                    PayNowTheme.of(context)
                                                        .secondary,
                                                dense: false,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding:
                                        const EdgeInsetsDirectional.fromSTEB(
                                            20.0, 20.0, 20.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              1.0,
                                          height: 70.0,
                                          constraints: BoxConstraints(
                                            maxWidth: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.88,
                                          ),
                                          decoration: BoxDecoration(
                                            color: PayNowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(5.0),
                                            shape: BoxShape.rectangle,
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsetsDirectional
                                                .fromSTEB(0.0, 10.0, 0.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                // await launchURL('https://skiwitness.com/terms-conditions/');
                                                loadWebSiteUrl(
                                                    'https://skiwitness.com/terms-conditions/');
                                              },
                                              child: ListTile(
                                                leading: Icon(
                                                  Icons
                                                      .contact_support_outlined,
                                                  color: PayNowTheme.of(context)
                                                      .primaryText,
                                                ),
                                                title: Text(
                                                  'Terms & Conditions',
                                                  style: PayNowTheme.of(context)
                                                      .titleMedium
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color: PayNowTheme.of(
                                                                context)
                                                            .primaryText,
                                                        fontSize: 14.0,
                                                      ),
                                                ),
                                                trailing: Icon(
                                                  Icons.arrow_forward_ios,
                                                  color: PayNowTheme.of(context)
                                                      .secondaryText,
                                                  size: 20.0,
                                                ),
                                                tileColor:
                                                    PayNowTheme.of(context)
                                                        .secondary,
                                                dense: false,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding:
                                        const EdgeInsetsDirectional.fromSTEB(
                                            20.0, 20.0, 20.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              1.0,
                                          height: 70.0,
                                          constraints: BoxConstraints(
                                            maxWidth: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.88,
                                          ),
                                          decoration: BoxDecoration(
                                            color: PayNowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(5.0),
                                            shape: BoxShape.rectangle,
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsetsDirectional
                                                .fromSTEB(0.0, 10.0, 0.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                // await launchURL('https://skiwitness.com/#How-to-use');
                                                loadWebSiteUrl(
                                                    'https://skiwitness.com/#How-to-use');
                                              },
                                              child: ListTile(
                                                leading: Icon(
                                                  Icons
                                                      .contact_support_outlined,
                                                  color: PayNowTheme.of(context)
                                                      .primaryText,
                                                ),
                                                title: Text(
                                                  'FAQs',
                                                  style: PayNowTheme.of(context)
                                                      .titleMedium
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color: PayNowTheme.of(
                                                                context)
                                                            .primaryText,
                                                        fontSize: 14.0,
                                                      ),
                                                ),
                                                trailing: Icon(
                                                  Icons.arrow_forward_ios,
                                                  color: PayNowTheme.of(context)
                                                      .secondaryText,
                                                  size: 20.0,
                                                ),
                                                tileColor:
                                                    PayNowTheme.of(context)
                                                        .secondary,
                                                dense: false,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding:
                                        const EdgeInsetsDirectional.fromSTEB(
                                            20.0, 20.0, 20.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              1.0,
                                          height: 70.0,
                                          constraints: BoxConstraints(
                                            maxWidth: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.88,
                                          ),
                                          decoration: BoxDecoration(
                                            color: PayNowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(5.0),
                                            shape: BoxShape.rectangle,
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsetsDirectional
                                                .fromSTEB(0.0, 10.0, 0.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                await Navigator.push(
                                                  context,
                                                  PageTransition(
                                                    type: PageTransitionType
                                                        .rightToLeft,
                                                    duration: const Duration(
                                                        milliseconds: 300),
                                                    reverseDuration:
                                                        const Duration(
                                                            milliseconds: 300),
                                                    child:
                                                        const SupportPageWidget(),
                                                  ),
                                                );
                                              },
                                              child: ListTile(
                                                leading: Icon(
                                                  Icons
                                                      .contact_support_outlined,
                                                  color: PayNowTheme.of(context)
                                                      .primaryText,
                                                ),
                                                title: Text(
                                                  'Support',
                                                  style: PayNowTheme.of(context)
                                                      .titleMedium
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color: PayNowTheme.of(
                                                                context)
                                                            .primaryText,
                                                        fontSize: 14.0,
                                                      ),
                                                ),
                                                trailing: Icon(
                                                  Icons.arrow_forward_ios,
                                                  color: PayNowTheme.of(context)
                                                      .secondaryText,
                                                  size: 20.0,
                                                ),
                                                tileColor:
                                                    PayNowTheme.of(context)
                                                        .secondary,
                                                dense: false,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding:
                                        const EdgeInsetsDirectional.fromSTEB(
                                            20.0, 20.0, 20.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              1.0,
                                          height: 70.0,
                                          constraints: BoxConstraints(
                                            maxWidth: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.88,
                                          ),
                                          decoration: BoxDecoration(
                                            color: PayNowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(5.0),
                                            shape: BoxShape.rectangle,
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsetsDirectional
                                                .fromSTEB(0.0, 10.0, 0.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                // await launchURL('https://skiwitness.com/#How-to-use');
                                                loadWebSiteUrl(
                                                    'https://skiwitness.com/#How-to-use');
                                              },
                                              child: ListTile(
                                                leading: Icon(
                                                  Icons
                                                      .contact_support_outlined,
                                                  color: PayNowTheme.of(context)
                                                      .primaryText,
                                                ),
                                                title: Text(
                                                  'Help Center',
                                                  style: PayNowTheme.of(context)
                                                      .titleMedium
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color: PayNowTheme.of(
                                                                context)
                                                            .primaryText,
                                                        fontSize: 14.0,
                                                      ),
                                                ),
                                                trailing: Icon(
                                                  Icons.arrow_forward_ios,
                                                  color: PayNowTheme.of(context)
                                                      .secondaryText,
                                                  size: 20.0,
                                                ),
                                                tileColor:
                                                    PayNowTheme.of(context)
                                                        .secondary,
                                                dense: false,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding:
                                        const EdgeInsetsDirectional.fromSTEB(
                                            20.0, 20.0, 20.0, 0.0),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Container(
                                          width: MediaQuery.of(context)
                                                  .size
                                                  .width *
                                              1.0,
                                          height: 70.0,
                                          constraints: BoxConstraints(
                                            maxWidth: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.88,
                                          ),
                                          decoration: BoxDecoration(
                                            color: PayNowTheme.of(context)
                                                .primaryBackground,
                                            borderRadius:
                                                BorderRadius.circular(5.0),
                                            shape: BoxShape.rectangle,
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsetsDirectional
                                                .fromSTEB(0.0, 10.0, 0.0, 0.0),
                                            child: InkWell(
                                              splashColor: Colors.transparent,
                                              focusColor: Colors.transparent,
                                              hoverColor: Colors.transparent,
                                              highlightColor:
                                                  Colors.transparent,
                                              onTap: () async {
                                                _showExit(context);
                                              },
                                              child: ListTile(
                                                leading: Icon(
                                                  Icons.logout,
                                                  color: PayNowTheme.of(context)
                                                      .primaryText,
                                                ),
                                                title: Text(
                                                  'Logout',
                                                  style: PayNowTheme.of(context)
                                                      .titleMedium
                                                      .override(
                                                        fontFamily: 'Poppins',
                                                        color: PayNowTheme.of(
                                                                context)
                                                            .primaryText,
                                                        fontSize: 14.0,
                                                      ),
                                                ),
                                                tileColor:
                                                    PayNowTheme.of(context)
                                                        .secondary,
                                                dense: false,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ));
  }

  Future<void> _showPasswordVerificationDialog(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    final String? storedPassword = prefs.getString('isPassword');
    final TextEditingController passwordController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text(
            'Verify Password',
            style: TextStyle(
              color: Colors.black,
              fontSize: 20.0,
            ),
          ),
          content: TextField(
            controller: passwordController,
            obscureText: true,
            decoration: const InputDecoration(
                hintText: 'Enter your password',
                hintStyle: TextStyle(color: Colors.black)),
            style: const TextStyle(color: Colors.black),
          ),
          backgroundColor: Colors.white,
          shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(2))),
          actions: <Widget>[
            TextButton(
              child: const Text(
                'Cancel',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18.0,
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text(
                'Verify',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 18.0,
                ),
              ),
              onPressed: () {
                if (passwordController.text == storedPassword) {
                  Navigator.of(context).pop();
                  resetPassword();
                  // Navigator.push(
                  //   context,
                  //   PageTransition(
                  //     type: PageTransitionType.rightToLeft,
                  //     duration: Duration(milliseconds: 300),
                  //     reverseDuration: Duration(milliseconds: 300),
                  //     child: ResetPasswordPageWidget(),
                  //   ),
                  // );
                  //  Navigator.push(
                  //   context,
                  //   PageTransition(
                  //     type:
                  //     PageTransitionType.rightToLeft,
                  //     duration:
                  //     Duration(milliseconds: 300),
                  //     reverseDuration:
                  //     Duration(milliseconds: 300),
                  //     child: ResetPasswordPageWidget(),
                  //   ),
                  // );
                } else {
                  // Show an error message or handle incorrect password
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        'Incorrect password',
                        style: PayNowTheme.of(context).titleSmall.override(
                              fontFamily: 'Poppins',
                              color: Colors.white,
                            ),
                      ),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              },
            ),
          ],
        );
      },
    );
  }

  _showExit(BuildContext context) {
    // set up the buttons
    Widget cancelButton = TextButton(
      child: const Text(
        "No",
        style: TextStyle(
          color: Colors.black,
          // fontSize: 17.0,
        ),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );
    Widget continueButton = TextButton(
      child: const Text(
        "Yes",
        style: TextStyle(
          color: Colors.black,
          // fontSize: 17.0,
        ),
      ),
      onPressed: () async {
        Navigator.pop(context);
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setBool('isLogin', false);
        // To remove user details (on logout)
        await prefs.remove('userDetails');
        // To remove user details (on logout)
        await prefs.remove('isPassword');
        Amplify.Auth.signOut();

        Navigator.pushAndRemoveUntil(
          context,
          PageTransition(
            type: PageTransitionType.rightToLeft,
            duration: const Duration(milliseconds: 300),
            reverseDuration: const Duration(milliseconds: 300),
            child: const LoginPageWidget(),
          ),
          (r) => false,
        );
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: const Text(
        "Confirmation",
        style: TextStyle(
          color: Colors.black,
          fontSize: 20.0,
        ),
      ),
      content: const Text(
        "Do you want to logout?",
        style: TextStyle(
          color: Colors.black,
          fontSize: 17.0,
        ),
      ),
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(2))),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  void loadWebSiteUrl(String url) {
    Navigator.push(
      context,
      PageTransition(
        type: PageTransitionType.rightToLeft,
        duration: const Duration(milliseconds: 300),
        reverseDuration: const Duration(milliseconds: 300),
        child: WebViewContainer(url),
      ),
    );
  }

  Future _pickImageFromGallery() async {
    final returnedImage = await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );
    setState(() {
      selectedProfileImage = File(returnedImage!.path);
    });
    (context.read<ProfileImageBloc>()
      ..add(GetProfileImageEvent(
          fileName: 's4.jpg',
          fileType: 'jpg',
          imageFile: selectedProfileImage!)));
  }
}
