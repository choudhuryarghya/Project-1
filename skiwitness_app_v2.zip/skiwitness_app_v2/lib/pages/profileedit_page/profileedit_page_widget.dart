import 'dart:convert';

import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:http/http.dart' as http;
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skiwitness_app/widgets/timer_widget.dart';

import '/main.dart';
import '../../../theme/pay_now_theme.dart';
import '../../../theme/pay_now_util.dart';
import '../../../theme/pay_now_widgets.dart';
import 'profileedit_page_model.dart';

export 'profileedit_page_model.dart';

class ProfileeditPageWidget extends StatefulWidget {
  const ProfileeditPageWidget({super.key});

  @override
  _ProfileeditPageWidgetState createState() => _ProfileeditPageWidgetState();
}

class _ProfileeditPageWidgetState extends State<ProfileeditPageWidget> {
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _mobileNumberController = TextEditingController();
  final TextEditingController _emergencyContactName1Controller =
      TextEditingController();
  final TextEditingController _emergencyMobileNumber1Controller =
      TextEditingController();
  final TextEditingController _emergencyContactName2Controller =
      TextEditingController();
  final TextEditingController _emergencyMobileNumber2Controller =
      TextEditingController();
  final TextEditingController _emergencyContactName3Controller =
      TextEditingController();
  final TextEditingController _emergencyMobileNumber3Controller =
      TextEditingController();

  final bool _isProfileImageVisible = true;
  final String _mobileCountryCode = 'IN';
  String countryCode = '91';
  String _emergencyMobileCountryCode1 = 'IN';
  String emergencyMobileCountryCode1 = '91';
  String _emergencyMobileCountryCode2 = 'IN';
  String emergencyMobileCountryCode2 = '91';
  String _emergencyMobileCountryCode3 = 'IN';
  String emergencyMobileCountryCode3 = '91';

  bool _isLoader = false;
  late ProfileeditPageModel _model;
  String userName = '';
  String phone = '';
  String email = '';
  String profile = '';
  final scaffoldKey = GlobalKey<ScaffoldState>();
  bool isEditable = false;

  String _viewEmergencyContactName1 = '';
  String _viewEmergencyContactName2 = '';
  String _viewEmergencyContactName3 = '';
  String _viewEmergencyContactPhone1 = '';
  String _viewEmergencyContactPhone2 = '';
  String _viewEmergencyContactPhone3 = '';

  @override
  void initState() {
    super.initState();
    fetchUserDetails();
    _model = createModel(context, () => ProfileeditPageModel());

    _model.textController1 ??= TextEditingController();
    _model.textController2 ??= TextEditingController();
    _model.textController3 ??= TextEditingController();
  }

  fetchUserDetails() async {
    var authUser = await Amplify.Auth.getCurrentUser();
    print(authUser);
    String cognitoId = authUser.userId;
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userDetailsString = prefs.getString('userDetails');
    if (userDetailsString != null) {
      Map<String, dynamic> userDetails = json.decode(userDetailsString);
      print(userDetails);
      setState(() {
        userName = userDetails['user']['first_name'] ?? '';

        phone = userDetails['user']['phone'] ?? '';
        print(phone);
        email = userDetails['user']['email'] ?? '';
        profile = userDetails['user']['imageUrl'] ?? '';
        _viewEmergencyContactName1 =
            userDetails['user']['emergencyContactName'] ?? '';
        _viewEmergencyContactName2 =
            userDetails['user']['emergencyContactName2'] ?? '';
        _viewEmergencyContactName3 =
            userDetails['user']['emergencyContactName3'] ?? '';
        _viewEmergencyContactPhone1 = userDetails['user']['emergencyContact']
                ?['phoneNumberWithCountryCode'] ??
            '';
        _viewEmergencyContactPhone2 = userDetails['user']['emergencyContact2']
                ?['phoneNumberWithCountryCode'] ??
            '';
        _viewEmergencyContactPhone3 = userDetails['user']['emergencyContact3']
                ?['phoneNumberWithCountryCode'] ??
            '';

        _firstNameController.text = userName;
        _lastNameController.text = userDetails['user']['middle_name'] ?? '';
        _emailController.text = email;
        _mobileNumberController.text = phone;
        _emergencyContactName1Controller.text = _viewEmergencyContactName1;
        _emergencyMobileNumber1Controller.text =
            userDetails['user']['emergencyContact']?['phoneNumber'] ?? '';
        _emergencyContactName2Controller.text = _viewEmergencyContactName2;
        _emergencyMobileNumber2Controller.text =
            userDetails['user']['emergencyContact2']?['phoneNumber'] ?? '';
        _emergencyContactName3Controller.text = _viewEmergencyContactName3;
        _emergencyMobileNumber3Controller.text =
            userDetails['user']['emergencyContact3']?['phoneNumber'] ?? '';
        if (userDetails['user']['emergencyContact'] != null &&
            userDetails['user']['emergencyContact']['countryCode'] != null &&
            userDetails['user']['emergencyContact']['countryCode'].isNotEmpty) {
          _emergencyMobileCountryCode1 =
              userDetails['user']['emergencyContact']['countryCode'];
          emergencyMobileCountryCode1 =
              userDetails['user']['emergencyContact']['callingCode'];
        }
        if (userDetails['user']['emergencyContact2'] != null &&
            userDetails['user']['emergencyContact2']['countryCode'] != null &&
            userDetails['user']['emergencyContact2']['countryCode']
                .isNotEmpty) {
          _emergencyMobileCountryCode2 =
              userDetails['user']['emergencyContact2']['countryCode'];
          emergencyMobileCountryCode2 =
              userDetails['user']['emergencyContact2']['callingCode'];
        }
        if (userDetails['user']['emergencyContact3'] != null &&
            userDetails['user']['emergencyContact3']['countryCode'] != null &&
            userDetails['user']['emergencyContact3']['countryCode']
                .isNotEmpty) {
          _emergencyMobileCountryCode3 =
              userDetails['user']['emergencyContact3']['countryCode'];
          emergencyMobileCountryCode3 =
              userDetails['user']['emergencyContact3']['callingCode'];
        }
      });
    } else {
      print('just-test-2');
      final url =
          'https://3ghvmpumdb.execute-api.us-east-1.amazonaws.com/default/getUserDetails?cognitoId=$cognitoId';

      final response = await http.get(Uri.parse(url));
      print('just-test-3');
      if (response.statusCode == 200) {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('userDetails', response.body);
        Map<String, dynamic> userDetails = json.decode(response.body);
        setState(() {
          userName = userDetails['user']['first_name'] ?? '';
          phone = userDetails['user']['phone'] ?? '';
          email = userDetails['user']['email'] ?? '';
          _viewEmergencyContactName1 =
              userDetails['user']['emergencyContactName'] ?? '';
          _viewEmergencyContactName2 =
              userDetails['user']['emergencyContactName2'] ?? '';
          _viewEmergencyContactName3 =
              userDetails['user']['emergencyContactName3'] ?? '';

          _viewEmergencyContactPhone1 = userDetails['user']['emergencyContact']
                  ?['phoneNumberWithCountryCode'] ??
              '';
          _viewEmergencyContactPhone2 = userDetails['user']['emergencyContact2']
                  ?['phoneNumberWithCountryCode'] ??
              '';
          _viewEmergencyContactPhone3 = userDetails['user']['emergencyContact3']
                  ?['phoneNumberWithCountryCode'] ??
              '';

          _firstNameController.text = userName;
          _lastNameController.text = userDetails['user']['middle_name'] ?? '';
          _emailController.text = email;
          _mobileNumberController.text = phone;
          _emergencyContactName1Controller.text = _viewEmergencyContactName1;
          _emergencyMobileNumber1Controller.text =
              userDetails['user']['emergencyContact']?['phoneNumber'] ?? '';
          _emergencyContactName2Controller.text = _viewEmergencyContactName2;
          _emergencyMobileNumber2Controller.text =
              userDetails['user']['emergencyContact2']?['phoneNumber'] ?? '';
          _emergencyContactName3Controller.text = _viewEmergencyContactName3;
          _emergencyMobileNumber3Controller.text =
              userDetails['user']['emergencyContact3']?['phoneNumber'] ?? '';
          if (userDetails['user']['emergencyContact'] != null &&
              userDetails['user']['emergencyContact']['countryCode'] != null &&
              userDetails['user']['emergencyContact']['countryCode']
                  .isNotEmpty) {
            _emergencyMobileCountryCode1 =
                userDetails['user']['emergencyContact']['countryCode'];
            emergencyMobileCountryCode1 =
                userDetails['user']['emergencyContact']['callingCode'];
          }
          if (userDetails['user']['emergencyContact2'] != null &&
              userDetails['user']['emergencyContact2']['countryCode'] != null &&
              userDetails['user']['emergencyContact2']['countryCode']
                  .isNotEmpty) {
            _emergencyMobileCountryCode2 =
                userDetails['user']['emergencyContact2']['countryCode'];
            emergencyMobileCountryCode2 =
                userDetails['user']['emergencyContact2']['callingCode'];
          }
          if (userDetails['user']['emergencyContact3'] != null &&
              userDetails['user']['emergencyContact3']['countryCode'] != null &&
              userDetails['user']['emergencyContact3']['countryCode']
                  .isNotEmpty) {
            _emergencyMobileCountryCode3 =
                userDetails['user']['emergencyContact3']['countryCode'];
            emergencyMobileCountryCode3 =
                userDetails['user']['emergencyContact3']['callingCode'];
          }
          // print(_viewEmergencyContactPhone3);
        });
      } else {
        throw Exception('Failed to load user details');
      }
    }
  }

  Future<void> _updateProfile() async {
    setState(() {
      _isLoader = true;
    });
    var authUser = await Amplify.Auth.getCurrentUser();
    print(authUser);
    String cognitoId = authUser.userId;
    final response = await http.post(
      Uri.parse(
          'https://x5lf51nrml.execute-api.us-east-1.amazonaws.com/default/updateProfile'),
      headers: <String, String>{
        'Content-Type': 'application/json',
      },
      body: jsonEncode(<String, dynamic>{
        "cognitoId": cognitoId,
        "name": _firstNameController.text,
        "middle_name": _lastNameController.text,
        "contact": {
          "callingCode": _emergencyMobileNumber1Controller.text.isEmpty
              ? ''
              : emergencyMobileCountryCode1,
          "isValidNumber": true,
          "phoneNumberWithCountryCode":
              _emergencyMobileNumber1Controller.text.isEmpty
                  ? ''
                  : emergencyMobileCountryCode1 +
                      _emergencyMobileNumber1Controller.text,
          "phoneNumber": _emergencyMobileNumber1Controller.text,
          "countryCode": _emergencyMobileNumber1Controller.text.isEmpty
              ? ''
              : _emergencyMobileCountryCode1
        },
        "contact2": {
          "callingCode": _emergencyMobileNumber2Controller.text.isEmpty
              ? ''
              : emergencyMobileCountryCode2,
          "isValidNumber": true,
          "phoneNumberWithCountryCode":
              _emergencyMobileNumber2Controller.text.isEmpty
                  ? ''
                  : emergencyMobileCountryCode2 +
                      _emergencyMobileNumber2Controller.text,
          "phoneNumber": _emergencyMobileNumber2Controller.text,
          "countryCode": _emergencyMobileNumber2Controller.text.isEmpty
              ? ''
              : _emergencyMobileCountryCode2
        },
        "contact3": {
          "callingCode": _emergencyMobileNumber3Controller.text.isEmpty
              ? ''
              : emergencyMobileCountryCode3,
          "isValidNumber": true,
          "phoneNumberWithCountryCode":
              _emergencyMobileNumber3Controller.text.isEmpty
                  ? ''
                  : emergencyMobileCountryCode3 +
                      _emergencyMobileNumber3Controller.text,
          "phoneNumber": _emergencyMobileNumber3Controller.text,
          "countryCode": _emergencyMobileNumber3Controller.text.isEmpty
              ? ''
              : _emergencyMobileCountryCode3
        },
        "email": _emailController.text,
        "devideId": "",
        "contactName": _emergencyContactName1Controller.text,
        "contactName2": _emergencyContactName2Controller.text,
        "contactName3": _emergencyContactName3Controller.text
      }),
    );

    if (response.statusCode == 200) {
      setState(() {
        _isLoader = false;
      });
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('userDetails', response.body);
      showDialog(
        context: context, // Pass the current BuildContext
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text(
              'Success!',
              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),
            ),
            content: const Text(
              'Successfully Updated.',
              style: TextStyle(
                color: Colors.black,
                // fontSize: 17.0,
              ),
            ),
            backgroundColor: Colors.white,
            shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(2))),
            actions: <Widget>[
              TextButton(
                style: TextButton.styleFrom(
                  textStyle: Theme.of(context).textTheme.labelLarge,
                ),
                child: const Text(
                  'Ok',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                  ),
                ),
                onPressed: () async {
                  Navigator.of(context).pop(); // Close the dialog
                  await Navigator.push(
                    context,
                    PageTransition(
                      type: PageTransitionType.rightToLeft,
                      duration: const Duration(milliseconds: 300),
                      reverseDuration: const Duration(milliseconds: 300),
                      child: const NavBarPage(initialPage: 'ProfilePage'),
                    ),
                  );
                },
              ),
            ],
          );
        },
      );
      print('Profile updated successfully');
      print(response.body);
    } else {
      setState(() {
        _isLoader = false;
      });
      print('Failed to update profile: ${response.statusCode}');
    }
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
        inAsyncCall: _isLoader,
        progressIndicator: const CircularProgressIndicator(),
        child: Scaffold(
          key: scaffoldKey,
          backgroundColor: PayNowTheme.of(context).secondaryBackground,
          appBar: AppBar(
            backgroundColor: PayNowTheme.of(context).secondaryBackground,
            automaticallyImplyLeading: false,
            leading: InkWell(
              splashColor: Colors.transparent,
              focusColor: Colors.transparent,
              hoverColor: Colors.transparent,
              highlightColor: Colors.transparent,
              onTap: () async {
                await Navigator.push(
                  context,
                  PageTransition(
                    type: PageTransitionType.rightToLeft,
                    duration: const Duration(milliseconds: 300),
                    reverseDuration: const Duration(milliseconds: 300),
                    child: const NavBarPage(initialPage: 'ProfilePage'),
                  ),
                );
              },
              child: Icon(
                Icons.arrow_back_ios,
                color: PayNowTheme.of(context).primaryText,
                size: 24.0,
              ),
            ),
            title: Text(
              'My Info',
              style: PayNowTheme.of(context).titleMedium.override(
                    fontFamily: 'Poppins',
                    color: PayNowTheme.of(context).primaryText,
                    fontSize: 18.0,
                  ),
            ),
            actions: [
              const RemainingTimer(
                timerColor: Colors.green,
              ),
              IconButton(
                  onPressed: () {
                    setState(() {
                      isEditable = !isEditable;
                    });
                  },
                  icon: Icon(isEditable ? Icons.view_list_sharp : Icons.edit))
            ],
            centerTitle: true,
            elevation: 0.0,
          ),
          body: isEditable ? _editProfile(context) : _buildViewProfile(),
        ));
  }

  Widget _buildViewProfile() {
    return Container(
      color: PayNowTheme.of(context).secondaryBackground,
      padding: const EdgeInsets.all(12),
      child: ListView(
        children: [
          _buildProfileImage(context, enableUpdate: false, imageUrl: profile),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.all(2.0),
            child: ListTile(
              leading: const Icon(
                Icons.insert_drive_file_rounded,
                color: Colors.white70,
              ),
              title: Text(
                userName,
                style: PayNowTheme.of(context).titleSmall.override(
                    fontFamily: 'Poppins',
                    color: Colors.white,
                    fontWeight: FontWeight.normal),
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.all(2.0),
            child: ListTile(
              leading: const Icon(
                Icons.email,
                color: Colors.white70,
              ),
              title: Text(
                email,
                style: PayNowTheme.of(context).titleSmall.override(
                    fontFamily: 'Poppins',
                    color: Colors.white,
                    fontWeight: FontWeight.normal),
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.all(2.0),
            child: ListTile(
              leading: const Icon(
                Icons.mobile_friendly,
                color: Colors.white70,
              ),
              title: Text(
                phone,
                style: PayNowTheme.of(context).titleSmall.override(
                    fontFamily: 'Poppins',
                    color: Colors.white,
                    fontWeight: FontWeight.normal),
              ),
            ),
          ),
          const SizedBox(
            height: 14,
          ),
          Text(
            " Emergency Contact",
            style: PayNowTheme.of(context).titleMedium.override(
                  fontFamily: 'Poppins',
                  color: Colors.white,
                  fontSize: 17,
                ),
          ),
          const SizedBox(
            height: 8,
          ),
          const Divider(
            color: Colors.white70,
          ),
          if (_viewEmergencyContactPhone1.isNotEmpty)
            _buildContact(
                _viewEmergencyContactPhone1, _viewEmergencyContactName1),
          if (_viewEmergencyContactPhone2.isNotEmpty)
            _buildContact(
                _viewEmergencyContactPhone2, _viewEmergencyContactName2),
          if (_viewEmergencyContactPhone3.isNotEmpty)
            _buildContact(
                _viewEmergencyContactPhone3, _viewEmergencyContactName3),
        ],
      ),
    );
  }

  Widget _editProfile(BuildContext context) {
    return Container(
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  AnimatedOpacity(
                    opacity: _isProfileImageVisible ? 1.0 : 0.0,
                    duration: const Duration(milliseconds: 300),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildProfileImage(context, imageUrl: profile),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(
                        0.0, 10.0, 0.0, 0.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              20.0, 0.0, 20.0, 0.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              const SizedBox(height: 22),
                              TextFormField(
                                controller: _firstNameController,
                                decoration: const InputDecoration(
                                  prefixIcon: Icon(Icons.person),
                                  labelText: 'First Name',
                                  focusColor: Colors.blue,
                                  border: OutlineInputBorder(
                                    borderSide: BorderSide(),
                                  ),
                                  errorBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.red),
                                  ),
                                ),
                                style: PayNowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Poppins',
                                      color:
                                          PayNowTheme.of(context).primaryText,
                                    ),
                              ),
                              const SizedBox(height: 22),
                              TextFormField(
                                controller: _lastNameController,
                                decoration: const InputDecoration(
                                  prefixIcon: Icon(Icons.person),
                                  labelText: 'Last Name',
                                  focusColor: Colors.blue,
                                  border: OutlineInputBorder(
                                    borderSide: BorderSide(),
                                  ),
                                  errorBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.red),
                                  ),
                                ),
                                style: PayNowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Poppins',
                                      color:
                                          PayNowTheme.of(context).primaryText,
                                    ),
                              ),
                              const SizedBox(height: 22),
                              TextFormField(
                                controller: _emailController,
                                decoration: const InputDecoration(
                                  prefixIcon: Icon(Icons.person),
                                  labelText: 'Email',
                                  focusColor: Colors.blue,
                                  border: OutlineInputBorder(
                                    borderSide: BorderSide(),
                                  ),
                                  errorBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.red),
                                  ),
                                ),
                                style: PayNowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Poppins',
                                      color:
                                          PayNowTheme.of(context).primaryText,
                                    ),
                              ),
                              const SizedBox(height: 22),
                              TextFormField(
                                enabled: false,
                                controller: _mobileNumberController,
                                decoration: const InputDecoration(
                                  prefixIcon: Icon(Icons.mobile_off),
                                  labelText: 'Mobile Number',
                                  focusColor: Colors.blue,
                                  border: OutlineInputBorder(
                                    borderSide: BorderSide(),
                                  ),
                                  errorBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.red),
                                  ),
                                ),
                                style: PayNowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Poppins',
                                      color:
                                          PayNowTheme.of(context).primaryText,
                                    ),
                              ),
                              // IntlPhoneField(
                              //   decoration: InputDecoration(
                              //     labelText: 'Mobile Number',
                              //     border: OutlineInputBorder(
                              //       borderSide: BorderSide(),
                              //     ),
                              //     focusColor: Colors.blue,
                              //   ),
                              //   languageCode: "en",
                              //   initialCountryCode: "IN",
                              //   dropdownIcon: Icon(Icons.mobile_friendly),
                              //   onChanged: (phone) {
                              //     print(phone.completeNumber);
                              //   },
                              //   onCountryChanged: (country) {
                              //     countryCode = country.dialCode;
                              //     print('Country changed to: ' + country.name);
                              //   },
                              // ),
                              const SizedBox(height: 22),
                              ..._buildEmergencyContactInput(),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding:
                const EdgeInsetsDirectional.fromSTEB(10.0, 30.0, 10.0, 10.0),
            child: FFButtonWidget(
              onPressed: () async {
                _updateProfile();
              },
              text: 'Save Changes',
              options: FFButtonOptions(
                width: 330.0,
                height: 50.0,
                padding:
                    const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                iconPadding:
                    const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                color: PayNowTheme.of(context).primary,
                textStyle: PayNowTheme.of(context).titleSmall.override(
                      fontFamily: 'Poppins',
                      color: Colors.white,
                    ),
                elevation: 2.0,
                borderSide: const BorderSide(
                  color: Colors.transparent,
                  width: 1.0,
                ),
                borderRadius: BorderRadius.circular(10.0),
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildEmergencyContactInput() {
    return [
      const Padding(
        padding: EdgeInsets.all(8.0),
        child: Text(
          "Emergency Contacts",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
      ),
      const Divider(
        color: Colors.grey,
      ),
      const SizedBox(
        height: 20,
      ),
      TextFormField(
        controller: _emergencyContactName1Controller,
        decoration: const InputDecoration(
          prefixIcon: Icon(Icons.person),
          labelText: 'Emergency Contact Name 1',
          focusColor: Colors.blue,
          border: OutlineInputBorder(
            borderSide: BorderSide(),
          ),
          errorBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.red),
          ),
        ),
        style: PayNowTheme.of(context).bodyMedium.override(
              fontFamily: 'Poppins',
              color: PayNowTheme.of(context).primaryText,
            ),
      ),
      const SizedBox(
        height: 22,
      ),
      IntlPhoneField(
        controller: _emergencyMobileNumber1Controller,
        decoration: const InputDecoration(
            labelText: 'Emergency Mobile Number 1',
            border: OutlineInputBorder(
              borderSide: BorderSide(),
            ),
            focusColor: Colors.blue),
        languageCode: "en",
        initialCountryCode: _emergencyMobileCountryCode1,
        dropdownIcon: const Icon(Icons.mobile_friendly),
        onChanged: (phone) {
          print(phone.completeNumber);
        },
        onCountryChanged: (country) {
          emergencyMobileCountryCode1 = country.dialCode;
        },
      ),
      const SizedBox(
        height: 22,
      ),
      TextFormField(
        controller: _emergencyContactName2Controller,
        decoration: const InputDecoration(
          prefixIcon: Icon(Icons.person),
          labelText: 'Emergency Contact Name 2',
          focusColor: Colors.blue,
          border: OutlineInputBorder(
            borderSide: BorderSide(),
          ),
          errorBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.red),
          ),
        ),
        style: PayNowTheme.of(context).bodyMedium.override(
              fontFamily: 'Poppins',
              color: PayNowTheme.of(context).primaryText,
            ),
      ),
      const SizedBox(
        height: 22,
      ),
      IntlPhoneField(
        controller: _emergencyMobileNumber2Controller,
        decoration: const InputDecoration(
            labelText: 'Emergency Mobile Number 2',
            border: OutlineInputBorder(
              borderSide: BorderSide(),
            ),
            focusColor: Colors.blue),
        languageCode: "en",
        initialCountryCode: _emergencyMobileCountryCode2,
        dropdownIcon: const Icon(Icons.mobile_friendly),
        onChanged: (phone) {
          print(phone.completeNumber);
        },
        onCountryChanged: (country) {
          emergencyMobileCountryCode2 = country.dialCode;
        },
      ),
      const SizedBox(
        height: 22,
      ),
      TextFormField(
        controller: _emergencyContactName3Controller,
        decoration: const InputDecoration(
          prefixIcon: Icon(Icons.person),
          labelText: 'Emergency Contact Name 3',
          focusColor: Colors.blue,
          border: OutlineInputBorder(
            borderSide: BorderSide(),
          ),
          errorBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.red),
          ),
        ),
        style: PayNowTheme.of(context).bodyMedium.override(
              fontFamily: 'Poppins',
              color: PayNowTheme.of(context).primaryText,
            ),
      ),
      const SizedBox(
        height: 22,
      ),
      IntlPhoneField(
        controller: _emergencyMobileNumber3Controller,
        decoration: const InputDecoration(
            labelText: 'Emergency Mobile Number 3',
            border: OutlineInputBorder(
              borderSide: BorderSide(),
            ),
            focusColor: Colors.blue),
        languageCode: "en",
        initialCountryCode: _emergencyMobileCountryCode3,
        dropdownIcon: const Icon(Icons.mobile_friendly),
        onChanged: (phone) {
          print(phone.completeNumber);
        },
        onCountryChanged: (country) {
          emergencyMobileCountryCode3 = country.dialCode;
        },
      ),
      const SizedBox(
        height: 22,
      ),
    ];
  }

  Widget _buildProfileImage(
    BuildContext context, {
    bool enableUpdate = true,
    String imageUrl = '',
  }) {
    if (imageUrl != '') {
      return CircleAvatar(
        radius: 110,
        backgroundImage: NetworkImage(imageUrl),
      );
    }
    return Container(
      width: MediaQuery.of(context).size.width * 1.0,
      height: 220.0,
      decoration: BoxDecoration(
        color: PayNowTheme.of(context).secondaryBackground,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 120.0,
                height: 120.0,
                clipBehavior: Clip.antiAlias,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                ),
                child: SvgPicture.asset(
                  'assets/images/Profile_Image.svg',
                ),
              ),
            ],
          ),
          if (enableUpdate)
            Text(
              'Upload Image',
              style: PayNowTheme.of(context).titleSmall.override(
                    fontFamily: 'Poppins',
                    color: PayNowTheme.of(context).primary,
                  ),
            ),
        ],
      ),
    );
  }

  Widget _buildContact(
      String viewEmergencyContactPhone1, String viewEmergencyContactName1) {
    return Card(
      color: Colors.white,
      elevation: 0,
      child: ListTile(
        leading: const Icon(
          Icons.add_alert_rounded,
          color: Colors.black,
          size: 22,
        ),
        title: Text(
          viewEmergencyContactName1,
          style:
              const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          "+$viewEmergencyContactPhone1",
          style: const TextStyle(color: Colors.black87),
        ),
      ),
    );
  }
}
