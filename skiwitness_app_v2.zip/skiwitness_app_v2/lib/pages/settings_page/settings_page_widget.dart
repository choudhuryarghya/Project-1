import '../../../theme/pay_now_icon_button.dart';
import '../../../theme/pay_now_theme.dart';
import '../../../theme/pay_now_util.dart';
import '/main.dart';
import 'package:skiwitness_app/pages/welcome_page/welcome_page_widget.dart';
import 'package:flutter/material.dart';
import 'settings_page_model.dart';
export 'settings_page_model.dart';

class SettingsPageWidget extends StatefulWidget {
  const SettingsPageWidget({Key? key}) : super(key: key);

  @override
  _SettingsPageWidgetState createState() => _SettingsPageWidgetState();
}

class _SettingsPageWidgetState extends State<SettingsPageWidget> {
  late SettingsPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SettingsPageModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: PayNowTheme.of(context).secondaryBackground,
      appBar: AppBar(
        backgroundColor: PayNowTheme.of(context).secondaryBackground,
        automaticallyImplyLeading: false,
        leading: PayNowIconButton(
          borderColor: Colors.transparent,
          borderRadius: 30.0,
          buttonSize: 46.0,
          fillColor: PayNowTheme.of(context).secondaryBackground,
          icon: Icon(
            Icons.arrow_back_ios,
            color: PayNowTheme.of(context).primaryText,
            size: 24.0,
          ),
          onPressed: () async {
            await Navigator.push(
              context,
              PageTransition(
                type: PageTransitionType.rightToLeft,
                duration: Duration(milliseconds: 300),
                reverseDuration: Duration(milliseconds: 300),
                child: NavBarPage(initialPage: 'ProfilePage'),
              ),
            );
          },
        ),
        title: Text(
          'Settings Page',
          style: PayNowTheme.of(context).titleSmall.override(
                fontFamily: 'Poppins',
                color: PayNowTheme.of(context).primaryText,
                fontSize: 18.0,
                fontWeight: FontWeight.w500,
              ),
        ),
        actions: [],
        centerTitle: true,
        elevation: 0.0,
      ),
      body: Padding(
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 30.0, 0.0, 0.0),
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: Text(
                      'General',
                      style: PayNowTheme.of(context).bodySmall.override(
                            fontFamily: 'Lexend Deca',
                            color: PayNowTheme.of(context).primary,
                            fontSize: 14.0,
                            fontWeight: FontWeight.normal,
                          ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 12.0, 0.0, 0.0),
              child: SwitchListTile.adaptive(
                value: _model.switchListTileValue1 ??= true,
                onChanged: (newValue) async {
                  setState(() => _model.switchListTileValue1 = newValue);
                },
                title: Text(
                  'Push Notifications',
                  style: PayNowTheme.of(context).titleMedium.override(
                        fontFamily: 'Poppins',
                        color: PayNowTheme.of(context).primaryText,
                      ),
                ),
                subtitle: Text(
                  'Receive Push notifications from our application on a semi regular basis.',
                  style: PayNowTheme.of(context).bodyMedium.override(
                        fontFamily: 'Lexend Deca',
                        color: PayNowTheme.of(context).secondaryText,
                        fontSize: 14.0,
                        fontWeight: FontWeight.normal,
                      ),
                ),
                activeColor: Color(0xFF4B39EF),
                activeTrackColor: Color(0xFF3B2DB6),
                dense: false,
                controlAffinity: ListTileControlAffinity.trailing,
                contentPadding:
                    EdgeInsetsDirectional.fromSTEB(24.0, 12.0, 24.0, 12.0),
              ),
            ),
            SwitchListTile.adaptive(
              value: _model.switchListTileValue2 ??= true,
              onChanged: (newValue) async {
                setState(() => _model.switchListTileValue2 = newValue);
              },
              title: Text(
                'Email Notifications',
                style: PayNowTheme.of(context).titleMedium.override(
                      fontFamily: 'Poppins',
                      color: PayNowTheme.of(context).primaryText,
                    ),
              ),
              subtitle: Text(
                'Receive email notifications from our marketing team about new features.',
                style: PayNowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Lexend Deca',
                      color: PayNowTheme.of(context).secondaryText,
                      fontSize: 14.0,
                      fontWeight: FontWeight.normal,
                    ),
              ),
              activeColor: Color(0xFF4B39EF),
              activeTrackColor: Color(0xFF3B2DB6),
              dense: false,
              controlAffinity: ListTileControlAffinity.trailing,
              contentPadding:
                  EdgeInsetsDirectional.fromSTEB(24.0, 12.0, 24.0, 12.0),
            ),
            SwitchListTile.adaptive(
              value: _model.switchListTileValue3 ??= true,
              onChanged: (newValue) async {
                setState(() => _model.switchListTileValue3 = newValue);
              },
              title: Text(
                'Location Services',
                style: PayNowTheme.of(context).titleMedium.override(
                      fontFamily: 'Poppins',
                      color: PayNowTheme.of(context).primaryText,
                    ),
              ),
              subtitle: Text(
                'Allow us to track your location, this helps keep track of spending and keeps you safe.',
                style: PayNowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Lexend Deca',
                      color: PayNowTheme.of(context).secondaryText,
                      fontSize: 14.0,
                      fontWeight: FontWeight.normal,
                    ),
              ),
              activeColor: Color(0xFF4B39EF),
              activeTrackColor: Color(0xFF3B2DB6),
              dense: false,
              controlAffinity: ListTileControlAffinity.trailing,
              contentPadding:
                  EdgeInsetsDirectional.fromSTEB(24.0, 12.0, 24.0, 12.0),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
              child: Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 30.0, 0.0, 0.0),
                      child: Text(
                        'More',
                        style: PayNowTheme.of(context).bodySmall.override(
                              fontFamily: 'Lexend Deca',
                              color: PayNowTheme.of(context).primary,
                              fontSize: 14.0,
                              fontWeight: FontWeight.normal,
                            ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
              child: InkWell(
                splashColor: Colors.transparent,
                focusColor: Colors.transparent,
                hoverColor: Colors.transparent,
                highlightColor: Colors.transparent,
                onTap: () async {
                  await launchURL('https://google.com');
                },
                child: ListTile(
                  leading: Icon(
                    Icons.support_agent_outlined,
                    color: PayNowTheme.of(context).primaryText,
                  ),
                  title: Text(
                    'Contact us',
                    style: PayNowTheme.of(context).titleMedium.override(
                          fontFamily: 'Poppins',
                          color: PayNowTheme.of(context).primaryText,
                        ),
                  ),
                  subtitle: Text(
                    'For more information',
                    style: PayNowTheme.of(context).titleSmall.override(
                          fontFamily: 'Poppins',
                          color: PayNowTheme.of(context).secondaryText,
                        ),
                  ),
                  dense: false,
                  contentPadding:
                      EdgeInsetsDirectional.fromSTEB(24.0, 12.0, 24.0, 12.0),
                ),
              ),
            ),
            InkWell(
              splashColor: Colors.transparent,
              focusColor: Colors.transparent,
              hoverColor: Colors.transparent,
              highlightColor: Colors.transparent,
              onTap: () async {
                await Navigator.pushAndRemoveUntil(
                  context,
                  PageTransition(
                    type: PageTransitionType.rightToLeft,
                    duration: Duration(milliseconds: 300),
                    reverseDuration: Duration(milliseconds: 300),
                    child: WelcomePageWidget(),
                  ),
                  (r) => false,
                );
              },
              child: ListTile(
                leading: Icon(
                  Icons.logout,
                  color: PayNowTheme.of(context).primaryText,
                ),
                title: Text(
                  'Logout',
                  style: PayNowTheme.of(context).titleMedium.override(
                        fontFamily: 'Poppins',
                        color: PayNowTheme.of(context).primaryText,
                      ),
                ),
                dense: false,
                contentPadding:
                    EdgeInsetsDirectional.fromSTEB(24.0, 12.0, 24.0, 12.0),
              ),
            ),
          ],
        ),
      ),
    );
  }

  _showExit(BuildContext context) {
    // set up the buttons
    Widget cancelButton = TextButton(
      child: Text("Cancel"),
      onPressed: () {},
    );
    Widget continueButton = TextButton(
      child: Text("Continue"),
      onPressed: () {},
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("AlertDialog"),
      content: Text(
          "Would you like to continue learning how to use Flutter alerts?"),
      actions: [
        cancelButton,
        continueButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
