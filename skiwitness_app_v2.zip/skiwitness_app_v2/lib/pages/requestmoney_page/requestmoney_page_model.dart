import '../../../theme/pay_now_util.dart';
import 'package:flutter/material.dart';

class RequestmoneyPageModel extends PayNowModel {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for Amount widget.
  TextEditingController? amountController;
  String? Function(BuildContext, String?)? amountControllerValidator;
  String? _amountControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }

  // State field(s) for Note widget.
  TextEditingController? noteController;
  String? Function(BuildContext, String?)? noteControllerValidator;
  String? _noteControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    amountControllerValidator = _amountControllerValidator;
    noteControllerValidator = _noteControllerValidator;
  }

  void dispose() {
    amountController?.dispose();
    noteController?.dispose();
  }

  /// Additional helper methods are added here.
}
