import 'dart:convert';
import 'dart:io';

import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skiwitness_app/bloc/camera_bloc/camera_bloc.dart';
import 'package:skiwitness_app/model/video_info_model.dart';
import 'package:skiwitness_app/pages/camera_demo/camera_page.dart';
import 'package:skiwitness_app/utils/camera_utils.dart';
import 'package:skiwitness_app/utils/permission_utils.dart';
import 'package:skiwitness_app/widgets/timer_widget.dart';

import '/main.dart';
import '../../../theme/pay_now_theme.dart';
import '../../../theme/pay_now_util.dart';
import '../../../theme/pay_now_widgets.dart';
import '../../http-services/api.dart';
import '../camera_demo/video_player.dart';
import 'dashboard_page_model.dart';

export 'dashboard_page_model.dart';

class MyRecordsTabWidget extends StatefulWidget {
  const MyRecordsTabWidget({super.key});

  @override
  _MyRecordsTabWidgetState createState() => _MyRecordsTabWidgetState();
}

class _MyRecordsTabWidgetState extends State<MyRecordsTabWidget> {
  late DashboardPageModel _model;
  var videoData;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  List<dynamic> videoDataList = [];
  String userName = '';
  String profile = '';
  // Define videoItems list
  @override
  void initState() {
    fetchUserDetails();
    getMyVideos();
    getAllvideos();
    super.initState();
    _model = createModel(context, () => DashboardPageModel());
  }

  void getAllvideos() async {
    List<VideoInfo>? videoData = await getAllVideos();

    if (videoData != null) {
      for (var videoInfo in videoData) {}
      setState(() {
        videoDataList.addAll(videoData);
      });
    }
  }

  fetchUserDetails() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userDetailsString = prefs.getString('userDetails');
    String? isPassword = prefs.getString('isPassword');
    print(isPassword);
    if (userDetailsString != null) {
      Map<String, dynamic> userDetails = json.decode(userDetailsString);

      setState(() {
        try {
          userName = userDetails['user']['first_name'];
          profile = userDetails['user']['imageUrl'];
        } catch (e) {
          profile = '';
          userName = '';
        }
      });
    } else {
      var authUser = await Amplify.Auth.getCurrentUser();
      print(authUser);
      String cognitoId = authUser.userId;
      print('just-test-2');
      final url =
          'https://3ghvmpumdb.execute-api.us-east-1.amazonaws.com/default/getUserDetails?cognitoId=$cognitoId';

      final response = await http.get(Uri.parse(url));
      print('just-test-3');
      if (response.statusCode == 200) {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setString('userDetails', response.body);
        Map<String, dynamic> userDetails = json.decode(response.body);
        userName = userDetails['user']['first_name'];
        // setState(() {
        //
        // });
      } else {
        throw Exception('Failed to load user details');
      }
    }
  }

  void getMyVideos() async {
    var authUser = await Amplify.Auth.getCurrentUser();
    String cognitoId = authUser.userId;
    var httpservice = api();
    final response = await http.post(
      Uri.parse(
          'https://hx7h2j6r82.execute-api.us-east-1.amazonaws.com/develop/myvideos'),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, String>{"cognitoId": cognitoId}),
    );
    if (response.statusCode == 200) {
    } else {
      throw Exception('Failed to create album.');
    }
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  void didChangeDependencies() async {
    List<VideoInfo> videos = await getAllVideos() ?? [];
    for (VideoInfo videoInfo in videos) {}
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: PayNowTheme.of(context).secondaryBackground,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Padding(
        padding: const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 5.0, 0.0),
        child: FFButtonWidget(
          onPressed: () async {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => BlocProvider(
                  create: (context) {
                    return CameraBloc(
                      cameraUtils: CameraUtils(),
                      permissionUtils: PermissionUtils(),
                    )..add(const CameraInitialize(recordingLimit: 15));
                  },
                  child: const CameraPage(),
                ),
              ),
            );
          },
          text: 'Record Video',
          icon: const Icon(
            Icons.emergency_recording,
            size: 20.0,
          ),
          options: FFButtonOptions(
            width: 160.0,
            height: 50.0,
            padding: const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
            iconPadding:
                const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
            color: PayNowTheme.of(context).secondary,
            textStyle: PayNowTheme.of(context).bodyMedium.override(
                fontFamily: 'Poppins',
                color: Colors.black,
                fontWeight: FontWeight.bold),
            elevation: 2.0,
            borderSide: const BorderSide(
              color: Colors.transparent,
              width: 1.0,
            ),
            borderRadius: BorderRadius.circular(32.0),
          ),
        ),
      ),
      body: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Expanded(
            flex: 2,
            child: Container(
              width: double.infinity,
              // height: double.infinity,
              height: 30,
              decoration: BoxDecoration(
                color: PayNowTheme.of(context).primary,
                image: DecorationImage(
                  fit: BoxFit.cover,
                  image: Image.asset(
                    'assets/images/dashbaotd-bg.png',
                    // height: 100,
                  ).image,
                ),
              ),
              child: Padding(
                padding:
                    const EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 20.0),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding: const EdgeInsetsDirectional.fromSTEB(
                          10.0, 30.0, 10.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  8.0, 0.0, 0.0, 0.0),
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Hi, $userName!',
                                    style: PayNowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Poppins',
                                          color: const Color(0xffffffff),
                                          fontSize: 18.0,
                                        ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const RemainingTimer(
                            timerColor: Colors.white,
                          ),
                          Column(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsetsDirectional.fromSTEB(
                                    2.0, 2.0, 2.0, 2.0),
                                child: InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    await Navigator.push(
                                      context,
                                      PageTransition(
                                        type: PageTransitionType.rightToLeft,
                                        duration:
                                            const Duration(milliseconds: 300),
                                        reverseDuration:
                                            const Duration(milliseconds: 300),
                                        child: const NavBarPage(
                                            initialPage: 'ProfilePage'),
                                      ),
                                    );
                                  },
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(8.0),
                                    child: profile != ''
                                        ? CircleAvatar(
                                            backgroundImage:
                                                NetworkImage(profile),
                                          )
                                        : Image.asset(
                                            'assets/images/Profile_Picture.png',
                                            width: 40.0,
                                            height: 40.0,
                                            fit: BoxFit.cover,
                                          ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            flex: 11,
            child: Container(
              width: double.infinity,
              height: double.infinity,
              decoration: BoxDecoration(
                color: PayNowTheme.of(context).secondaryBackground,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Padding(
                    padding: const EdgeInsetsDirectional.fromSTEB(
                        20.0, 30.0, 20.0, 5.0),
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Text(
                              'Recorded Videos',
                              style: PayNowTheme.of(context)
                                  .titleSmall
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: PayNowTheme.of(context).primaryText,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                    flex: 2,
                    child: ListView(
                      padding: EdgeInsets.zero,
                      scrollDirection: Axis.vertical,
                      children: [
                        Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              10.0, 0.0, 10.0, 0.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SingleChildScrollView(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    ..._buildRecordedVideoItems(
                                        context, videoDataList),
                                    const SizedBox(
                                      height: 100,
                                    )
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildRecordedVideoItems(
      BuildContext context, List<dynamic> videoDataList) {
    List<Widget> videoItems = [];
    Set<String> existingNames =
        <String>{}; // Maintain a set of existing video names
    for (var videoInfo in videoDataList) {
      String name = videoInfo.name;
      String thumbnailUrl = videoInfo.thumbnail;
      String date = videoInfo.datetime; // Assuming you'll populate this later
      DateFormat dateFormat = DateFormat("yyyy-MM-ddTHH:mm:ss.SSS");
      DateTime dateTime = dateFormat.parse(date);
      String dummyImagePath = 'assets/video-placeholder.jpg';
      File thumbnailFile = File(thumbnailUrl);
      bool isThumbnailValid =
          thumbnailUrl.isNotEmpty && thumbnailFile.existsSync();
      String formattedDate = DateFormat('MMM dd, hh:mm aa').format(dateTime);
      if (name.isNotEmpty && !existingNames.contains(name)) {
        existingNames.add(name);
        videoItems.add(Padding(
          padding: const EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
          child: InkWell(
            // Wrap the entire container with InkWell
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => VideoPage(
                      videoFile: videoInfo.filePath.startsWith('https')
                          ? videoInfo.filePath
                          : File(videoInfo.filePath)),
                ),
              );
            },
            child: SizedBox(
              width: MediaQuery.of(context).size.width * 1.0,
              height: 80.0,
              child: Row(
                mainAxisSize: MainAxisSize.max,
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    width: MediaQuery.of(context).size.width * 0.2,
                    height: 100.0,
                    decoration: const BoxDecoration(),
                    child: Container(
                      width: 80.0,
                      height: 80.0,
                      margin: const EdgeInsets.all(8),
                      clipBehavior: Clip.antiAlias,
                      decoration: const BoxDecoration(
                        shape: BoxShape.rectangle,
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                      child: isThumbnailValid
                          ? Image.file(
                              thumbnailFile,
                              fit: BoxFit.cover,
                            )
                          : Image.asset(
                              dummyImagePath,
                              fit: BoxFit.cover,
                            ),
                    ),
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.4,
                    margin: const EdgeInsets.only(left: 2),
                    height: 100.0,
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name, // Use the video name from the API response
                          style: PayNowTheme.of(context).titleSmall.override(
                                fontFamily: 'Poppins',
                                color: PayNowTheme.of(context).primaryText,
                              ),
                        ),
                        Text(
                          formattedDate, // Use the video date from the API response
                          style: const TextStyle(
                            // Define your text style here
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: MediaQuery.of(context).size.width * 0.30,
                    height: 100.0,
                    child: Row(
                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        IconButton(
                          onPressed: () {},
                          icon: Icon(
                            Icons.download_for_offline_rounded,
                            color: Colors.yellow.shade700,
                            size: 28,
                          ),
                        ),
                        IconButton(
                          onPressed: () {},
                          icon: Icon(
                            Icons.share_rounded,
                            color: Colors.yellow.shade700,
                            size: 28,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ));
      }
    }

    return videoItems;
  }
}
