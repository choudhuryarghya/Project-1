import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class VideoPage extends StatefulWidget {
  const VideoPage({super.key, required this.videoFile});
  final dynamic videoFile;

  @override
  State<VideoPage> createState() => _VideoPageState();
}

class _VideoPageState extends State<VideoPage> {
  late VideoPlayerController _videoController;
  @override
  void initState() {
    // _videoController = VideoPlayerController.file(widget.videoFile);
    if (widget.videoFile is File) {
      // Local file
      _videoController = VideoPlayerController.file(widget.videoFile as File);
    } else if (widget.videoFile is String) {
      // Remote URL
      _videoController = VideoPlayerController.network(widget.videoFile as String);
    } else {
      throw ArgumentError('Invalid video type');
    }
    initializeVideo();
    super.initState();
  }

  void initializeVideo() async {
    await _videoController.initialize();
    _videoController.setLooping(true);
    // _videoController.play();
    // _togglePlayPause();
  }
  void _togglePlayPause() {
    setState(() {
      if (_videoController.value.isPlaying) {
        print("of");
        _videoController.pause();
      } else {
        print("on");
        _videoController.play();
      }
    });
  }

  @override
  void dispose() {
    _videoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Video 😍"),
        centerTitle: true,
      ),
      body: GestureDetector(
        onTap: _togglePlayPause,
        child: Center(
          child: AspectRatio(
            aspectRatio: 9 / 16,
            child: Container(
              color: Colors.black,
              child: VideoPlayer(_videoController),
            ),
          ),
        ),
      ),
      floatingActionButton: Stack(
        children: [
          Positioned(
            bottom: 0.0,
            left: 25,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FloatingActionButton(
                  onPressed: _togglePlayPause,
                  backgroundColor: Colors.yellow.shade900,
                  child: Icon(
                    _videoController.value.isPlaying ? Icons.pause : Icons.play_arrow,
                  ),

                ),
              ],
            ),
          ),
        ],
      ),
    );

  }
}
