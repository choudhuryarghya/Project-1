import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:sentry_flutter/sentry_flutter.dart';
import 'package:skiwitness_app/bloc/get_plans_bloc/get_plans_bloc.dart';
import 'package:skiwitness_app/in_app_purchase/subscription_ids.dart';
import 'package:skiwitness_app/theme/pay_now_widgets.dart';

import '/main.dart';
import '../../../../theme/pay_now_theme.dart';
import '../../../../theme/pay_now_util.dart';
import 'contact_list_page_model.dart';

export 'contact_list_page_model.dart';

class SubscriptionPageWidget extends StatefulWidget {
  const SubscriptionPageWidget({super.key});

  @override
  State<SubscriptionPageWidget> createState() => _SubscriptionPageWidgetState();
}

class _SubscriptionPageWidgetState extends State<SubscriptionPageWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  late ContactListPageModel _model;
  final _inAppPurchase = InAppPurchase.instance;
  bool _isAvailable = false;
  bool _loading = true;
  List<ProductDetails> _products = [];

  String? _notice;

  Future<void> initStoreInfo() async {
    final isAvailable = await _inAppPurchase.isAvailable();
    setState(() {
      _isAvailable = isAvailable;
    });

    if (!_isAvailable) {
      setState(() {
        _loading = false;
        _notice = "There are no upgrades at this time";
      });
      return;
    }

    // get IAP.
    final subscriptionIds = SubscriptionIds.values.map((id) => id.key).toSet();
    ProductDetailsResponse productDetailsResponse =
        await _inAppPurchase.queryProductDetails(subscriptionIds);

    setState(() {
      _loading = false;
      _products = productDetailsResponse.productDetails;
    });

    if (productDetailsResponse.error != null) {
      setState(() {
        _notice = "There was a problem connecting to the store";
      });
    } else if (productDetailsResponse.productDetails.isEmpty) {
      setState(() {
        _notice = "There are no upgrades at this time";
      });
    }

    _products.sort((productOne, productTwo) {
      return productOne.rawPrice.compareTo(productTwo.rawPrice);
    });
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ContactListPageModel());
    _model.textController ??= TextEditingController();
    initStoreInfo();
  }

  @override
  void dispose() {
    _model.dispose();
    super.dispose();
  }

  late int selectedButton = 0;

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<GetPlansBloc, GetPlansState>(
      listener: (context, state) {
        log(state.status.toString());
      },
      builder: (context, state) {
        return Scaffold(
          key: scaffoldKey,
          backgroundColor: PayNowTheme.of(context).secondaryBackground,
          appBar: AppBar(
            backgroundColor: PayNowTheme.of(context).secondaryBackground,
            iconTheme: const IconThemeData(color: Colors.black),
            automaticallyImplyLeading: true,
            leading: InkWell(
              splashColor: Colors.transparent,
              focusColor: Colors.transparent,
              hoverColor: Colors.transparent,
              highlightColor: Colors.transparent,
              onTap: () {
                Navigator.push(
                  context,
                  PageTransition(
                    type: PageTransitionType.rightToLeft,
                    duration: const Duration(milliseconds: 300),
                    reverseDuration: const Duration(milliseconds: 300),
                    child: const NavBarPage(initialPage: 'DashboardPage'),
                  ),
                );
              },
              child: Icon(
                Icons.arrow_back_ios,
                color: PayNowTheme.of(context).primaryText,
                size: 24.0,
              ),
            ),
            title: Text(
              'Subscription Plans',
              style: PayNowTheme.of(context).titleMedium.override(
                    fontFamily: 'Poppins',
                    color: PayNowTheme.of(context).primaryText,
                    fontSize: 18.0,
                  ),
            ),
            centerTitle: true,
            elevation: 0.0,
          ),
          body: Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(10.0, 0.0, 1.0, 0.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                if (_notice != null)
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(_notice!),
                  ),
                const SizedBox(height: 40),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsetsDirectional.only(top: 20.0),
                    child: ListView(
                      padding: EdgeInsets.zero,
                      shrinkWrap: true,
                      scrollDirection: Axis.vertical,
                      children: [
                        Card(
                          color: Colors.white,
                          elevation: 5,
                          shadowColor: Colors.yellow,
                          margin: const EdgeInsets.all(12),
                          child: Column(
                            children: [
                              const SizedBox(height: 22),
                              ClipOval(
                                child: Material(
                                  color: Colors.blue.shade700, // Button color
                                  child: InkWell(
                                    onTap: () {},
                                    child: const SizedBox(
                                      width: 126,
                                      height: 126,
                                      child: Icon(
                                        Icons.subscriptions,
                                        size: 58,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                "Buy Recording Minutes",
                                style:
                                    PayNowTheme.of(context).bodyMedium.override(
                                          fontFamily: 'Poppins',
                                          color: Colors.blue.shade900,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 24,
                                        ),
                              ),
                              const Padding(
                                padding: EdgeInsets.all(18.0),
                                child: Divider(color: Colors.grey),
                              ),
                              if (state.status == GetPlanStatus.loaded)
                                SizedBox(
                                  height: 250,
                                  child: ListView.builder(
                                    // itemCount: state.plansList!.length,
                                    itemCount: _products.length,
                                    itemBuilder: (context, index) {
                                      final productDetails = _products[index];

                                      return OptionRadio(
                                        // text: state.plansList![index].plan,
                                        text: productDetails.description,
                                        index: index,
                                        selectedButton: selectedButton,
                                        press: (val) {
                                          selectedButton = val;
                                          setState(() {});
                                        },
                                      );
                                    },
                                  ),
                                )
                              else
                                const CircularProgressIndicator(),
                              const SizedBox(height: 12),
                              FFButtonWidget(
                                onPressed: () async {
                                  try {
                                    final productDetails =
                                        _products[selectedButton];
                                    final purchaseParam = PurchaseParam(
                                      productDetails: productDetails,
                                    );
                                    InAppPurchase.instance.buyNonConsumable(
                                      purchaseParam: purchaseParam,
                                    );
                                  } catch (exception, stackTrace) {
                                    await Sentry.captureException(
                                      exception,
                                      stackTrace: stackTrace,
                                      hint: Hint(),
                                    );
                                  }
                                },
                                text: 'Subscribe',
                                options: FFButtonOptions(
                                  width: 320.0,
                                  height: 50.0,
                                  padding: EdgeInsetsDirectional.zero,
                                  iconPadding: EdgeInsetsDirectional.zero,
                                  color: PayNowTheme.of(context).primary,
                                  textStyle: PayNowTheme.of(context)
                                      .headlineSmall
                                      .override(
                                        fontFamily: 'Poppins',
                                        color: Colors.white,
                                        fontSize: 15.0,
                                      ),
                                  elevation: 0.0,
                                  borderSide: const BorderSide(
                                    color: Colors.transparent,
                                    width: 1.0,
                                  ),
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                              ),
                              const SizedBox(height: 12),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class OptionRadio extends StatefulWidget {
  final String text;
  final int index;
  final int selectedButton;
  final Function press;

  const OptionRadio({
    super.key,
    required this.text,
    required this.index,
    required this.selectedButton,
    required this.press,
  });

  @override
  OptionRadioPage createState() => OptionRadioPage();
}

class OptionRadioPage extends State<OptionRadio> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        widget.press(widget.index);
      },
      child: Row(
        children: <Widget>[
          Expanded(
            child: Theme(
              data: Theme.of(context).copyWith(
                  unselectedWidgetColor: Colors.grey,
                  disabledColor: Colors.blue),
              child: Column(children: [
                RadioListTile(
                  title: Text(
                    " ${widget.text}",
                    style: const TextStyle(color: Colors.black, fontSize: 16),
                    softWrap: true,
                  ),
                  /*Here the selectedButton which is null initially takes place of value after onChanged. Now, I need to clear the selected button when other button is clicked */
                  groupValue: widget.selectedButton,
                  value: widget.index,
                  activeColor: Colors.green,
                  onChanged: (val) async {
                    debugPrint('Radio button is clicked onChanged $val');

                    widget.press(widget.index);
                  },
                  toggleable: true,
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }
}
