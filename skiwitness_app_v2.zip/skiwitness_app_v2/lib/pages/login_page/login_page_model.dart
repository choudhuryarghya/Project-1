import '../../../theme/pay_now_util.dart';
import 'package:flutter/material.dart';

class LoginPageModel extends PayNowModel {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>(debugLabel: 'Login');
  // State field(s) for Email widget.
  TextEditingController? mobileController;
  String? Function(BuildContext, String?)? mobileControllerValidator;
  String? _mobileControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    // if (!RegExp(kTextValidatorEmailRegex).hasMatch(val)) {
    //   return 'Has to be a valid email address.';
    // }
    return null;
  }

  // State field(s) for Password widget.
  TextEditingController? passwordController;
  late bool passwordVisibility;
  String? Function(BuildContext, String?)? passwordControllerValidator;
  String? _passwordControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required';
    }

    return null;
  }

  /// Initialization and disposal methods.

  void initState(BuildContext context) {
    mobileControllerValidator = _mobileControllerValidator;
    passwordVisibility = false;
    passwordControllerValidator = _passwordControllerValidator;
  }

  void dispose() {
    mobileController?.dispose();
    passwordController?.dispose();
  }

  /// Additional helper methods are added here.
}
