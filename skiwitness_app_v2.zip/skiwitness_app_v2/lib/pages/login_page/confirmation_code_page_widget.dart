import 'package:amplify_auth_cognito/amplify_auth_cognito.dart';
import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:local_auth/local_auth.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:skiwitness_app/pages/login_page/login_page_widget.dart';

import '../../../theme/pay_now_theme.dart';
import '../../../theme/pay_now_util.dart';
import '../../../theme/pay_now_widgets.dart';
import '/main.dart';
import 'package:skiwitness_app/pages/resetpassword_page/resetpassword_page_widget.dart';
import 'package:skiwitness_app/pages/signup_page/signup_page_widget.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'login_page_model.dart';
export 'login_page_model.dart';

enum PageComingFrom {
  LoginScreen,
  SignUpScreen,
}

class ConfirmationCodePageWidget extends StatefulWidget {
  final PageComingFrom? pageComingFrom;
  final String username;
  final String password;
  final Function onConfirmSuccess;

  const ConfirmationCodePageWidget(
      {super.key,
      required this.username,
      required this.onConfirmSuccess,
      this.pageComingFrom, required this.password});

  @override
  _ConfirmationCodePageWidgetState createState() =>
      _ConfirmationCodePageWidgetState();
}

class _ConfirmationCodePageWidgetState
    extends State<ConfirmationCodePageWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final _codeController = TextEditingController();
  bool _isLoader = false;
  @override
  void initState() {
    print(widget.pageComingFrom);
    super.initState();
  }

  void _confirmSignInWithSmsMfa() async {
    setState(() {
      _isLoader = true;
    });
    try {
      SignInResult res = await Amplify.Auth.confirmSignIn(
        confirmationValue: _codeController.text.trim(),
      );
         print(res);
      if (res.isSignedIn) {

        Future.delayed(Duration(seconds: 4), () {
          // Actions to perform after 2 seconds
          print("This action happens after a 2-second delay.");
        });
        setState(() {
          _isLoader = false;
        });
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setBool('isLogin', true);
        await prefs.setString('isPassword', widget.password);
        showDialog(
          context: context, // Pass the current BuildContext
          barrierDismissible: false,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Success!',

              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),

              ),
              content: const Text(
                'You\'ve successfully Login.',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20.0,
                ),
              ),
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
              actions: <Widget>[
            Center(
              child:   TextButton(
                  style: TextButton.styleFrom(
                    textStyle: Theme.of(context).textTheme.labelLarge,
                  ),
                  child: const Text('Ok',
                     style: TextStyle(
                       color: Colors.black,
                       fontSize: 18.0,
                     ),
                  ),
                  onPressed: () async {
                     Navigator.of(context).pop(); // Close the dialog

                    await Navigator.pushAndRemoveUntil(
                      context,
                      PageTransition(
                        type: PageTransitionType.rightToLeft,
                        duration: Duration(milliseconds: 300),
                        reverseDuration: Duration(milliseconds: 300),
                        child: NavBarPage(initialPage: 'DashboardPage'),
                      ),
                          (r) => false,
                    );
                  },
                ),
            )
              ],
            );
          },
        );
        print("MFA verification successful and login successful!");

    // hari
      } else {
        setState(() {
          _isLoader = false;
        });
        print("MFA verification failed or further steps required");
      }
    } on AuthException catch (e) {
      // showMessage(context, e.message, backgroundColor: Colors.red);
      setState(() {
        _isLoader = false;
      });
      showDialog(
        context: context, // Pass the current BuildContext
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Error!',

              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),

            ),
            content:  Text(
              e.message,
              style: TextStyle(
                color: Colors.black,
                // fontSize: 20.0,
              ),
            ),
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
            actions: <Widget>[
             TextButton(
                  style: TextButton.styleFrom(
                    textStyle: Theme.of(context).textTheme.labelLarge,
                  ),
                  child: const Text('Ok',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18.0,
                    ),
                  ),
                  onPressed: () async {
                     Navigator.of(context).pop(); // Close the dialog

                  },
                ),

            ],
          );
        },
      );
      print("Failed to confirm sign in with MFA code: ${e.message}");
    }
  }

  void _confirmSignUpWithSmsMfa() async {
    setState(() {
      _isLoader = true;
    });
    try {
      SignUpResult res = await Amplify.Auth.confirmSignUp(
        username: widget.username,
        confirmationCode: _codeController.text.trim(),
      );
        print(res);
      if (res.isSignUpComplete) {
        // showMessage(context, 'Sign up successful please login',backgroundColor: Colors.green[400]);
        Future.delayed(Duration(seconds: 4), () {
          // Actions to perform after 2 seconds
          print("This action happens after a 2-second delay.");
        });
        setState(() {
          _isLoader = false;
        });
        showDialog(
          context: context, // Pass the current BuildContext
          barrierDismissible: false,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Success!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20.0,
                ),

              ),
              content: const Text(
                'Sign up successful please login.',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20.0,
                ),
              ),
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
              actions: <Widget>[
                Center(
                  child:   TextButton(
                    style: TextButton.styleFrom(
                      textStyle: Theme.of(context).textTheme.labelLarge,
                    ),
                    child: const Text('Ok',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 18.0,
                      ),
                    ),
                    onPressed: () async {
                      Navigator.of(context).pop(); // Close the dialog
                      await Navigator.pushAndRemoveUntil(
                        context,
                        PageTransition(
                          type: PageTransitionType.rightToLeft,
                          duration: Duration(milliseconds: 300),
                          reverseDuration: Duration(milliseconds: 300),
                          child: LoginPageWidget(),
                        ),
                            (r) => false,
                      );
                    },
                  ),
                )
              ],
            );
          },
        );
        print("MFA verification successful and login successful!");
        // widget.onConfirmSuccess();
        // Navigator.pop(context);  // Go back to the previous screen
        // await Navigator.pushAndRemoveUntil(
        //   context,
        //   PageTransition(
        //     type: PageTransitionType.rightToLeft,
        //     duration: Duration(milliseconds: 300),
        //     reverseDuration: Duration(milliseconds: 300),
        //     child: NavBarPage(initialPage: 'DashboardPage'),
        //   ),
        //       (r) => false,
        // );

      } else {
        setState(() {
          _isLoader = false;
        });
        print("MFA verification failed or further steps required");
      }
    } on AuthException catch (e) {
      setState(() {
        _isLoader = false;
      });
      // showMessage(context, e.message, backgroundColor: Colors.red);
      showDialog(
        context: context, // Pass the current BuildContext
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Error!',
              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),

            ),
            content:  Text(
              e.message,
              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),
            ),
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
            actions: <Widget>[
                 TextButton(
                  style: TextButton.styleFrom(
                    textStyle: Theme.of(context).textTheme.labelLarge,
                  ),
                  child: const Text('Ok',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18.0,
                    ),
                  ),
                  onPressed: () async {
                    Navigator.of(context).pop(); // Close the dialog

                  },
                ),
            ],
          );
        },
      );
      print("Failed to confirm sign in with MFA code: ${e.message}");
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
        key: scaffoldKey,
        backgroundColor: PayNowTheme.of(context).secondaryBackground,
        body: ModalProgressHUD(
          inAsyncCall: _isLoader,
          // demo of some additional parameters
          opacity: 0.4,
          blur: 1.5,
          progressIndicator: const CircularProgressIndicator(),
          child: Container(
            width: MediaQuery.of(context).size.width * 1.0,
            height: MediaQuery.of(context).size.height * 1.0,
            // decoration: BoxDecoration(
            //   color: PayNowTheme.of(context).primary,
            //   image: DecorationImage(
            //     fit: BoxFit.cover,
            //     image: Image.asset(
            //       'assets/images/login-bg.png',
            //     ).image,
            //   ),
            // ),
            // color: Colors.white,
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(25.0, screenHeight * 0.05, 25.0, 0.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 70.0, 0.0, 0.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            mainAxisSize: MainAxisSize.max,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              AutoSizeText(
                                'Confirmation Code ',
                                textAlign: TextAlign.start,
                                style: PayNowTheme.of(context)
                                    .displaySmall
                                    .override(
                                        fontFamily: 'Poppins',
                                        fontSize: 32.0,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Form(
                      autovalidateMode: AutovalidateMode.disabled,
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 50.0, 0.0, 0.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Image.asset(
                              'assets/images/app_laucher_icon.png',
                              width: 200.0,
                              height: 200.0,
                              fit: BoxFit.cover,
                            ),
                            SizedBox(
                              height: 56,
                            ),
                            TextFormField(
                              controller: _codeController,
                              decoration: InputDecoration(
                                prefixIcon: Icon(Icons.lock),
                                labelText: 'Confirmation Code',
                                focusColor: Colors.blue,
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(),
                                ),
                                errorBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.red),
                                ),
                              ),
                              style: PayNowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: PayNowTheme.of(context).primaryText,
                                  ),
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly
                              ],
                              keyboardType: TextInputType.number,
                              maxLength: 6,
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (widget.pageComingFrom == PageComingFrom.LoginScreen)
                      Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            0.0, 20.0, 0.0, 20.0),
                        child: Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                await Navigator.push(
                                  context,
                                  PageTransition(
                                    type: PageTransitionType.rightToLeft,
                                    duration: Duration(milliseconds: 300),
                                    reverseDuration:
                                        Duration(milliseconds: 300),
                                    child: ResetpasswordPageWidget(),
                                  ),
                                );
                              },
                              child: AutoSizeText(
                                'Forget password?',
                                textAlign: TextAlign.center,
                                style: PayNowTheme.of(context)
                                    .titleSmall
                                    .override(
                                      fontFamily: 'Poppins',
                                      color: PayNowTheme.of(context).primary,
                                    ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 0.0, 15.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                              child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: _resentCode(context),
                          )),
                          Expanded(
                              child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: _confirmButton(context),
                          )),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding:  EdgeInsets.only(bottom: screenHeight * 0.05),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              await Navigator.push(
                                context,
                                PageTransition(
                                  type: PageTransitionType.rightToLeft,
                                  duration: Duration(milliseconds: 300),
                                  reverseDuration: Duration(milliseconds: 300),
                                  child: SignupPageWidget(),
                                ),
                              );
                            },
                            child: Text(
                              'Create new account',
                              style: PayNowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Poppins',
                                    color: PayNowTheme.of(context).primary,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ));
  }

  FFButtonWidget _resentCode(BuildContext context) {
    return FFButtonWidget(
      onPressed: () async {
        widget.onConfirmSuccess();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Resend Code Sent ',
              style: PayNowTheme.of(context).titleSmall.override(
                    fontFamily: 'Poppins',
                    color: Colors.white,
                  ),
            ),
            duration: Duration(milliseconds: 4000),
            backgroundColor: PayNowTheme.of(context).primary,
          ),
        );
      },
      text: 'Resend Code',
      options: FFButtonOptions(
        height: 50.0,
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
        iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
        color: PayNowTheme.of(context).primary,
        textStyle: PayNowTheme.of(context).headlineSmall.override(
              fontFamily: 'Poppins',
              color: Colors.white,
              fontSize: 15.0,
            ),
        elevation: 2.0,
        borderSide: BorderSide(
          color: Colors.transparent,
          width: 1.0,
        ),
        borderRadius: BorderRadius.circular(10.0),
      ),
    );
  }

  FFButtonWidget _confirmButton(BuildContext context) {
    return FFButtonWidget(
      onPressed: () async {
        if (widget.pageComingFrom == PageComingFrom.LoginScreen) {
          _confirmSignInWithSmsMfa();
          // await Navigator.pushAndRemoveUntil(
          //   context,
          //   PageTransition(
          //     type: PageTransitionType.rightToLeft,
          //     duration: Duration(milliseconds: 300),
          //     reverseDuration: Duration(milliseconds: 300),
          //     child: NavBarPage(initialPage: 'DashboardPage'),
          //   ),
          //   (r) => false,
          // );
        } else {
          _confirmSignUpWithSmsMfa();
          // await Navigator.push(
          //   context,
          //   PageTransition(
          //     type: PageTransitionType.rightToLeft,
          //     duration: Duration(milliseconds: 300),
          //     reverseDuration: Duration(milliseconds: 300),
          //     child: LoginPageWidget(),
          //   ),
          // );
        }
      },
      text: widget.pageComingFrom == PageComingFrom.LoginScreen
          ? 'Confirm SignIn'
          : 'Confirm SingUp',
      options: FFButtonOptions(
        height: 50.0,
        padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
        iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
        color: PayNowTheme.of(context).primary,
        textStyle: PayNowTheme.of(context).headlineSmall.override(
              fontFamily: 'Poppins',
              color: Colors.white,
              fontSize: 15.0,
            ),
        elevation: 2.0,
        borderSide: BorderSide(
          color: Colors.transparent,
          width: 1.0,
        ),
        borderRadius: BorderRadius.circular(10.0),
      ),
    );
  }

  void showMessage(BuildContext context, String message,
      {Color? backgroundColor}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: PayNowTheme.of(context).titleSmall.override(
                fontFamily: 'Poppins',
                color: Colors.white,
              ),
        ),
        duration: Duration(milliseconds: 4000),
        backgroundColor: backgroundColor ?? PayNowTheme.of(context).primary,
      ),
    );
  }

  final _auth = LocalAuthentication();

  Future<bool> hasBiometrics() async {
    final isAvailable = await _auth.canCheckBiometrics;
    final isDeviceSupported = await _auth.isDeviceSupported();
    return isAvailable && isDeviceSupported;
  }

  Future<bool> authenticate() async {
    final isAuthAvailable = await hasBiometrics();
    if (!isAuthAvailable) return false;
    try {
      return await _auth.authenticate(
          localizedReason: 'Touch your finger on the sensor to login');
    } catch (e) {
      return false;
    }
  }

  static Future<bool> authenticateUser() async {
    //initialize Local Authentication plugin.
    final LocalAuthentication _localAuthentication = LocalAuthentication();
    //status of authentication.
    bool isAuthenticated = false;
    //check if device supports biometrics authentication.
    bool isBiometricSupported = await _localAuthentication.isDeviceSupported();
    //check if user has enabled biometrics.
    //check
    bool canCheckBiometrics = await _localAuthentication.canCheckBiometrics;

    //if device supports biometrics and user has enabled biometrics, then authenticate.
    if (isBiometricSupported && canCheckBiometrics) {
      try {
        isAuthenticated = await _localAuthentication.authenticate(
          localizedReason: 'Scan your fingerprint to authenticate',
          options: const AuthenticationOptions(
            biometricOnly: true,
            useErrorDialogs: true,
            stickyAuth: true,
          ),
        );
      } on PlatformException catch (e) {
        print(e);
      }
    }
    return isAuthenticated;
  }
}
