import 'package:amplify_auth_cognito/amplify_auth_cognito.dart';
import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:flutter/services.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:local_auth/local_auth.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';
import 'package:skiwitness_app/pages/login_page/confirmation_code_page_widget.dart';

import '../../../theme/pay_now_theme.dart';
import '../../../theme/pay_now_util.dart';
import '../../../theme/pay_now_widgets.dart';
import '/main.dart';
import 'package:skiwitness_app/pages/resetpassword_page/resetpassword_page_widget.dart';
import 'package:skiwitness_app/pages/signup_page/signup_page_widget.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'login_page_model.dart';
export 'login_page_model.dart';

class LoginPageWidget extends StatefulWidget {
  const LoginPageWidget({Key? key}) : super(key: key);

  @override
  _LoginPageWidgetState createState() => _LoginPageWidgetState();
}

class _LoginPageWidgetState extends State<LoginPageWidget> {
  late LoginPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  bool _isLoader = false;
  bool _isPhoneNotValid = true;
  String countryCode = '91';
  @override
  void initState() {
    super.initState();
    Amplify.Auth.signOut();
    _model = createModel(context, () => LoginPageModel());

    _model.mobileController ??= TextEditingController();
    _model.passwordController ??= TextEditingController();
  }

  void _login() async {
    setState(() {
      _isLoader = true;
    });
    try {
      SignInResult res = await Amplify.Auth.signIn(
        username: "+" + countryCode + _model.mobileController.text.trim(),
        password: _model.passwordController.text.trim(),
      );

      if (res.isSignedIn) {
        setState(() {
          _isLoader = false;
        });
        print("Login successful!");
        // Navigate to your main application page
      } else {
        print(res);
        print(res.nextStep.signInStep.toString());
        if (res.nextStep.signInStep ==
            AuthSignInStep.confirmSignInWithSmsMfaCode) {
          // Navigate to a page where the user can enter the MFA code
          print("MFA code required. Please check your SMS.");
          // showMessage(context, 'Verification code send Please check your SMS.',backgroundColor: Colors.green[400]);
          setState(() {
            _isLoader = false;
          });
          showDialog(
            context: context, // Pass the current BuildContext
            barrierDismissible: false,
            builder: (BuildContext context) {
              return AlertDialog(
                title: const Text('Success!',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 20.0,
                  ),

                ),
                content: const Text(
                  'Verification code send Please check your SMS.',
                  style: TextStyle(
                    color: Colors.black,
                    // fontSize: 17.0,
                  ),
                ),
                backgroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
                actions: <Widget>[
                    TextButton(
                      style: TextButton.styleFrom(
                        textStyle: Theme.of(context).textTheme.labelLarge,
                      ),
                      child: const Text('Ok',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 18.0,
                        ),
                      ),
                      onPressed: () async {
                         Navigator.of(context).pop(); // Close the dialog
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ConfirmationCodePageWidget(
                                  pageComingFrom: PageComingFrom.LoginScreen,
                                  username: "+" +countryCode +_model.mobileController.text.trim(), // Pass the username to the confirmation page
                                  password: _model.passwordController.text.trim(),
                                  onConfirmSuccess: () {
                                    print("MFA Verification and login successful!");
                                    // Handle successful verification here, e.g., navigate to main app page
                                  })),
                        );
                      },
                    ),

                ],
              );
            },
          );

        } else {
          setState(() {
            _isLoader = false;
          });
          print("Login failed");
        }
      }
    } on AuthException catch (e) {
      setState(() {
        _isLoader = false;
      });
      print("Could not login - ${e.message}");
      // showMessage(context, e.message, backgroundColor: Colors.red);
      showDialog(
        context: context, // Pass the current BuildContext
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Error!',
              // textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),

            ),
            content:  Text(
              e.message,
              style: TextStyle(
                color: Colors.black,
                // fontSize: 17.0,
              ),
            ),
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
            actions: <Widget>[
                 TextButton(
                  style: TextButton.styleFrom(
                    textStyle: Theme.of(context).textTheme.labelLarge,
                  ),
                  child: const Text('Ok',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18.0,
                    ),
                  ),
                  onPressed: () async {
                     Navigator.of(context).pop(); // Close the dialog

                  },
                ),

            ],
          );
        },
      );
    }
  }

  void validatePhone() {
    if (_model.mobileController.text.trim().isEmpty) {
      setState(() {
        _isPhoneNotValid = false;
      });
    } else {
      setState(() {
        _isPhoneNotValid = true;
      });
    }
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
        key: scaffoldKey,
        backgroundColor: PayNowTheme.of(context).secondaryBackground,
        body: ModalProgressHUD(
          inAsyncCall: _isLoader,
          // demo of some additional parameters
          opacity: 0.4,
          blur: 1.5,
          progressIndicator: const CircularProgressIndicator(),
          child: Container(
            width: MediaQuery.of(context).size.width * 1.0,
            height: MediaQuery.of(context).size.height * 1.0,
            // decoration: BoxDecoration(
            //   color: PayNowTheme.of(context).primary,
            //   image: DecorationImage(
            //     fit: BoxFit.cover,
            //     image: Image.asset(
            //       'assets/images/login-bg.png',
            //     ).image,
            //   ),
            // ),
            // color: Colors.white,
            child: Padding(
              padding: EdgeInsetsDirectional.fromSTEB(
                  25.0, screenHeight * 0.06, 25.0, 0.0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // Padding(
                    //   padding: EdgeInsetsDirectional.fromSTEB(0.0, 70.0, 0.0, 0.0),
                    //   child: Row(
                    //     mainAxisSize: MainAxisSize.max,
                    //     mainAxisAlignment: MainAxisAlignment.center,
                    //     crossAxisAlignment: CrossAxisAlignment.start,
                    //     children: [
                    //       Column(
                    //         mainAxisSize: MainAxisSize.max,
                    //         crossAxisAlignment: CrossAxisAlignment.start,
                    //         children: [
                    //           AutoSizeText(
                    //             'Welcome Back',
                    //             textAlign: TextAlign.start,
                    //             style: PayNowTheme.of(context)
                    //                 .displaySmall
                    //                 .override(
                    //                     fontFamily: 'Poppins',
                    //                     fontSize: 26.0,
                    //                     fontWeight: FontWeight.bold,
                    //                     color: Colors.white),
                    //           ),
                    //         ],
                    //       ),
                    //     ],
                    //   ),
                    // ),
                    // Padding(
                    //   padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 40.0),
                    //   child: Row(
                    //     mainAxisSize: MainAxisSize.max,
                    //     mainAxisAlignment: MainAxisAlignment.center,
                    //     crossAxisAlignment: CrossAxisAlignment.start,
                    //     children: [
                    //       Column(
                    //         mainAxisSize: MainAxisSize.max,
                    //         crossAxisAlignment: CrossAxisAlignment.start,
                    //         children: [
                    //           Row(
                    //             mainAxisSize: MainAxisSize.max,
                    //             children: [
                    //               Text(
                    //                 'Enter your credential to login',
                    //                 textAlign: TextAlign.start,
                    //                 style: PayNowTheme.of(context)
                    //                     .displaySmall
                    //                     .override(
                    //                         fontFamily: 'Poppins',
                    //                         fontSize: 10.0,
                    //                         fontWeight: FontWeight.bold,
                    //                         color: Colors.white),
                    //               ),
                    //             ],
                    //           ),
                    //         ],
                    //       ),
                    //     ],
                    //   ),
                    // ),
                    Form(
                      key: _model.formKey,
                      autovalidateMode: AutovalidateMode.disabled,
                      child: Padding(
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 10.0, 0.0, 0.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Image.asset(
                              'assets/images/app_laucher_icon.png',
                              width: 200.0,
                              height: 200.0,
                              fit: BoxFit.cover,
                            ),
                            AutoSizeText(
                              'Skiwitness ',
                              textAlign: TextAlign.start,
                              style: PayNowTheme.of(context)
                                  .displaySmall
                                  .override(
                                      fontFamily: 'Poppins',
                                      fontSize: 28.0,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.yellow.shade800),
                            ),
                            SizedBox(
                              height: 36,
                            ),
                            IntlPhoneField(
                              controller: _model.mobileController,
                              decoration: InputDecoration(
                                  labelText: 'Mobile Number',
                                  border: OutlineInputBorder(
                                    borderSide: BorderSide(),
                                  ),
                                  errorBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.red),
                                  ),
                                  errorText: !_isPhoneNotValid
                                      ? 'Please enter mobile number'
                                      : null,
                                  focusColor: Colors.blue),
                              languageCode: "en",
                              initialCountryCode: "IN",
                              dropdownIcon: Icon(Icons.person),
                              onChanged: (phone) {
                                validatePhone();
                                print(phone.completeNumber);
                                _model.mobileControllerValidator
                                    .asValidator(context);
                              },
                              onCountryChanged: (country) {
                                countryCode = country.dialCode;
                                print('Country changed to: ' + country.name);
                              },
                            ),
                            SizedBox(
                              height: 16,
                            ),
                            TextFormField(
                              decoration: InputDecoration(
                                prefixIcon: Icon(Icons.security),
                                labelText: 'Password',
                                focusColor: Colors.blue,
                                border: OutlineInputBorder(
                                  borderSide: BorderSide(),
                                ),
                                errorBorder: OutlineInputBorder(
                                  borderSide: BorderSide(color: Colors.red),
                                ),
                                suffixIcon: InkWell(
                                  onTap: () => setState(
                                    () => _model.passwordVisibility =
                                        !_model.passwordVisibility,
                                  ),
                                  focusNode: FocusNode(skipTraversal: true),
                                  child: Icon(
                                    _model.passwordVisibility
                                        ? Icons.visibility_outlined
                                        : Icons.visibility_off_outlined,
                                    color: PayNowTheme.of(context).secondary,
                                    size: 20.0,
                                  ),
                                ),
                              ),
                              style: PayNowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: PayNowTheme.of(context).primaryText,
                                  ),
                              controller: _model.passwordController,
                              obscureText: !_model.passwordVisibility,
                              // validator: _model.passwordControllerValidator.asValidator(context),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter your password';
                                }
                                // You can add more complex validation here if needed
                                return null; // Return null if the validation is successful
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 20.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              await Navigator.push(
                                context,
                                PageTransition(
                                  type: PageTransitionType.rightToLeft,
                                  duration: Duration(milliseconds: 300),
                                  reverseDuration: Duration(milliseconds: 300),
                                  child: ResetpasswordPageWidget(),
                                ),
                              );
                            },
                            child: AutoSizeText(
                              'Forget password?',
                              textAlign: TextAlign.center,
                              style:
                                  PayNowTheme.of(context).titleSmall.override(
                                        fontFamily: 'Poppins',
                                        color: PayNowTheme.of(context).primary,
                                      ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 6.0, 0.0, 24.0),
                      child: Row(
                          mainAxisSize: MainAxisSize.max,
                         mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                              child: SizedBox( // Use SizedBox to set a maximum width
                                width: MediaQuery.of(context).size.width * 0.8, // Set maximum width as 80% of screen width
                                child: FFButtonWidget(
                            onPressed: () async {
                              // if (_model.mobileController.text.isEmpty) {
                              //   showMessage(
                              //       context, 'Please enter mobile Number!',
                              //       backgroundColor: Colors.red);
                              //   return;
                              // }
                              validatePhone();
                              if (_model.formKey.currentState!.validate() &&
                                  _isPhoneNotValid) {
                                // print('all ok');
                                // return;
                                _login();
                              }

                              // await Navigator.pushAndRemoveUntil(
                              //   context,
                              //   PageTransition(
                              //     type: PageTransitionType.rightToLeft,
                              //     duration: Duration(milliseconds: 300),
                              //     reverseDuration: Duration(milliseconds: 300),
                              //     child: ConfirmationCodePageWidget(pageComingFrom: PageComingFrom.LoginScreen, username: "+91" + _model.mobileController.text.trim(),  // Pass the username to the confirmation page
                              //         onConfirmSuccess: () {
                              //           print("MFA Verification and login successful!");
                              //           // Handle successful verification here, e.g., navigate to main app page
                              //         }),
                              //   ),
                              //   (r) => false,
                              // );

                              // ScaffoldMessenger.of(context).showSnackBar(
                              //   SnackBar(
                              //     content: Text(
                              //       'Action Completed ',
                              //       style: PayNowTheme.of(context)
                              //           .titleSmall
                              //           .override(
                              //             fontFamily: 'Poppins',
                              //             color: Colors.white,
                              //           ),
                              //     ),
                              //     duration: Duration(milliseconds: 4000),
                              //     backgroundColor:
                              //         PayNowTheme.of(context).primary,
                              //   ),
                              // );
                            },
                            text: 'Login',
                            options: FFButtonOptions(
                              // width: MediaQuery.of(context).size.width * 0.8,
                              height: 50.0,
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              iconPadding: EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              color: PayNowTheme.of(context).primary,
                              textStyle: PayNowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Poppins',
                                    color: Colors.white,
                                    fontSize: 15.0,
                                  ),
                              elevation: 2.0,
                              borderSide: BorderSide(
                                color: Colors.transparent,
                                width: 1.0,
                              ),
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                          ),))
                        ],
                      ),
                    ),
                    Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                              child: Divider(
                            color: Colors.white70,
                          )),
                          Text(
                            '  OR  ',
                            style: TextStyle(color: Colors.white),
                          ),
                          Expanded(
                              child: Divider(
                            color: Colors.white70,
                          )),
                        ]),
                    IconButton(
                        onPressed: () async {
                          if (await hasBiometrics()) {
                            var auth = await authenticateWithBiometrics();
                            showMessage(context, auth ? "Success" : "Failed");
                          } else {
                            String messageValue = 'Bio Metric Not Available ';
                            showMessage(context, messageValue);
                          }
                        },
                        icon: Icon(
                          Icons.fingerprint,
                          size: 50,
                          color: Colors.blue,
                        )),
                    SizedBox(
                      height: 10,
                    ),
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          0.0, 0.0, 0.0, screenHeight * 0.05),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          InkWell(
                            splashColor: Colors.transparent,
                            focusColor: Colors.transparent,
                            hoverColor: Colors.transparent,
                            highlightColor: Colors.transparent,
                            onTap: () async {
                              await Navigator.push(
                                context,
                                PageTransition(
                                  type: PageTransitionType.rightToLeft,
                                  duration: Duration(milliseconds: 300),
                                  reverseDuration: Duration(milliseconds: 300),
                                  child: SignupPageWidget(),
                                ),
                              );
                            },
                            child: Text(
                              'Create new account',
                              style:
                                  PayNowTheme.of(context).bodyMedium.override(
                                        fontFamily: 'Poppins',
                                        color: PayNowTheme.of(context).primary,
                                      ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    // if (_isLoading)
                  ],
                ),
              ),
            ),
          ),
        ));
  }

  void showMessage(BuildContext context, String message,
      {Color? backgroundColor}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: PayNowTheme.of(context).titleSmall.override(
              fontFamily: 'Poppins', color: Colors.white, fontSize: 15),
        ),
        duration: Duration(milliseconds: 4000),
        backgroundColor: backgroundColor ?? PayNowTheme.of(context).primary,
      ),
    );
  }

  final _auth = LocalAuthentication();

  Future<bool> hasBiometrics() async {
    final isAvailable = await _auth.canCheckBiometrics;
    final isDeviceSupported = await _auth.isDeviceSupported();
    return isAvailable && isDeviceSupported;
  }

  Future<bool> authenticate() async {
    final isAuthAvailable = await hasBiometrics();
    if (!isAuthAvailable) return false;
    try {
      return await _auth.authenticate(
          localizedReason: 'Touch your finger on the sensor to login');
    } catch (e) {
      return false;
    }
  }

  static Future<bool> authenticateUser() async {
    //initialize Local Authentication plugin.
    final LocalAuthentication _localAuthentication = LocalAuthentication();
    //status of authentication.
    bool isAuthenticated = false;
    //check if device supports biometrics authentication.
    bool isBiometricSupported = await _localAuthentication.isDeviceSupported();
    //check if user has enabled biometrics.
    //check
    bool canCheckBiometrics = await _localAuthentication.canCheckBiometrics;

    //if device supports biometrics and user has enabled biometrics, then authenticate.
    if (isBiometricSupported && canCheckBiometrics) {
      try {
        isAuthenticated = await _localAuthentication.authenticate(
          localizedReason: 'Scan your fingerprint to authenticate',
          options: const AuthenticationOptions(
            biometricOnly: true,
            useErrorDialogs: true,
            stickyAuth: true,
          ),
        );
      } on PlatformException catch (e) {
        print(e);
      }
    }
    return isAuthenticated;
  }

  Future<bool> authenticateWithBiometrics() async {
    bool authenticated = false;
    try {
      authenticated = await _auth.authenticate(
        localizedReason:
            'Scan your fingerprint (or face or whatever) to authenticate',
        options: const AuthenticationOptions(
          stickyAuth: false,
          biometricOnly: true,
        ),
      );
      return authenticated;
    } on PlatformException catch (e) {
      print(e);
      return false;
    }
  }
}
