import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:flutter/services.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

import '../../../theme/pay_now_theme.dart';
import '../../../theme/pay_now_util.dart';
import '../../../theme/pay_now_widgets.dart';
import 'package:skiwitness_app/pages/login_page/login_page_widget.dart';
import 'package:flutter/material.dart';
import 'resetpassword_page_model.dart';
export 'resetpassword_page_model.dart';

class ResetpasswordPageWidget extends StatefulWidget {
  const ResetpasswordPageWidget({Key? key}) : super(key: key);

  @override
  _ResetpasswordPageWidgetState createState() =>
      _ResetpasswordPageWidgetState();
}

class _ResetpasswordPageWidgetState extends State<ResetpasswordPageWidget> {
  late ResetpasswordPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  bool _isLoader = false;
  bool _isPhoneValid = true;
  String countryCode = '91';
  bool _confirmCodeNotSend = true;
  final _codeController = TextEditingController();
  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ResetpasswordPageModel());

    _model.mobileController ??= TextEditingController();
    _model.passwordController ??= TextEditingController();
  }

  Future<void> resetPassword() async {
    setState(() {
      _isLoader = true;
    });
    print(countryCode);
    print(_model.mobileController.text);
    try {
      final result = await Amplify.Auth.resetPassword(
        username: "+"+countryCode+_model.mobileController.text,
      );
      // print(result);
      // print(result.isPasswordReset);
      setState(() {
        _isLoader = false;
      });
      showDialog(
        context: context, // Pass the current BuildContext
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Code Send',
              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),),
            content: const Text(
              'Verification code has been sent to your number. Please check.',
              style: TextStyle(
                color: Colors.black,
                // fontSize: 17.0,
              ),
            ),
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),

            actions: <Widget>[
              TextButton(
                style: TextButton.styleFrom(
                  textStyle: Theme.of(context).textTheme.labelLarge,
                ),
                child: const Text('Ok'),
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                  setState(() {
                    print(result);
                    print(result.isPasswordReset);
                    print('hari');
                    _confirmCodeNotSend = result.isPasswordReset;
                  });
                },
              ),
            ],
          );
        },
      );
      // setState(() {
      //    _confirmCodeNotSend = result.isPasswordReset;
      // });
    } on AmplifyException catch (e) {
      setState(() {
        _isLoader = false;
      });
      print(e);
      // if(e.message == 'Username/client id combination not found.'){
      //   showMessage(context, 'Invalid User',20, backgroundColor: Colors.red);
      //   safePrint(e.message);
      // }else{
      //   showMessage(context, e.message,15, backgroundColor: Colors.red);
      // }
      showDialog(
        context: context, // Pass the current BuildContext
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Error!',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),

            ),
            content:  Text(
              e.message,
              style: TextStyle(
                color: Colors.black,
                // fontSize: 20.0,
              ),
            ),
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
            actions: <Widget>[
              Center(
                child:   TextButton(
                  style: TextButton.styleFrom(
                    textStyle: Theme.of(context).textTheme.labelLarge,
                  ),
                  child: const Text('Ok',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18.0,
                    ),
                  ),
                  onPressed: () async {
                     Navigator.of(context).pop(); // Close the dialog

                  },
                ),
              )
            ],
          );
        },
      );

    }
  }

  Future<void> confirmResetPassword() async {
    setState(() {
      _isLoader = true;
    });
    try {
      final result = await Amplify.Auth.confirmResetPassword(
          username: "+"+countryCode+_model.mobileController.text,
          newPassword: _model.passwordController.text,
          confirmationCode: _codeController.text
      );
      // print('test1');
      // print(result);
      // print('test2');
      if(result.isPasswordReset){
        setState(() {
          _isLoader = false;
        });
        showDialog(
          context: context, // Pass the current BuildContext
          barrierDismissible: false,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Success!',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20.0,
                ),
              ),
              content: const Text(
                'You\'ve successfully reset your password.',
                style: TextStyle(
                  color: Colors.black,
                  // fontSize: 17.0,
                ),
              ),
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
              actions: <Widget>[
                TextButton(
                  style: TextButton.styleFrom(
                    textStyle: Theme.of(context).textTheme.labelLarge,
                  ),
                  child: const Text('Ok',
                    style: TextStyle(
                      color: Colors.black,
                      // fontSize: 17.0,
                    ),
                  ),
                  onPressed: () async {
                    // Navigator.of(context).pop(); // Close the dialog
                    await Navigator.pushAndRemoveUntil(
                      context,
                      PageTransition(
                        type: PageTransitionType.rightToLeft,
                        duration: Duration(milliseconds: 300),
                        reverseDuration: Duration(milliseconds: 300),
                        child: LoginPageWidget(),
                      ),
                          (r) => false,
                    );
                  },
                ),
              ],
            );
          },
        );
      }
      // await Navigator.push(
      //   context,
      //   PageTransition(
      //     type: PageTransitionType.rightToLeft,
      //     duration: Duration(milliseconds: 300),
      //     reverseDuration: Duration(milliseconds: 300),
      //     child: LoginPageWidget(),
      //   ),
      // );
    } on AmplifyException catch (e) {
      setState(() {
        _isLoader = false;
      });
      print(e.message);
      // if(e.message == 'Username/client id combination not found.'){
      //   showMessage(context, e.message,15, backgroundColor: Colors.red);
      showDialog(
        context: context, // Pass the current BuildContext
        barrierDismissible: false,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('error!',

              style: TextStyle(
                color: Colors.black,
                fontSize: 20.0,
              ),

            ),
            content:  Text(
              e.message,
              style: TextStyle(
                color: Colors.black,
                // fontSize: 20.0,
              ),
            ),
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(2))),
            actions: <Widget>[
                TextButton(
                  style: TextButton.styleFrom(
                    textStyle: Theme.of(context).textTheme.labelLarge,
                  ),
                  child: const Text('Ok',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 18.0,
                    ),
                  ),
                  onPressed: () async {
                    Navigator.of(context).pop(); // Close the dialog

                  },
                ),

            ],
          );
        },
      );
      //   safePrint(e.message);
      // }else{
      //   showMessage(context, e.message,15, backgroundColor: Colors.red);
      // }
    }
  }

  void validatePhone() {
    if (_model.mobileController.text.trim().isEmpty) {
      setState(() {
        _isPhoneValid = false;
      });
    } else {
      setState(() {
        _isPhoneValid = true;
      });
    }
  }
  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: PayNowTheme.of(context).primaryBackground,
      appBar: AppBar(
        backgroundColor: PayNowTheme.of(context).primaryBackground,
        automaticallyImplyLeading: false,
        leading: InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            await Navigator.pushAndRemoveUntil(
              context,
              PageTransition(
                type: PageTransitionType.rightToLeft,
                duration: Duration(milliseconds: 300),
                reverseDuration: Duration(milliseconds: 300),
                child: LoginPageWidget(),
              ),
              (r) => false,
            );
          },
          child: Icon(
            Icons.chevron_left_rounded,
            color: PayNowTheme.of(context).primaryText,
            size: 32.0,
          ),
        ),
        title: Text(
          'Reset Password',
          style: PayNowTheme.of(context).headlineSmall.override(
                fontFamily: 'Poppins',
                color: PayNowTheme.of(context).primaryText,
              ),
        ),
        actions: [],
        centerTitle: true,
        elevation: 0.0,
      ),
      body: ModalProgressHUD(
        inAsyncCall: _isLoader,
        // demo of some additional parameters
        opacity: 0.4,
        blur: 1.5,
        progressIndicator: const CircularProgressIndicator(),
       child : Row(
        mainAxisSize: MainAxisSize.max,
        children: [
          Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(
                child: Container(
                  width: MediaQuery.of(context).size.width * 1.0,
                  height: MediaQuery.of(context).size.height * 1.0,
                  decoration: BoxDecoration(),
                  child: Padding(
                    padding:
                        EdgeInsetsDirectional.fromSTEB(10.0, 30.0, 10.0, 0.0),
                    child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [

                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              10.0, 30.0, 10.0, 20.0),
                          child: Text(
                            'Enter your mobile number to send instruction to reset your password',
                            style: PayNowTheme.of(context).titleSmall.override(
                                  fontFamily: 'Poppins',
                                  color: PayNowTheme.of(context).primaryText,
                                ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              10.0, 0.0, 10.0, 2.0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Text(
                                ' ',
                                style: PayNowTheme.of(context)
                                    .bodyMedium
                                    .override(
                                      fontFamily: 'Poppins',
                                      color:
                                          PayNowTheme.of(context).primaryText,
                                      fontWeight: FontWeight.w500,
                                    ),
                              ),
                            ],
                          ),
                        ),
                        Form(
                          key: _model.formKey,
                          autovalidateMode: AutovalidateMode.disabled,
                          child: Column(
                            children: [
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    10.0, 15.0, 10.0, 10.0),
                                child: IntlPhoneField(
                                  controller: _model.mobileController,
                                  decoration: InputDecoration(
                                      labelText: 'Mobile Number',
                                      border: OutlineInputBorder(
                                        borderSide: BorderSide(),
                                      ),
                                      errorBorder: OutlineInputBorder(
                                        borderSide: BorderSide(color: Colors.red),
                                      ),
                                      errorText: !_isPhoneValid ? 'Please enter mobile number' : null,
                                      focusColor: Colors.blue
                                  ),
                                  languageCode: "en",
                                  initialCountryCode: "IN",
                                  onChanged: (phone) {
                                    validatePhone();
                                    print(phone.completeNumber);
                                    _model.mobileControllerValidator
                                        .asValidator(context);
                                  },
                                  onCountryChanged: (country) {
                                    countryCode = country.dialCode;
                                    // _model.mobileControllerValidator
                                    //     .asValidator(context);
                                    print('Country changed to: ' + country.name);
                                  },
                                  enabled: _confirmCodeNotSend ? true : false,
                                ),
                              ),
                           if (!_confirmCodeNotSend)
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(10.0, 15.0, 10.0, 10.0),
                                child: TextFormField(
                                   controller: _codeController,
                                  decoration: InputDecoration(
                                    prefixIcon: Icon(Icons.lock),
                                    labelText: 'Confirmation Code',
                                    focusColor: Colors.blue,
                                    border: OutlineInputBorder(
                                      borderSide: BorderSide(),
                                    ),
                                    errorBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: Colors.red),
                                    ),
                                  ),
                                  style: PayNowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Poppins',
                                    color: PayNowTheme.of(context).primaryText,
                                  ),
                                  inputFormatters: [
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                  keyboardType: TextInputType.number,
                                  maxLength: 6,
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter verfication code';
                                    }
                                    // You can add more complex validation here if needed
                                    return null; // Return null if the validation is successful
                                  },
                                ),
                              ),
                              if (!_confirmCodeNotSend)
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(10.0, 15.0, 10.0, 10.0),
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    prefixIcon: Icon(Icons.security),
                                    labelText: 'Password',
                                    focusColor: Colors.blue,
                                    border: OutlineInputBorder(
                                      borderSide: BorderSide(),
                                    ),
                                    errorBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: Colors.red),
                                    ),
                                    suffixIcon: InkWell(
                                      onTap: () => setState(
                                            () => _model.passwordVisibility =
                                        !_model.passwordVisibility,
                                      ),
                                      focusNode: FocusNode(skipTraversal: true),
                                      child: Icon(
                                        _model.passwordVisibility
                                            ? Icons.visibility_outlined
                                            : Icons.visibility_off_outlined,
                                        color: PayNowTheme.of(context).secondary,
                                        size: 20.0,
                                      ),
                                    ),
                                  ),
                                  style: PayNowTheme.of(context).bodyMedium.override(
                                    fontFamily: 'Poppins',
                                    color: PayNowTheme.of(context).primaryText,
                                  ),
                                  controller: _model.passwordController,
                                  obscureText: !_model.passwordVisibility,
                                  // validator: _model.passwordControllerValidator.asValidator(context),
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter your new password';
                                    }
                                    // You can add more complex validation here if needed
                                    return null; // Return null if the validation is successful
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    )
                  ),
                ),
              ),
              Container(
                width: MediaQuery.of(context).size.width * 1.0,
                height: 100.0,
                decoration: BoxDecoration(),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    FFButtonWidget(
                      onPressed: () async {
                        validatePhone();
                        if(!_isPhoneValid){
                          print('phone Not valid');
                           return;
                        }else if(!_confirmCodeNotSend){
                          if(_model.formKey.currentState!.validate()){
                            confirmResetPassword();
                            // _model.mobileControllerValidator.asValidator(context);
                            // showMessage(context,'Please enter Verification Code!',backgroundColor: Colors.red);
                            // return;
                          }
                          print(_model.passwordController.text);
                          // if(_model.passwordController.text.isEmpty){
                          //   _model.mobileControllerValidator.asValidator(context);
                          //   showMessage(context,'Please enter password',backgroundColor: Colors.red);
                          //   return;
                          // }
                          // confirmResetPassword();
                        }else{
                          resetPassword();
                        }
                        print(_confirmCodeNotSend);




                      },
                      text:  _confirmCodeNotSend ? 'Submit' : 'Send',
                      options: FFButtonOptions(
                        width: 330.0,
                        height: 50.0,
                        padding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        iconPadding:
                            EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                        color: PayNowTheme.of(context).primary,
                        textStyle: PayNowTheme.of(context).titleSmall.override(
                              fontFamily: 'Poppins',
                              color: Colors.white,
                            ),
                        elevation: 2.0,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    ));
  }
  void showMessage(BuildContext context, String message,double size,{Color? backgroundColor}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: PayNowTheme.of(context).titleSmall.override(
            fontFamily: 'Poppins',
            color: Colors.white,
          ),
        ),
        duration: Duration(milliseconds: 4000),
        backgroundColor: backgroundColor??PayNowTheme.of(context).primary,
      ),
    );
  }
}
