class GetPlansModel {
  final int minute;
  final String plan;
  final double amount;
  final String SK;
  final String iosProductID;
  final String PK;
  final String name;
  final String type;

  GetPlansModel({
    required this.minute,
    required this.plan,
    required this.amount,
    required this.SK,
    required this.iosProductID,
    required this.PK,
    required this.name,
    required this.type,
  });

  // Method to copy the object with modified fields
  GetPlansModel copyWith({
    int? minute,
    String? plan,
    double? amount,
    String? SK,
    String? iosProductID,
    String? PK,
    String? name,
    String? type,
  }) {
    return GetPlansModel(
      minute: minute ?? this.minute,
      plan: plan ?? this.plan,
      amount: amount ?? this.amount,
      SK: SK ?? this.SK,
      iosProductID: iosProductID ?? this.iosProductID,
      PK: PK ?? this.PK,
      name: name ?? this.name,
      type: type ?? this.type,
    );
  }

  // Method to convert the object to a JSON map
  Map<String, dynamic> toJson() {
    return {
      'minute': minute,
      'plan': plan,
      'amount': amount,
      'SK': SK,
      'iosProductID': iosProductID,
      'PK': PK,
      'name': name,
      'type': type,
    };
  }

  // Method to convert the object to a map
  Map<String, dynamic> toMap() {
    return {
      'minute': minute,
      'plan': plan,
      'amount': amount,
      'SK': SK,
      'iosProductID': iosProductID,
      'PK': PK,
      'name': name,
      'type': type,
    };
  }

  // Factory method to create an object from a JSON map
  factory GetPlansModel.fromJson(Map<String, dynamic> json) {
    return GetPlansModel(
      minute: json['minute'],
      plan: json['plan'],
      amount: json['amount'],
      SK: json['SK'],
      iosProductID: json['iosProductID'],
      PK: json['PK'],
      name: json['name'],
      type: json['type'],
    );
  }
}
