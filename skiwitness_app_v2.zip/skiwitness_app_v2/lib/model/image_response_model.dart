import 'dart:convert';

class ImageResponseModel {
  final String? message;
  final User? user;

  ImageResponseModel({
    this.message,
    this.user,
  });

  factory ImageResponseModel.fromRawJson(String str) =>
      ImageResponseModel.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory ImageResponseModel.fromJson(Map<String, dynamic> json) =>
      ImageResponseModel(
        message: json["message"],
        user: json["user"] == null ? null : User.fromJson(json["user"]),
      );

  Map<String, dynamic> toJson() => {
        "message": message,
        "user": user?.toJson(),
      };
}

class User {
  final Attributes? attributes;

  User({
    this.attributes,
  });

  factory User.fromRawJson(String str) => User.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory User.fromJson(Map<String, dynamic> json) => User(
        attributes: json["Attributes"] == null
            ? null
            : Attributes.fromJson(json["Attributes"]),
      );

  Map<String, dynamic> toJson() => {
        "Attributes": attributes?.toJson(),
      };
}

class Attributes {
  final DateTime? updateAt;
  final String? imageUrl;

  Attributes({
    this.updateAt,
    this.imageUrl,
  });

  factory Attributes.fromRawJson(String str) =>
      Attributes.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Attributes.fromJson(Map<String, dynamic> json) => Attributes(
        updateAt:
            json["updateAt"] == null ? null : DateTime.parse(json["updateAt"]),
        imageUrl: json["imageUrl"],
      );

  Map<String, dynamic> toJson() => {
        "updateAt": updateAt?.toIso8601String(),
        "imageUrl": imageUrl,
      };
}
