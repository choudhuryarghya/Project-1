import 'dart:convert';
import 'dart:io';

import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

import '../DB/create_database.dart';
import '../utils/s3bucket_upload.dart';

class VideoInfo {
  String name;
  String filePath;
  String datetime;
  String thumbnail;
  bool sync;
  bool isOffline;
  bool isUploading;

  VideoInfo(
      {required this.name,
      required this.datetime,
      required this.filePath,
      required this.thumbnail,
        required this.sync,
      required this.isOffline,
        this.isUploading = false,});
  factory VideoInfo.fromRawJson(String str) =>
      VideoInfo.fromJson(json.decode(str));

  factory VideoInfo.fromJson(Map<String, dynamic> parsedJson) {
    return VideoInfo(
        name: parsedJson['name'] ?? "",
        filePath: parsedJson['filePath'] ?? "",
        datetime: parsedJson['datetime'] ?? "",
        thumbnail: parsedJson['thumbnail'] ?? "",
        sync: parsedJson['sync'] == 1,
        isOffline: parsedJson['isOffline']  == 1);
  }

  Map<String, dynamic> toJson() {
    return {
      "name": name,
      "datetime": datetime,
      "filePath": filePath,
      "thumbnail": thumbnail,
      "sync": sync,
      "isOffline": isOffline ? 1 : 0,
    };
  }

  Map<String, dynamic> toJsonSaveDataBase() {
    return {
      // "name": name,
      // "datetime": datetime,
      // "filePath": filePath,
      // "thumbnail": thumbnail,
      // "isOffline": isOffline,
      "cognitoId": "", // Add appropriate values or leave empty for default
      "name":
          name, // Assuming 'name' corresponds to 'title' column in the table
      "filePath": filePath, // Add appropriate values or leave empty for default
      "location": "", // Add appropriate values or leave empty for default
      "duration": 0, // Add appropriate values or leave empty for default
      "thumbnail":
          thumbnail, // Add appropriate values or leave empty for default
      "thumbnailFilename":
          "", // Add appropriate values or leave empty for default
      "datetime": datetime, // Add appropriate values or leave empty for default
      "isSubscriptionExpired":
          0, // Add appropriate values or leave empty for default
      "videoCompressed": 0, // Add appropriate values or leave empty for default
      "sync": false, // Add appropriate values or leave empty for default
      "isOffline":
          isOffline, // Assuming you want to set 'isOffline' to 1 (true)
    };
  }
}

void saveVideo(VideoInfo persons) async {
  SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  List<VideoInfo> videos = await getAllVideos() ?? [];
  videos.add(persons);
  List<String> personsEncoded =
      videos.map((person) => jsonEncode(person.toJson())).toList();
  await sharedPreferences.setStringList('videos', personsEncoded);

  DataBase database = DataBase();
  // Call the initializeDatabase() method and await its completion
  Database db = await database.initializeDatabase();
  var authUser = await Amplify.Auth.getCurrentUser();
  String cognitoId = authUser.userId;
  // Customize data for specific columns
  Map<String, dynamic> videoData = persons.toJsonSaveDataBase();
  videoData['cognitoId'] = cognitoId; // Custom value for the 'isOffline' column
  // You can add more customizations for other columns here...

  await db.insert('tbl_offline_videos', videoData,
      conflictAlgorithm: ConflictAlgorithm.replace);
  // Pass the filePath of the videoInfo to the _uploadFile function
  await _uploadFile(persons.filePath,persons.name);
  print('Video saved to database successfully');
}

final S3bucketUpload s3bucketUpload = S3bucketUpload();
// File? filePath;
String? _presignedUrl;
Future<void> _uploadFile(String filePath, String name) async {
  File file = File(filePath);
  if (filePath != null) {
    String? presignedUrl = await s3bucketUpload.getPresignedUrl(file!);
    var replacedUrl = presignedUrl?.replaceFirst('https://ski-uploads-free.s3.amazonaws.com', 'https://dczmr8aignart.cloudfront.net');
      _presignedUrl = replacedUrl;
    String? uploadResult = await s3bucketUpload.uploadFileToPresignedUrl(file!, _presignedUrl!);
    if (uploadResult != null) {
      updateVideoColumn(name, 'filePath',  replacedUrl);
    }

  }
}

Future<void> updateVideoColumn(String name, String columnName, String? presignedUrl) async {
  DataBase database = DataBase();
  Database db = await database.initializeDatabase();
  // Build the map for the column update
  Map<String, dynamic> updateData = {
    columnName: presignedUrl,
    'sync': true
  };
  // Update the specific column for the video with the given id
  await db.update(
    'tbl_offline_videos',
    updateData,
    where: 'name = ?',
    whereArgs: [name],
    conflictAlgorithm: ConflictAlgorithm.replace,
  );
  print('Column $columnName updated successfully');
}

void saveVideos(List<VideoInfo> persons) async {
  SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  List<String> personsEncoded =
      persons.map((person) => jsonEncode(person.toJson())).toList();
  await sharedPreferences.setStringList('videos', personsEncoded);
}



Future<List<VideoInfo>?> getAllVideos() async {
  var authUser = await Amplify.Auth.getCurrentUser();
  String cognitoId = authUser.userId;
  // SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  // final persons = sharedPreferences.getStringList('videos');

  DataBase database = DataBase();
  Database db = await database.initializeDatabase();

  // Fetch data from SharedPreferences
  // List<VideoInfo>? sharedPreferencesVideos = persons?.map((person) => VideoInfo.fromRawJson(person)).toList();

  // Fetch data from the database
  List<Map<String, dynamic>> videoData = await db.query('tbl_offline_videos', where: 'cognitoId = ?', whereArgs: [cognitoId]);
  print('dataTest');
   // print(videoData.first['sync']);
  // Convert database data into VideoInfo objects
  List<VideoInfo> databaseVideos = videoData.map((video) => VideoInfo.fromJson(video)).toList();

  // Combine data from both sources
  List<VideoInfo> allVideos = [];
  // if (sharedPreferencesVideos != null) {
  //   allVideos.addAll(sharedPreferencesVideos);
  // }
  allVideos.addAll(databaseVideos);

  return allVideos;
}

Future<List<VideoInfo>?> getOfflineVideos() async {
  // SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
  // final persons = sharedPreferences.getStringList('videos');
  var authUser = await Amplify.Auth.getCurrentUser();
  String cognitoId = authUser.userId;


  DataBase database = DataBase();
  Database db = await database.initializeDatabase();

  // Fetch data from SharedPreferences
  // List<VideoInfo>? sharedPreferencesVideos = persons?.map((person) => VideoInfo.fromRawJson(person)).toList();

  // Fetch data from the database
  List<Map<String, dynamic>> videoData = await db.query('tbl_offline_videos',
    where: 'sync = ? AND cognitoId = ?',
    whereArgs: [0, cognitoId],
  );
  print('dataTest');
  // print(videoData.first['sync']);
  // Convert database data into VideoInfo objects
  List<VideoInfo> databaseVideos = videoData.map((video) => VideoInfo.fromJson(video)).toList();

  // Combine data from both sources
  List<VideoInfo> allVideos = [];
  // if (sharedPreferencesVideos != null) {
  //   allVideos.addAll(sharedPreferencesVideos);
  // }
  allVideos.addAll(databaseVideos);

  return allVideos;
}
