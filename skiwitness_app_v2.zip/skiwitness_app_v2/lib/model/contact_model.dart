class ContactModel {
  final String cognitoId;
  final String body;

  ContactModel({
    required this.cognitoId,
    required this.body,
  });

  // CopyWith function
  ContactModel copyWith({
    String? cognitoId,
    String? body,
  }) {
    return ContactModel(
      cognitoId: cognitoId ?? this.cognitoId,
      body: body ?? this.body,
    );
  }

  // Convert to JSON
  Map<String, dynamic> toJson() {
    return {
      'cognitoId': cognitoId,
      'body': body,
    };
  }

  // Convert to Map
  Map<String, dynamic> toMap() {
    return {
      'cognitoId': cognitoId,
      'body': body,
    };
  }

  // Create an instance from a JSON map
  factory ContactModel.fromJson(Map<String, dynamic> json) {
    return ContactModel(
      cognitoId: json['cognitoId'] as String,
      body: json['body'] as String,
    );
  }

  // Create an instance from a Map
  factory ContactModel.fromMap(Map<String, dynamic> map) {
    return ContactModel(
      cognitoId: map['cognitoId'] as String,
      body: map['body'] as String,
    );
  }
}
