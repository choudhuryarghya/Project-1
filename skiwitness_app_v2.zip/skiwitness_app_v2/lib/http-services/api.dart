class api {
     String baseUrl = 'https://hx7h2j6r82.execute-api.us-east-1.amazonaws.com/';
}