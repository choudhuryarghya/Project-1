import 'dart:developer';

import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:sentry_flutter/sentry_flutter.dart';

class IAPService {
  void listenToPurchaseUpdated(
    List<PurchaseDetails> purchaseDetailsList,
  ) async {
    log("object $purchaseDetailsList");
    for (final purchaseDetails in purchaseDetailsList) {
      log("purchaseDetails.status: ${purchaseDetails.status}");
      log("purchaseDetails: $purchaseDetails");

      await Sentry.captureMessage(
          "purchaseDetails.status: ${purchaseDetails.status}");
      await Sentry.captureMessage("purchaseDetails: $purchaseDetails");

      if (purchaseDetails.status == PurchaseStatus.purchased ||
          purchaseDetails.status == PurchaseStatus.restored) {
        log("1 object ${purchaseDetails.status}");
        log("1 object $purchaseDetails");

        await Sentry.captureMessage("1 object ${purchaseDetails.status}");
        await Sentry.captureMessage("1 object $purchaseDetails");

        bool valid = await _verifyPurchase(purchaseDetails);
        if (valid) {
          _handleSuccessfulPurchase(purchaseDetails);
        }
      }

      if (purchaseDetails.status == PurchaseStatus.error) {
        log(purchaseDetails.error!.toString());
        await Sentry.captureMessage(purchaseDetails.error!.toString());
      }

      if (purchaseDetails.pendingCompletePurchase) {
        await InAppPurchase.instance.completePurchase(purchaseDetails);
        log("Purchase marked complete");
        await Sentry.captureMessage("Purchase marked complete");
      }
    }
  }

  Future<bool> _verifyPurchase(PurchaseDetails purchaseDetails) async {
    log("Verifying Purchase $purchaseDetails");
    await Sentry.captureMessage("Verifying Purchase $purchaseDetails");
    return true;
  }

  void _handleSuccessfulPurchase(PurchaseDetails purchaseDetails) async {
    if (purchaseDetails.productID == "auto_30_min_4_99") {
      log("30 min buy");
      await Sentry.captureMessage("30 min buy");
    }
    if (purchaseDetails.productID == "auto_60_min_9_99") {
      log("60 min buy");
      await Sentry.captureMessage("60 min buy");
    }
    if (purchaseDetails.productID == "auto_90_min_11_99") {
      log("90 min buy");
      await Sentry.captureMessage("90 min buy");
    }
    if (purchaseDetails.productID == "auto_120_min_12_99") {
      log("120 min buy");
      await Sentry.captureMessage("120 min buy");
    }
    if (purchaseDetails.productID == "auto_240_min_18_99") {
      log("240 min buy");
      await Sentry.captureMessage("240 min buy");
    }
  }
}
