enum SubscriptionIds {
  minutes30('auto_30_min_4_99'),
  minutes60('auto_60_min_9_99'),
  minutes90('auto_90_min_11_99'),
  minutes120('auto_120_min_12_99'),
  minutes240('auto_240_min_18_99');

  const SubscriptionIds(this.key);
  final String key;
}
