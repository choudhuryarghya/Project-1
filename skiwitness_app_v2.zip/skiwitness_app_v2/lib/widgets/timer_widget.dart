import 'package:flutter/material.dart';

class RemainingTimer extends StatelessWidget {
  final Color timerColor;

  const RemainingTimer({super.key, this.timerColor = Colors.green});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Padding(
          padding: const EdgeInsets.all(2.0),
          child: Icon(
            Icons.timer,
            color: timerColor,
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            "12:15:00",
            style: TextStyle(color: timerColor, fontWeight: FontWeight.bold),
          ),
        )
      ],
    );
  }
}
